// src/shared/browser.ts
var REQUEST_HEADERS = "requestHeaders";
var EXTRA_HEADERS = "extraHeaders";
var cachedBrowserTarget = null;
function getExtensionBrowserTarget() {
  if (cachedBrowserTarget) {
    return cachedBrowserTarget;
  }
  try {
    const runtimeUrl = chrome.runtime.getURL("/");
    if (runtimeUrl.startsWith("moz-extension://")) {
      cachedBrowserTarget = "firefox";
      return cachedBrowserTarget;
    }
  } catch {
  }
  cachedBrowserTarget = "chromium";
  return cachedBrowserTarget;
}
function isFirefoxExtension() {
  return getExtensionBrowserTarget() === "firefox";
}
function getInstallDirectory() {
  return isFirefoxExtension() ? "browser_extension/firefox" : "browser_extension/chromium";
}
function getOnSendHeadersExtraInfoSpec() {
  return isFirefoxExtension() ? [REQUEST_HEADERS] : [REQUEST_HEADERS, EXTRA_HEADERS];
}
function supportsDownloadDeterminingFilename() {
  return Boolean(chrome.downloads?.onDeterminingFilename?.addListener);
}

// src/shared/constants.ts
var DEFAULT_SERVER_URL = "ws://127.0.0.1:14370";
var EXTENSION_VERSION = chrome.runtime.getManifest().version;
var ADVANCED_FEATURES = [
  {
    key: "recorder",
    title: "\u89C6\u9891\u5F55\u5236",
    description: "\u5F55\u5236\u7F51\u9875\u4E2D\u7684\u89C6\u9891\u5185\u5BB9"
  },
  {
    key: "webrtc",
    title: "\u5F55\u5236 WebRTC",
    description: "\u5F55\u5236 WebRTC \u5B9E\u65F6\u901A\u4FE1\u5185\u5BB9",
    reloadRequired: true
  },
  {
    key: "recorder2",
    title: "\u5C4F\u5E55\u6355\u6349",
    description: "\u6355\u6349\u5C4F\u5E55\u3001\u7A97\u53E3\u6216\u6807\u7B7E\u9875"
  },
  {
    key: "mobileUserAgent",
    title: "\u6A21\u62DF\u624B\u673A",
    description: "\u6A21\u62DF\u79FB\u52A8\u8BBE\u5907\u8BBF\u95EE\u9875\u9762",
    reloadRequired: true
  },
  {
    key: "search",
    title: "\u6DF1\u5EA6\u641C\u7D22",
    description: "\u6DF1\u5165\u5206\u6790\u9875\u9762\u8BF7\u6C42\u8D44\u6E90",
    reloadRequired: true
  },
  {
    key: "catch",
    title: "\u7F13\u5B58\u6355\u6349",
    description: "\u6355\u6349\u6D4F\u89C8\u5668\u7F13\u5B58\u7684\u8D44\u6E90",
    reloadRequired: true
  }
];
var HELP_CONTENT = {
  pairing: {
    title: "\u5982\u4F55\u914D\u5BF9\u684C\u9762\u7AEF",
    body: [
      "1. \u5728 Ghost-Downloader-3 \u684C\u9762\u7AEF\u8BBE\u7F6E\u9875\u5F00\u542F\u201C\u542F\u7528\u6D4F\u89C8\u5668\u6269\u5C55\u201D\u3002",
      "2. \u590D\u5236\u684C\u9762\u7AEF\u663E\u793A\u7684\u914D\u5BF9\u4EE4\u724C\u3002",
      "3. \u56DE\u5230\u6269\u5C55\u8BBE\u7F6E\u9875\uFF0C\u628A\u4EE4\u724C\u7C98\u8D34\u5230\u201C\u914D\u5BF9\u4EE4\u724C\u201D\u8F93\u5165\u6846\u5E76\u4FDD\u5B58\u3002",
      "4. \u8FDE\u63A5\u72B6\u6001\u53D8\u6210\u201C\u5DF2\u8FDE\u63A5\u201D\u540E\uFF0C\u6D4F\u89C8\u5668\u5C31\u80FD\u76F4\u63A5\u7BA1\u7406\u684C\u9762\u4EFB\u52A1\u4E86\u3002"
    ]
  },
  install: {
    title: "\u5B89\u88C5\u8BF4\u660E",
    body: isFirefoxExtension() ? [
      "1. \u6253\u5F00 about:debugging#/runtime/this-firefox\u3002",
      "2. \u70B9\u51FB\u201C\u4E34\u65F6\u8F7D\u5165\u9644\u52A0\u7EC4\u4EF6\u201D\u3002",
      `3. \u9009\u62E9\u9879\u76EE\u91CC\u7684 ${getInstallDirectory()} \u76EE\u5F55\u5185\u4EFB\u610F\u6587\u4EF6\u3002`,
      "4. \u4FDD\u6301\u684C\u9762\u7AEF\u6D4F\u89C8\u5668\u670D\u52A1\u5F00\u542F\u5373\u53EF\u6B63\u5E38\u8FDE\u63A5\u3002"
    ] : [
      "1. \u6253\u5F00\u6D4F\u89C8\u5668\u6269\u5C55\u7BA1\u7406\u9875\u5E76\u5F00\u542F\u5F00\u53D1\u8005\u6A21\u5F0F\u3002",
      "2. \u9009\u62E9\u201C\u52A0\u8F7D\u5DF2\u89E3\u538B\u7684\u6269\u5C55\u7A0B\u5E8F\u201D\u3002",
      `3. \u9009\u62E9\u9879\u76EE\u91CC\u7684 ${getInstallDirectory()} \u76EE\u5F55\u3002`,
      "4. \u4FDD\u6301\u684C\u9762\u7AEF\u6D4F\u89C8\u5668\u670D\u52A1\u5F00\u542F\u5373\u53EF\u6B63\u5E38\u8FDE\u63A5\u3002"
    ]
  },
  troubleshooting: {
    title: "\u6545\u969C\u6392\u67E5",
    body: [
      "1. \u5148\u786E\u8BA4\u684C\u9762\u7AEF\u6D4F\u89C8\u5668\u6269\u5C55\u670D\u52A1\u5DF2\u7ECF\u5F00\u542F\u3002",
      "2. \u68C0\u67E5\u914D\u5BF9\u4EE4\u724C\u662F\u5426\u548C\u684C\u9762\u7AEF\u4E00\u81F4\uFF0C\u5FC5\u8981\u65F6\u91CD\u65B0\u751F\u6210\u540E\u518D\u6B21\u4FDD\u5B58\u3002",
      "3. \u5982\u679C\u72B6\u6001\u4E00\u76F4\u65AD\u5F00\uFF0C\u5C1D\u8BD5\u70B9\u51FB\u8BBE\u7F6E\u9875\u91CC\u7684\u91CD\u65B0\u8FDE\u63A5\u3002",
      "4. \u6D4F\u89C8\u5668\u4E0B\u8F7D\u6CA1\u6709\u88AB\u63A5\u7BA1\u65F6\uFF0C\u53EF\u5148\u786E\u8BA4\u9876\u90E8\u201C\u62E6\u622A\u4E0B\u8F7D\u201D\u5F00\u5173\u662F\u5426\u5F00\u542F\u3002"
    ]
  }
};

// src/background/constants.ts
var PROTOCOL_VERSION = 1;
var RECONNECT_ALARM = "gd3-reconnect";
var RESOURCE_LIMIT = 120;
var HEADER_SNAPSHOT_LIMIT = 80;
var HEADER_EXPIRATION_MS = 2 * 60 * 1e3;
var BRIDGE_PERSIST_DEBOUNCE_MS = 240;
var MEDIA_SCAN_INTERVAL_MS = 4e3;
var MEDIA_FAILURE_THRESHOLD = 3;
var MAIN_FRAME_ID = 0;
var PAIR_TOKEN_KEY = "pairToken";
var SERVER_URL_KEY = "desktopServerUrl";
var INTERCEPT_DOWNLOADS_KEY = "interceptDownloads";
var DOMAIN_BLACKLIST_KEY = "domainBlacklist";
var TYPE_BLACKLIST_KEY = "typeBlacklist";
var SIZE_BLACKLIST_KEY = "sizeBlacklistMB";
var FEATURE_TAB_STATE_KEY = "featureTabState";
var MEDIA_TARGET_KEY = "mediaControlTarget";
var BRIDGE_RESOURCE_CACHE_KEY = "bridgeResourceCacheByTab";
var BRIDGE_HEADER_SNAPSHOTS_KEY = "bridgeHeaderSnapshots";
var BRIDGE_LAST_ACTIVE_TAB_KEY = "bridgeLastActiveTabId";
var FEATURE_KEYS = ADVANCED_FEATURES.map((item) => item.key);

// src/background/chrome-helpers.ts
function bridgeStorageArea() {
  return chrome.storage.session ?? chrome.storage.local;
}
async function localStorageGet(defaults) {
  const items = await chrome.storage.local.get(defaults);
  return items;
}
async function localStorageSet(values) {
  await chrome.storage.local.set(values);
}
async function bridgeStorageGet(defaults) {
  const items = await bridgeStorageArea().get(defaults);
  return items;
}
async function bridgeStorageSet(values) {
  await bridgeStorageArea().set(values);
}
async function queryTabs(queryInfo) {
  return chrome.tabs.query(queryInfo);
}
async function getTab(tabId) {
  try {
    return await chrome.tabs.get(tabId);
  } catch {
    return null;
  }
}
async function sendMessageToTab(tabId, message, options) {
  const tab = await getTab(tabId);
  if (!tab?.id) {
    return {
      status: "no_receiver",
      message: "\u76EE\u6807\u6807\u7B7E\u9875\u4E0D\u5B58\u5728"
    };
  }
  return new Promise((resolve) => {
    chrome.tabs.sendMessage(tabId, message, options ?? {}, (response) => {
      const lastError = chrome.runtime.lastError;
      if (lastError) {
        const text = String(lastError.message || "");
        const status = /receiving end does not exist/i.test(text) ? "no_receiver" : "runtime_error";
        resolve({
          status,
          message: text
        });
        return;
      }
      if (typeof response === "undefined") {
        resolve({
          status: "no_response"
        });
        return;
      }
      resolve({
        status: "ok",
        response
      });
    });
  });
}
async function reloadTab(tabId) {
  return new Promise((resolve) => {
    chrome.tabs.reload(tabId, { bypassCache: true }, () => resolve());
  });
}
async function activateTab(tabId) {
  const tab = await getTab(tabId);
  if (!tab?.id) {
    return;
  }
  if (typeof tab.index === "number" && typeof tab.windowId === "number") {
    await new Promise((resolve) => {
      chrome.tabs.highlight({ windowId: tab.windowId, tabs: tab.index }, () => resolve());
    });
    return;
  }
  await new Promise((resolve) => {
    chrome.tabs.update(tabId, { active: true }, () => resolve());
  });
}
async function cancelDownload(downloadId) {
  return new Promise((resolve, reject) => {
    chrome.downloads.cancel(downloadId, () => {
      const lastError = chrome.runtime.lastError;
      if (lastError) {
        reject(new Error(lastError.message));
        return;
      }
      resolve();
    });
  });
}
async function eraseDownloadFromHistory(downloadId) {
  return new Promise((resolve, reject) => {
    chrome.downloads.erase({ id: downloadId }, () => {
      const lastError = chrome.runtime.lastError;
      if (lastError) {
        reject(new Error(lastError.message));
        return;
      }
      resolve();
    });
  });
}
async function openActionPopup() {
  if (!chrome.action?.openPopup) {
    return;
  }
  try {
    await chrome.action.openPopup();
  } catch {
  }
}

// src/background/desktop-bridge.ts
function createDesktopBridge() {
  let desktopSocket = null;
  let reconnectTimer = null;
  let connectionState = "missing_token";
  let connectionMessage = "\u8BF7\u5148\u5728\u6269\u5C55\u8BBE\u7F6E\u91CC\u586B\u5199\u914D\u5BF9\u4EE4\u724C";
  let desktopVersion = "";
  let pairToken = "";
  let serverUrl = DEFAULT_SERVER_URL;
  let taskSnapshot = [];
  const pendingRequests = /* @__PURE__ */ new Map();
  function nextRequestId() {
    return crypto.randomUUID();
  }
  function setConnectionState(state, message) {
    connectionState = state;
    connectionMessage = message;
  }
  function rejectPendingRequests(message) {
    for (const [requestId, pending] of pendingRequests.entries()) {
      clearTimeout(pending.timeoutId);
      pending.reject(new Error(message));
      pendingRequests.delete(requestId);
    }
  }
  function isReady() {
    return connectionState === "connected" && desktopSocket?.readyState === WebSocket.OPEN;
  }
  function clearReconnectTimer() {
    if (reconnectTimer !== null) {
      clearTimeout(reconnectTimer);
      reconnectTimer = null;
    }
  }
  function scheduleReconnect() {
    if (!pairToken || reconnectTimer !== null) {
      return;
    }
    reconnectTimer = self.setTimeout(() => {
      reconnectTimer = null;
      void connect();
    }, 2500);
  }
  function handleDesktopMessage(rawData) {
    let message;
    try {
      message = JSON.parse(rawData);
    } catch {
      return;
    }
    if (message.type === "hello_ack") {
      desktopVersion = String(message.appVersion ?? "");
      setConnectionState("connected", "\u5DF2\u8FDE\u63A5");
      desktopSocket?.send(JSON.stringify({ type: "subscribe_tasks", requestId: nextRequestId() }));
      return;
    }
    if (message.type === "task_snapshot" && Array.isArray(message.tasks)) {
      taskSnapshot = message.tasks;
      return;
    }
    if (message.type === "create_task_result" || message.type === "task_action_result") {
      const requestId = String(message.requestId ?? "");
      const pending = pendingRequests.get(requestId);
      if (!pending) {
        return;
      }
      clearTimeout(pending.timeoutId);
      pendingRequests.delete(requestId);
      pending.resolve(message);
      return;
    }
    if (message.type === "error" && connectionState === "authenticating") {
      const text = String(message.message ?? "\u914D\u5BF9\u4EE4\u724C\u65E0\u6548");
      desktopVersion = "";
      taskSnapshot = [];
      setConnectionState("unauthorized", text);
      rejectPendingRequests(text);
      desktopSocket?.close();
      desktopSocket = null;
    }
  }
  async function connect(force = false) {
    if (!pairToken) {
      desktopVersion = "";
      taskSnapshot = [];
      setConnectionState("missing_token", "\u8BF7\u5148\u5728\u6269\u5C55\u8BBE\u7F6E\u91CC\u586B\u5199\u914D\u5BF9\u4EE4\u724C");
      return;
    }
    if (desktopSocket && desktopSocket.readyState === WebSocket.OPEN && !force) {
      return;
    }
    clearReconnectTimer();
    if (force && desktopSocket) {
      desktopSocket.close();
      desktopSocket = null;
    }
    setConnectionState("connecting", "\u6B63\u5728\u8FDE\u63A5 Ghost Downloader");
    const socket = new WebSocket(serverUrl);
    desktopSocket = socket;
    socket.addEventListener("open", () => {
      if (desktopSocket !== socket) {
        return;
      }
      setConnectionState("authenticating", "\u6B63\u5728\u6821\u9A8C\u914D\u5BF9\u4EE4\u724C");
      socket.send(
        JSON.stringify({
          type: "hello",
          protocolVersion: PROTOCOL_VERSION,
          token: pairToken,
          extensionVersion: chrome.runtime.getManifest().version,
          clientKind: "chromium_popup"
        })
      );
    });
    socket.addEventListener("message", (event) => {
      if (desktopSocket !== socket) {
        return;
      }
      handleDesktopMessage(String(event.data ?? ""));
    });
    socket.addEventListener("close", () => {
      if (desktopSocket !== socket) {
        return;
      }
      desktopSocket = null;
      rejectPendingRequests("\u4E0E Ghost Downloader \u7684\u8FDE\u63A5\u5DF2\u65AD\u5F00");
      if (connectionState !== "unauthorized" && connectionState !== "missing_token") {
        desktopVersion = "";
        setConnectionState("disconnected", "\u672A\u8FDE\u63A5");
        scheduleReconnect();
      }
    });
    socket.addEventListener("error", () => {
      if (desktopSocket !== socket) {
        return;
      }
      if (connectionState !== "unauthorized") {
        desktopVersion = "";
        setConnectionState("disconnected", "\u65E0\u6CD5\u8FDE\u63A5\u5230 Ghost Downloader");
      }
    });
  }
  async function sendRequest(payload) {
    if (!isReady() || !desktopSocket) {
      throw new Error("Ghost Downloader \u672A\u8FDE\u63A5");
    }
    const requestId = String(payload.requestId ?? nextRequestId());
    const message = { ...payload, requestId };
    return new Promise((resolve, reject) => {
      const timeoutId = self.setTimeout(() => {
        pendingRequests.delete(requestId);
        reject(new Error("\u7B49\u5F85 Ghost Downloader \u54CD\u5E94\u8D85\u65F6"));
      }, 12e3);
      pendingRequests.set(requestId, {
        resolve: (value) => resolve(value),
        reject,
        timeoutId
      });
      desktopSocket?.send(JSON.stringify(message));
    });
  }
  async function loadPersistentState() {
    const localState = await localStorageGet({
      [PAIR_TOKEN_KEY]: "",
      [SERVER_URL_KEY]: DEFAULT_SERVER_URL
    });
    pairToken = String(localState[PAIR_TOKEN_KEY] ?? "").trim();
    serverUrl = String(localState[SERVER_URL_KEY] ?? DEFAULT_SERVER_URL).trim() || DEFAULT_SERVER_URL;
  }
  async function setToken(token) {
    pairToken = String(token ?? "").trim();
    await localStorageSet({ [PAIR_TOKEN_KEY]: pairToken });
    if (pairToken) {
      await connect(true);
      return;
    }
    desktopVersion = "";
    taskSnapshot = [];
    if (desktopSocket) {
      desktopSocket.close();
      desktopSocket = null;
    }
    setConnectionState("missing_token", "\u8BF7\u5148\u5728\u6269\u5C55\u8BBE\u7F6E\u91CC\u586B\u5199\u914D\u5BF9\u4EE4\u724C");
  }
  async function setServerUrl(nextServerUrl) {
    serverUrl = String(nextServerUrl ?? DEFAULT_SERVER_URL).trim() || DEFAULT_SERVER_URL;
    await localStorageSet({ [SERVER_URL_KEY]: serverUrl });
    await connect(true);
  }
  function syncLocalStorageChanges(changes) {
    if (changes[PAIR_TOKEN_KEY]) {
      pairToken = String(changes[PAIR_TOKEN_KEY].newValue ?? "").trim();
    }
    if (changes[SERVER_URL_KEY]) {
      serverUrl = String(changes[SERVER_URL_KEY].newValue ?? DEFAULT_SERVER_URL).trim() || DEFAULT_SERVER_URL;
    }
  }
  function buildSnapshot() {
    return {
      connectionState,
      connectionMessage,
      desktopVersion,
      token: pairToken,
      serverUrl,
      tasks: taskSnapshot
    };
  }
  function ensureReconnectAlarm() {
    chrome.alarms.create(RECONNECT_ALARM, { periodInMinutes: 1 });
  }
  function handleReconnectAlarm(alarm) {
    if (alarm.name !== RECONNECT_ALARM || connectionState === "connected") {
      return;
    }
    void connect();
  }
  return {
    buildSnapshot,
    connect,
    ensureReconnectAlarm,
    handleReconnectAlarm,
    isReady,
    loadPersistentState,
    sendRequest,
    setServerUrl,
    setToken,
    syncLocalStorageChanges
  };
}

// src/background/feature-bridge.ts
var MOBILE_USER_AGENT = "Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1";
var SCRIPT_FEATURES = {
  recorder: {
    script: "recorder.js",
    refresh: false,
    allFrames: true,
    world: "MAIN",
    injectI18n: true
  },
  webrtc: {
    script: "webrtc.js",
    refresh: true,
    allFrames: true,
    world: "MAIN",
    injectI18n: true
  },
  recorder2: {
    script: "recorder2.js",
    refresh: false,
    allFrames: false,
    world: "ISOLATED",
    injectI18n: true
  },
  search: {
    script: "search.js",
    refresh: true,
    allFrames: true,
    world: "MAIN",
    injectI18n: false
  },
  catch: {
    script: "catch.js",
    refresh: true,
    allFrames: true,
    world: "MAIN",
    injectI18n: true
  }
};
function createFeatureBridge() {
  const featureTabs = Object.fromEntries(
    FEATURE_KEYS.map((key) => [key, /* @__PURE__ */ new Set()])
  );
  function createFeatureStateMap(tabId) {
    return FEATURE_KEYS.reduce((state, key) => {
      state[key] = tabId != null && featureTabs[key].has(tabId);
      return state;
    }, {});
  }
  function featureStoragePayload() {
    return FEATURE_KEYS.reduce((state, key) => {
      state[key] = Array.from(featureTabs[key]);
      return state;
    }, {});
  }
  async function persistFeatureTabs() {
    await localStorageSet({ [FEATURE_TAB_STATE_KEY]: featureStoragePayload() });
  }
  async function updateSessionRules(tabId, enabled) {
    return new Promise((resolve, reject) => {
      chrome.declarativeNetRequest.updateSessionRules(
        enabled ? {
          removeRuleIds: [tabId],
          addRules: [
            {
              id: tabId,
              action: {
                type: "modifyHeaders",
                requestHeaders: [
                  {
                    header: "User-Agent",
                    operation: "set",
                    value: MOBILE_USER_AGENT
                  }
                ]
              },
              condition: {
                tabIds: [tabId],
                resourceTypes: Object.values(chrome.declarativeNetRequest.ResourceType)
              }
            }
          ]
        } : {
          removeRuleIds: [tabId]
        },
        () => {
          const lastError = chrome.runtime.lastError;
          if (lastError) {
            reject(new Error(lastError.message));
            return;
          }
          resolve();
        }
      );
    });
  }
  async function executeScriptFiles(tabId, definition, frameIds) {
    const files = definition.injectI18n ? ["catch-script/i18n.js", `catch-script/${definition.script}`] : [`catch-script/${definition.script}`];
    await chrome.scripting.executeScript({
      target: definition.allFrames ? frameIds ? { tabId, frameIds } : { tabId, allFrames: true } : { tabId, frameIds: frameIds ?? [MAIN_FRAME_ID] },
      files,
      injectImmediately: true,
      world: definition.world
    });
  }
  async function applyMobileUserAgent(tabId) {
    await chrome.scripting.executeScript({
      target: { tabId, allFrames: true },
      injectImmediately: true,
      world: "MAIN",
      args: [MOBILE_USER_AGENT],
      func: (userAgent) => {
        Object.defineProperty(navigator, "userAgent", {
          value: userAgent,
          writable: false
        });
      }
    });
  }
  function featureKeyFromScript(scriptName) {
    switch (scriptName) {
      case "recorder.js":
        return "recorder";
      case "webrtc.js":
        return "webrtc";
      case "recorder2.js":
        return "recorder2";
      case "search.js":
        return "search";
      case "catch.js":
        return "catch";
      default:
        return null;
    }
  }
  async function setFeatureEnabled(key, tabId, enabled) {
    if (key === "mobileUserAgent") {
      if (enabled) {
        featureTabs.mobileUserAgent.add(tabId);
        await updateSessionRules(tabId, true);
        await persistFeatureTabs();
        await reloadTab(tabId);
        return "\u5DF2\u542F\u7528\u6A21\u62DF\u624B\u673A\uFF0C\u5C06\u5728\u5237\u65B0\u540E\u751F\u6548";
      }
      featureTabs.mobileUserAgent.delete(tabId);
      await updateSessionRules(tabId, false);
      await persistFeatureTabs();
      await reloadTab(tabId);
      return "\u5DF2\u5173\u95ED\u6A21\u62DF\u624B\u673A";
    }
    const definition = SCRIPT_FEATURES[key];
    if (!definition) {
      return "";
    }
    if (enabled) {
      featureTabs[key].add(tabId);
      await persistFeatureTabs();
      if (definition.refresh) {
        await reloadTab(tabId);
        return "\u529F\u80FD\u5DF2\u5F00\u542F\uFF0C\u9875\u9762\u5237\u65B0\u540E\u751F\u6548";
      }
      await executeScriptFiles(tabId, definition);
      return "\u529F\u80FD\u5DF2\u5F00\u542F";
    }
    featureTabs[key].delete(tabId);
    await persistFeatureTabs();
    if (definition.refresh) {
      await reloadTab(tabId);
      return "\u529F\u80FD\u5DF2\u5173\u95ED";
    }
    return "\u529F\u80FD\u540E\u53F0\u72B6\u6001\u5DF2\u5173\u95ED\uFF0C\u9875\u9762\u4E2D\u7684\u9762\u677F\u53EF\u5728\u7F51\u9875\u5185\u81EA\u884C\u5173\u95ED";
  }
  async function loadPersistentState() {
    const localState = await localStorageGet({
      [FEATURE_TAB_STATE_KEY]: {}
    });
    const storedFeatureTabs = localState[FEATURE_TAB_STATE_KEY] ?? {};
    for (const key of FEATURE_KEYS) {
      featureTabs[key] = new Set((storedFeatureTabs[key] ?? []).filter((value) => Number.isInteger(value)));
    }
    for (const tabId of featureTabs.mobileUserAgent) {
      try {
        await updateSessionRules(tabId, true);
      } catch {
        featureTabs.mobileUserAgent.delete(tabId);
      }
    }
    await persistFeatureTabs();
  }
  async function toggleFeature(key, tabId) {
    const enabled = !featureTabs[key].has(tabId);
    return setFeatureEnabled(key, tabId, enabled);
  }
  async function handleBridgeScriptCommand(payload, sender) {
    if (payload.Message !== "script" || typeof payload.script !== "string") {
      return;
    }
    const tabId = sender.tab?.id;
    const key = featureKeyFromScript(String(payload.script));
    if (!tabId || !key || !featureTabs[key].has(tabId)) {
      return;
    }
    await setFeatureEnabled(key, tabId, false);
  }
  function handleTabRemoved(tabId) {
    for (const key of FEATURE_KEYS) {
      featureTabs[key].delete(tabId);
    }
    void updateSessionRules(tabId, false).catch(() => {
    });
    void persistFeatureTabs();
  }
  function handleNavigationCommitted(details) {
    if (details.tabId <= 0 || !/^https?:/i.test(details.url)) {
      return;
    }
    for (const key of FEATURE_KEYS) {
      if (key === "mobileUserAgent") {
        continue;
      }
      if (!featureTabs[key].has(details.tabId)) {
        continue;
      }
      const definition = SCRIPT_FEATURES[key];
      if (!definition) {
        continue;
      }
      if (!definition.allFrames && details.frameId !== MAIN_FRAME_ID) {
        continue;
      }
      void executeScriptFiles(details.tabId, definition, definition.allFrames ? [details.frameId] : [MAIN_FRAME_ID]).catch(() => {
      });
    }
    if (details.frameId === MAIN_FRAME_ID && featureTabs.mobileUserAgent.has(details.tabId)) {
      void applyMobileUserAgent(details.tabId).catch(() => {
      });
    }
  }
  return {
    createFeatureStateMap,
    handleBridgeScriptCommand,
    handleNavigationCommitted,
    handleTabRemoved,
    loadPersistentState,
    toggleFeature
  };
}

// src/shared/utils.ts
var VIDEO_EXTENSIONS = /* @__PURE__ */ new Set(["mp4", "mkv", "webm", "mov", "avi", "flv", "m4s", "ts"]);
var AUDIO_EXTENSIONS = /* @__PURE__ */ new Set(["mp3", "m4a", "flac", "wav", "aac", "opus", "ogg", "m4s"]);
var IMAGE_EXTENSIONS = /* @__PURE__ */ new Set(["jpg", "jpeg", "png", "gif", "webp", "bmp", "svg", "avif", "heic"]);
var ARCHIVE_EXTENSIONS = /* @__PURE__ */ new Set(["zip", "7z", "rar", "tar", "gz", "bz2", "xz"]);
var PDF_EXTENSIONS = /* @__PURE__ */ new Set(["pdf"]);
var SPREADSHEET_EXTENSIONS = /* @__PURE__ */ new Set(["xls", "xlsx", "csv", "tsv", "ods", "numbers"]);
var DOCUMENT_EXTENSIONS = /* @__PURE__ */ new Set([
  "txt",
  "md",
  "rtf",
  "doc",
  "docx",
  "ppt",
  "pptx",
  "pages",
  "key",
  "epub"
]);
var CAT_CATCH_MEDIA_EXTENSIONS = /* @__PURE__ */ new Set(["ogg", "ogv", "mp4", "webm", "mp3", "wav", "m4a", "3gp", "mpeg", "mov", "m4s", "aac"]);
function shorten(value, max = 44) {
  if (!value || value.length <= max) {
    return value;
  }
  return `${value.slice(0, Math.max(0, max - 3))}...`;
}
function domainFromUrl(value) {
  try {
    return new URL(value).hostname;
  } catch {
    return "";
  }
}
function filenameFromUrl(value) {
  try {
    const url = new URL(value);
    return decodeURIComponent(url.pathname.split("/").pop() || "");
  } catch {
    return "";
  }
}
function fileExtension(name) {
  const trimmed = String(name || "").trim();
  const dotIndex = trimmed.lastIndexOf(".");
  if (dotIndex < 0) {
    return "";
  }
  return trimmed.slice(dotIndex + 1).toLowerCase();
}
function inferParserHint(rawUrl, mime, extension) {
  const loweredUrl = String(rawUrl || "").toLowerCase();
  const loweredMime = String(mime || "").toLowerCase();
  const loweredExt = String(extension || "").toLowerCase();
  if (loweredExt === "m3u8" || loweredExt === "m3u" || loweredUrl.includes(".m3u8") || loweredMime.includes("mpegurl")) {
    return "m3u8";
  }
  if (loweredExt === "mpd" || loweredUrl.includes(".mpd") || loweredMime === "application/dash+xml") {
    return "mpd";
  }
  if (loweredMime.startsWith("video/") || loweredMime.startsWith("audio/")) {
    return "media";
  }
  if (VIDEO_EXTENSIONS.has(loweredExt) || AUDIO_EXTENSIONS.has(loweredExt)) {
    return "media";
  }
  if (["zip", "7z", "rar", "pdf", "exe", "msi", "dmg", "pkg", "apk", "iso"].includes(loweredExt)) {
    return "download";
  }
  return "other";
}
function inferDashTrackKind(name, rawUrl) {
  const filename = String(name || filenameFromUrl(rawUrl) || "");
  const lowered = `${filename} ${rawUrl}`.toLowerCase();
  if (/(^|[-_.\\/])(video)([-_.\\/]|$)/i.test(lowered)) {
    return "video";
  }
  if (/(^|[-_.\\/])(audio)([-_.\\/]|$)/i.test(lowered)) {
    return "audio";
  }
  const match = lowered.match(/-(\d{5,6})(?=\.m4s(?:$|[?#]))/i) ?? lowered.match(/\/(\d{5,6})(?=\.m4s(?:$|[?#]))/i);
  const trackId = Number(match?.[1] ?? 0);
  if (!Number.isFinite(trackId) || trackId <= 0) {
    return "";
  }
  if (trackId >= 1e5) {
    return "video";
  }
  if (trackId >= 3e4 && trackId < 4e4) {
    return "audio";
  }
  return "";
}
function inferResourceMediaKind(resource, extension) {
  const mime = String(resource.mime || "").toLowerCase();
  if (extension === "m4s") {
    const dashKind = inferDashTrackKind(resource.filename, resource.url);
    if (dashKind) {
      return dashKind;
    }
  }
  if (mime.startsWith("video/")) {
    return "video";
  }
  if (mime.startsWith("audio/")) {
    return "audio";
  }
  if (VIDEO_EXTENSIONS.has(extension) && !AUDIO_EXTENSIONS.has(extension)) {
    return "video";
  }
  if (AUDIO_EXTENSIONS.has(extension) && !VIDEO_EXTENSIONS.has(extension)) {
    return "audio";
  }
  return "";
}
function inferDeliveryTarget(url) {
  return String(url || "").startsWith("blob:") ? "browser_download" : "gd3";
}
function inferVisualKind({
  extension,
  mime,
  parserHint
}) {
  const loweredMime = String(mime || "").toLowerCase();
  const loweredExtension = String(extension || "").toLowerCase();
  if (parserHint === "m3u8" || parserHint === "mpd") {
    return "stream";
  }
  if (loweredMime.startsWith("video/") || VIDEO_EXTENSIONS.has(loweredExtension)) {
    return "video";
  }
  if (loweredMime.startsWith("audio/") || AUDIO_EXTENSIONS.has(loweredExtension)) {
    return "audio";
  }
  if (loweredMime.startsWith("image/") || IMAGE_EXTENSIONS.has(loweredExtension)) {
    return "image";
  }
  if (ARCHIVE_EXTENSIONS.has(loweredExtension)) {
    return "archive";
  }
  if (PDF_EXTENSIONS.has(loweredExtension) || loweredMime === "application/pdf") {
    return "pdf";
  }
  if (SPREADSHEET_EXTENSIONS.has(loweredExtension) || loweredMime.includes("spreadsheet") || loweredMime.includes("excel") || loweredMime.includes("csv")) {
    return "spreadsheet";
  }
  if (DOCUMENT_EXTENSIONS.has(loweredExtension) || loweredMime.startsWith("text/")) {
    return "document";
  }
  return "download";
}
function resourceDerivedState(resource) {
  const extension = fileExtension(resource.filename || filenameFromUrl(resource.url));
  return {
    extension,
    parserHint: inferParserHint(resource.url, resource.mime, extension),
    deliveryTarget: inferDeliveryTarget(resource.url),
    mediaKind: inferResourceMediaKind(resource, extension)
  };
}
function resourcePrimaryBadge(resource, derived = resourceDerivedState(resource)) {
  if (derived.parserHint === "m3u8") {
    return "M3U8";
  }
  if (derived.parserHint === "mpd") {
    return "MPD";
  }
  if (derived.extension) {
    return derived.extension.slice(0, 6).toUpperCase();
  }
  if (resource.mime.startsWith("audio/")) {
    return "\u97F3\u9891";
  }
  if (resource.mime.startsWith("video/")) {
    return "\u89C6\u9891";
  }
  return "\u8D44\u6E90";
}
function describeResource(resource) {
  const derived = resourceDerivedState(resource);
  const mime = String(resource.mime || "").toLowerCase();
  let category = "all";
  if (derived.parserHint === "m3u8" || derived.parserHint === "mpd") {
    category = "streaming";
  } else if (derived.mediaKind === "audio") {
    category = "audio";
  } else if (derived.mediaKind === "video") {
    category = "video";
  }
  const primaryBadge = resourcePrimaryBadge(resource, derived);
  const needsDesktop = derived.deliveryTarget === "gd3";
  const statusText = resource.sentToDesktopAt ? needsDesktop ? "\u5DF2\u53D1\u9001\u5230 Ghost Downloader" : "\u5DF2\u4EA4\u7ED9\u6D4F\u89C8\u5668\u4E0B\u8F7D" : needsDesktop ? "\u53D1\u9001\u5230 Ghost Downloader" : "\u6D4F\u89C8\u5668\u4E0B\u8F7D";
  const tags = [primaryBadge];
  tags.push(derived.deliveryTarget === "browser_download" ? "\u6D4F\u89C8\u5668\u4E0B\u8F7D" : "GD3");
  if (!resource.sentToDesktopAt && (derived.parserHint === "m3u8" || derived.parserHint === "mpd")) {
    tags.push("\u6D41\u5A92\u4F53");
  }
  if (!resource.sentToDesktopAt && resource.requestHeaders && Object.keys(resource.requestHeaders).length > 0 && (derived.parserHint === "m3u8" || derived.parserHint === "mpd")) {
    tags.push("\u9700\u8BF7\u6C42\u5934");
  }
  if (!resource.sentToDesktopAt && (derived.parserHint === "download" || derived.parserHint === "media")) {
    tags.push("\u53EF\u76F4\u63A5\u4E0B\u8F7D");
  }
  const visual = {
    kind: inferVisualKind({
      extension: derived.extension,
      mime,
      parserHint: derived.parserHint
    })
  };
  return {
    extension: derived.extension,
    parserHint: derived.parserHint,
    deliveryTarget: derived.deliveryTarget,
    category,
    primaryBadge,
    statusText,
    actionLabel: needsDesktop ? "\u53D1\u9001\u5230 Ghost Downloader" : "\u6D4F\u89C8\u5668\u4E0B\u8F7D",
    needsDesktop,
    tags,
    visual
  };
}
function canUseOnlineMerge(resource) {
  const derived = resourceDerivedState(resource);
  if (derived.deliveryTarget !== "gd3") {
    return false;
  }
  if (derived.parserHint === "m3u8") {
    return true;
  }
  const mime = String(resource.mime || "").toLowerCase();
  if (!mime) {
    return CAT_CATCH_MEDIA_EXTENSIONS.has(derived.extension);
  }
  return CAT_CATCH_MEDIA_EXTENSIONS.has(derived.extension) || mime.startsWith("video") || mime.startsWith("audio") || mime.endsWith("octet-stream");
}
function canUseOnlineMergeSelection(resources) {
  if (resources.length !== 2) {
    return false;
  }
  const allM3U8 = resources.every((resource) => describeResource(resource).parserHint === "m3u8");
  if (allM3U8) {
    return resources.every((resource) => describeResource(resource).deliveryTarget === "gd3");
  }
  return resources.every(canUseOnlineMerge);
}
function sortResourcesForOnlineMerge(resources) {
  return [...resources].sort((left, right) => {
    const leftCategory = describeResource(left).category;
    const rightCategory = describeResource(right).category;
    if (leftCategory === rightCategory) {
      return 0;
    }
    if (leftCategory === "video") {
      return -1;
    }
    if (rightCategory === "video") {
      return 1;
    }
    return 0;
  });
}

// src/background/media-bridge.ts
function createMediaBridge() {
  let mediaControlTarget = { tabId: 0, index: -1, frameId: MAIN_FRAME_ID };
  let mediaInventory = /* @__PURE__ */ new Map();
  let mediaInventoryScannedAt = 0;
  let mediaInventoryReady = false;
  let mediaPanelInitialized = false;
  let lastMediaPanelState = createEmptyMediaPanelState("");
  const mediaFailureCounts = /* @__PURE__ */ new Map();
  const cachedMediaSnapshots = /* @__PURE__ */ new Map();
  function sleep(ms) {
    return new Promise((resolve) => {
      self.setTimeout(resolve, ms);
    });
  }
  function isCapturableUrl(rawUrl) {
    return /^https?:/i.test(rawUrl);
  }
  function isCapturableTab(tab) {
    return Boolean(tab?.url && isCapturableUrl(tab.url));
  }
  function createEmptyPlaybackState(message = "\u5F53\u524D\u672A\u68C0\u6D4B\u5230\u53EF\u63A7\u5236\u5A92\u4F53") {
    return {
      available: false,
      stale: false,
      message,
      tabId: null,
      mediaIndex: -1,
      frameId: MAIN_FRAME_ID,
      count: 0,
      currentTime: 0,
      duration: 0,
      progress: 0,
      volume: 1,
      paused: true,
      loop: false,
      muted: false,
      speed: 1,
      mediaType: ""
    };
  }
  function createEmptyMediaPanelState(message) {
    return {
      mediaTabs: [],
      mediaItems: [],
      selectedMediaTabId: null,
      selectedMediaIndex: -1,
      playbackState: createEmptyPlaybackState(message)
    };
  }
  function shortMediaLabel(src) {
    const candidate = filenameFromUrl(src) || src.split("/").pop() || src;
    return shorten(candidate, 48);
  }
  function normalizeMediaType(type) {
    return type === "audio" ? "audio" : "video";
  }
  function createMediaItems(srcList, count, mediaType) {
    return Array.from({ length: count }, (_unused, index) => ({
      index,
      label: shortMediaLabel(srcList[index] ?? `${mediaType}-${index + 1}`),
      type: mediaType
    }));
  }
  function mediaTabsFromInventory() {
    return [...mediaInventory.values()].sort((left, right) => left.title.localeCompare(right.title)).map((entry) => ({
      tabId: entry.tabId,
      title: entry.title,
      domain: entry.domain
    }));
  }
  function chooseMediaTabId(activeTabId) {
    if (mediaControlTarget.tabId > 0 && mediaInventory.has(mediaControlTarget.tabId)) {
      return mediaControlTarget.tabId;
    }
    if (activeTabId != null && mediaInventory.has(activeTabId)) {
      return activeTabId;
    }
    return mediaTabsFromInventory()[0]?.tabId ?? 0;
  }
  function mediaFailureMessage(result) {
    if (!result) {
      return "\u5F53\u524D\u5A92\u4F53\u72B6\u6001\u6682\u65F6\u4E0D\u53EF\u8BFB";
    }
    switch (result.status) {
      case "no_receiver":
        return "\u5F53\u524D\u9875\u9762\u7684\u5A92\u4F53\u6865\u63A5\u8FD8\u6CA1\u6709\u51C6\u5907\u597D";
      case "runtime_error":
        return result.message || "\u8BFB\u53D6\u5A92\u4F53\u72B6\u6001\u5931\u8D25";
      case "no_response":
        return "\u9875\u9762\u6CA1\u6709\u8FD4\u56DE\u5A92\u4F53\u72B6\u6001";
      default:
        return "\u5F53\u524D\u9875\u9762\u672A\u68C0\u6D4B\u5230\u53EF\u63A7\u5236\u5A92\u4F53";
    }
  }
  function responseHasExplicitFailure(response) {
    if (!response || typeof response !== "object" || !("ok" in response)) {
      return null;
    }
    if (response.ok !== false) {
      return null;
    }
    return String(response.message ?? "\u9875\u9762\u64CD\u4F5C\u5931\u8D25");
  }
  async function requestMediaState(tabId, index) {
    return sendMessageToTab(
      tabId,
      {
        Message: "getVideoState",
        index
      },
      { frameId: MAIN_FRAME_ID }
    );
  }
  async function scanMediaTabs(force = false) {
    if (!force && mediaInventoryReady && Date.now() - mediaInventoryScannedAt < MEDIA_SCAN_INTERVAL_MS) {
      return;
    }
    const tabs = await queryTabs({ windowType: "normal" });
    const next = /* @__PURE__ */ new Map();
    for (const tab of tabs) {
      if (!tab.id || !isCapturableTab(tab)) {
        continue;
      }
      const result = await requestMediaState(tab.id, 0);
      if (result.status !== "ok" || !result.response?.count) {
        continue;
      }
      const state = result.response;
      next.set(tab.id, {
        tabId: tab.id,
        title: tab.title || "\u672A\u547D\u540D\u6807\u7B7E\u9875",
        domain: domainFromUrl(tab.url || ""),
        count: Number(state.count ?? 0),
        src: Array.isArray(state.src) ? state.src : [],
        mediaType: normalizeMediaType(state.type)
      });
    }
    mediaInventory = next;
    mediaInventoryReady = true;
    mediaInventoryScannedAt = Date.now();
  }
  async function hydrateMediaSnapshot(tabId, index) {
    const result = await requestMediaState(tabId, index >= 0 ? index : 0);
    if (result.status !== "ok") {
      return {
        ok: false,
        message: mediaFailureMessage(result),
        status: result.status
      };
    }
    const state = result.response;
    if (!state?.count) {
      return {
        ok: false,
        message: "\u5F53\u524D\u9875\u9762\u672A\u68C0\u6D4B\u5230\u53EF\u63A7\u5236\u5A92\u4F53",
        status: "ok"
      };
    }
    const count = Number(state.count ?? 0);
    const selectedIndex = index >= 0 && index < count ? index : 0;
    const srcList = Array.isArray(state.src) ? state.src : [];
    const mediaType = normalizeMediaType(state.type);
    const mediaItems = createMediaItems(srcList, count, mediaType);
    const playbackState = {
      available: true,
      stale: false,
      message: "",
      tabId,
      mediaIndex: selectedIndex,
      frameId: MAIN_FRAME_ID,
      count,
      currentTime: Number(state.currentTime ?? 0),
      duration: Number(state.duration ?? 0),
      progress: Number(state.time ?? 0),
      volume: Number(state.volume ?? 1),
      paused: Boolean(state.paused ?? true),
      loop: Boolean(state.loop ?? false),
      muted: Boolean(state.muted ?? false),
      speed: Number(state.speed ?? 1),
      mediaType
    };
    const tab = await getTab(tabId);
    return {
      ok: true,
      selectedIndex,
      mediaItems,
      playbackState,
      entry: {
        tabId,
        title: tab?.title || "\u672A\u547D\u540D\u6807\u7B7E\u9875",
        domain: domainFromUrl(tab?.url || ""),
        count,
        src: srcList,
        mediaType
      }
    };
  }
  function cacheMediaSnapshot(tabId, mediaItems, playbackState) {
    cachedMediaSnapshots.set(tabId, {
      mediaItems,
      playbackState: { ...playbackState, stale: false, message: "" },
      updatedAt: Date.now()
    });
  }
  async function loadPersistentState() {
    const localState = await localStorageGet({
      [MEDIA_TARGET_KEY]: { tabId: 0, index: -1, frameId: MAIN_FRAME_ID }
    });
    mediaControlTarget = {
      tabId: Number(localState[MEDIA_TARGET_KEY]?.tabId ?? 0),
      index: Number(localState[MEDIA_TARGET_KEY]?.index ?? -1),
      frameId: MAIN_FRAME_ID
    };
  }
  async function buildPanelState(activeTabId, options = {}) {
    if (options.refreshInventory || !mediaInventoryReady || Date.now() - mediaInventoryScannedAt >= MEDIA_SCAN_INTERVAL_MS) {
      await scanMediaTabs(Boolean(options.refreshInventory));
    }
    let selectedMediaTabId = chooseMediaTabId(activeTabId);
    let selectedMediaIndex = mediaControlTarget.index;
    let mediaTabs = mediaTabsFromInventory();
    if (!selectedMediaTabId) {
      const empty = createEmptyMediaPanelState(mediaInventoryReady ? "\u5F53\u524D\u672A\u68C0\u6D4B\u5230\u53EF\u63A7\u5236\u5A92\u4F53" : "\u6B63\u5728\u6062\u590D\u5A92\u4F53\u72B6\u6001");
      lastMediaPanelState = { ...empty, mediaTabs };
      mediaPanelInitialized = true;
      return lastMediaPanelState;
    }
    const shouldRefreshTarget = options.refreshTarget || !mediaPanelInitialized || lastMediaPanelState.selectedMediaTabId !== selectedMediaTabId || lastMediaPanelState.selectedMediaIndex !== selectedMediaIndex;
    if (!shouldRefreshTarget) {
      const reused = {
        ...lastMediaPanelState,
        mediaTabs
      };
      lastMediaPanelState = reused;
      mediaPanelInitialized = true;
      return reused;
    }
    let snapshot = await hydrateMediaSnapshot(selectedMediaTabId, selectedMediaIndex);
    if (!snapshot.ok) {
      const failures = (mediaFailureCounts.get(selectedMediaTabId) ?? 0) + 1;
      mediaFailureCounts.set(selectedMediaTabId, failures);
      const cached = cachedMediaSnapshots.get(selectedMediaTabId);
      if (cached && failures < MEDIA_FAILURE_THRESHOLD) {
        const staleState = {
          mediaTabs,
          mediaItems: cached.mediaItems,
          selectedMediaTabId,
          selectedMediaIndex: cached.playbackState.mediaIndex,
          playbackState: {
            ...cached.playbackState,
            stale: true,
            message: snapshot.message
          }
        };
        lastMediaPanelState = staleState;
        mediaPanelInitialized = true;
        return staleState;
      }
      await scanMediaTabs(true);
      mediaTabs = mediaTabsFromInventory();
      selectedMediaTabId = chooseMediaTabId(activeTabId);
      selectedMediaIndex = mediaControlTarget.index;
      if (!selectedMediaTabId) {
        const empty = createEmptyMediaPanelState(snapshot.message);
        lastMediaPanelState = { ...empty, mediaTabs };
        mediaPanelInitialized = true;
        return lastMediaPanelState;
      }
      snapshot = await hydrateMediaSnapshot(selectedMediaTabId, selectedMediaIndex);
      if (!snapshot.ok) {
        const empty = createEmptyMediaPanelState(snapshot.message);
        lastMediaPanelState = { ...empty, mediaTabs, selectedMediaTabId, selectedMediaIndex };
        mediaPanelInitialized = true;
        return lastMediaPanelState;
      }
    }
    mediaFailureCounts.delete(selectedMediaTabId);
    selectedMediaIndex = snapshot.selectedIndex;
    mediaInventory.set(selectedMediaTabId, snapshot.entry);
    mediaTabs = mediaTabsFromInventory();
    cacheMediaSnapshot(selectedMediaTabId, snapshot.mediaItems, snapshot.playbackState);
    const nextState = {
      mediaTabs,
      mediaItems: snapshot.mediaItems,
      selectedMediaTabId,
      selectedMediaIndex,
      playbackState: snapshot.playbackState
    };
    if (mediaControlTarget.tabId !== selectedMediaTabId || mediaControlTarget.index !== selectedMediaIndex || mediaControlTarget.frameId !== MAIN_FRAME_ID) {
      mediaControlTarget = {
        tabId: selectedMediaTabId,
        index: selectedMediaIndex,
        frameId: MAIN_FRAME_ID
      };
      await localStorageSet({ [MEDIA_TARGET_KEY]: mediaControlTarget });
    }
    lastMediaPanelState = nextState;
    mediaPanelInitialized = true;
    return nextState;
  }
  async function setMediaTarget(tabId, index) {
    mediaControlTarget = {
      tabId,
      index,
      frameId: MAIN_FRAME_ID
    };
    mediaInventoryScannedAt = 0;
    await localStorageSet({ [MEDIA_TARGET_KEY]: mediaControlTarget });
  }
  async function performAction(action, value) {
    const tabId = mediaControlTarget.tabId;
    const index = mediaControlTarget.index;
    if (!tabId || index < 0) {
      return { ok: false, message: "\u5F53\u524D\u6CA1\u6709\u53EF\u63A7\u5236\u7684\u5A92\u4F53" };
    }
    const payload = { index };
    switch (action) {
      case "toggle_play": {
        const stateResult = await requestMediaState(tabId, index);
        if (stateResult.status === "ok" && stateResult.response?.count) {
          payload.Message = stateResult.response.paused ? "play" : "pause";
        } else {
          const cached = cachedMediaSnapshots.get(tabId);
          if (!cached) {
            return { ok: false, message: mediaFailureMessage(stateResult) };
          }
          payload.Message = cached.playbackState.paused ? "play" : "pause";
        }
        break;
      }
      case "set_speed":
        payload.Message = "speed";
        payload.speed = Number(value ?? 1);
        break;
      case "pip":
        payload.Message = "pip";
        break;
      case "fullscreen":
        payload.Message = "fullScreen";
        await activateTab(tabId);
        await sleep(120);
        break;
      case "screenshot":
        payload.Message = "screenshot";
        break;
      case "toggle_loop":
        payload.Message = "loop";
        payload.action = Boolean(value);
        break;
      case "toggle_muted":
        payload.Message = "muted";
        payload.action = Boolean(value);
        break;
      case "set_volume":
        payload.Message = "setVolume";
        payload.volume = Number(value ?? 1);
        break;
      case "set_time":
        payload.Message = "setTime";
        payload.time = Number(value ?? 0);
        break;
      default:
        return { ok: false, message: "\u672A\u77E5\u7684\u5A92\u4F53\u64CD\u4F5C" };
    }
    const result = await sendMessageToTab(tabId, payload, { frameId: MAIN_FRAME_ID });
    if (result.status !== "ok") {
      return { ok: false, message: mediaFailureMessage(result) };
    }
    const responseError = responseHasExplicitFailure(result.response);
    if (responseError) {
      return { ok: false, message: responseError };
    }
    return { ok: true };
  }
  function handleTabRemoved(tabId) {
    mediaInventory.delete(tabId);
    mediaFailureCounts.delete(tabId);
    cachedMediaSnapshots.delete(tabId);
    if (mediaControlTarget.tabId === tabId) {
      mediaControlTarget = { tabId: 0, index: -1, frameId: MAIN_FRAME_ID };
      void localStorageSet({ [MEDIA_TARGET_KEY]: mediaControlTarget });
      lastMediaPanelState = createEmptyMediaPanelState("\u5F53\u524D\u672A\u68C0\u6D4B\u5230\u53EF\u63A7\u5236\u5A92\u4F53");
      mediaPanelInitialized = false;
    }
  }
  function handleNavigationCommitted(details) {
    if (details.tabId <= 0 || details.frameId !== MAIN_FRAME_ID) {
      return;
    }
    mediaFailureCounts.delete(details.tabId);
    cachedMediaSnapshots.delete(details.tabId);
    if (mediaControlTarget.tabId === details.tabId) {
      mediaInventory.delete(details.tabId);
      mediaInventoryScannedAt = 0;
    }
  }
  return {
    buildPanelState,
    getLastPanelState: () => lastMediaPanelState,
    handleNavigationCommitted,
    handleTabRemoved,
    loadPersistentState,
    performAction,
    setMediaTarget
  };
}

// src/background/resource-bridge.ts
var HEADER_WHITELIST = /* @__PURE__ */ new Set(["referer", "origin", "cookie", "authorization"]);
var DIRECT_MEDIA_EXTENSIONS = /* @__PURE__ */ new Set([
  "mp4",
  "mkv",
  "webm",
  "mp3",
  "flac",
  "wav",
  "m4a",
  "mov",
  "m4s",
  "ts",
  "flv",
  "aac",
  "ogg",
  "opus"
]);
var DOWNLOAD_EXTENSIONS = /* @__PURE__ */ new Set(["zip", "7z", "rar", "pdf", "exe", "msi", "dmg", "pkg", "apk", "iso"]);
function createResourceBridge(options) {
  let bridgePersistTimer = null;
  let bridgeStateReady = false;
  let lastActiveTabId = null;
  const resourceCache = /* @__PURE__ */ new Map();
  const resourcesById = /* @__PURE__ */ new Map();
  const headersByRequestId = /* @__PURE__ */ new Map();
  const rangeRequestIds = /* @__PURE__ */ new Set();
  const headerSnapshotsByUrl = /* @__PURE__ */ new Map();
  function normalizeHeaders(headers) {
    const result = {};
    for (const [key, value] of Object.entries(headers ?? {})) {
      const name = String(key || "").trim().toLowerCase();
      if (!HEADER_WHITELIST.has(name)) {
        continue;
      }
      const text = String(value ?? "").trim();
      if (!text) {
        continue;
      }
      result[name] = text;
    }
    return result;
  }
  function parseHeaderList(headers) {
    const result = {};
    for (const header of headers ?? []) {
      if (!header.name) {
        continue;
      }
      const name = header.name.toLowerCase();
      if (!HEADER_WHITELIST.has(name)) {
        continue;
      }
      const value = String(header.value ?? "").trim();
      if (!value) {
        continue;
      }
      result[name] = value;
    }
    return result;
  }
  function hasRangeHeader(headers) {
    return (headers ?? []).some((header) => {
      if (!header.name) {
        return false;
      }
      if (header.name.toLowerCase() !== "range") {
        return false;
      }
      const value = String(header.value ?? "").toLowerCase();
      return value.startsWith("bytes=");
    });
  }
  function trimFilename(value) {
    const text = String(value || "").trim();
    if (!text) {
      return "";
    }
    const slashIndex = Math.max(text.lastIndexOf("/"), text.lastIndexOf("\\"));
    return slashIndex >= 0 ? text.slice(slashIndex + 1) : text;
  }
  function isCapturableUrl(rawUrl) {
    return /^https?:/i.test(rawUrl);
  }
  function isBridgeResourceUrl(rawUrl) {
    return /^(https?:|blob:)/i.test(rawUrl);
  }
  function isCapturableTab(tab) {
    return Boolean(tab?.url && isCapturableUrl(tab.url));
  }
  function sortResources(resources) {
    return [...resources].sort((left, right) => right.capturedAt - left.capturedAt);
  }
  function normalizeUrl(value, allowBlob = false) {
    const text = String(value || "").trim();
    if (!text) {
      return "";
    }
    if (allowBlob && text.startsWith("blob:")) {
      return text;
    }
    try {
      const url = new URL(text);
      url.hash = "";
      return url.toString();
    } catch {
      return text.split("#", 1)[0] ?? text;
    }
  }
  function normalizeResourceUrl(value) {
    return normalizeUrl(value, true);
  }
  function normalizeCapturedResource(resource) {
    return {
      id: String(resource.id ?? ""),
      tabId: Number(resource.tabId),
      url: String(resource.url ?? ""),
      pageTitle: String(resource.pageTitle ?? ""),
      pageUrl: String(resource.pageUrl ?? ""),
      filename: String(resource.filename ?? ""),
      mime: String(resource.mime ?? "").toLowerCase(),
      size: Number(resource.size ?? 0),
      supportsRange: Boolean(resource.supportsRange),
      referer: String(resource.referer ?? ""),
      requestHeaders: normalizeHeaders(resource.requestHeaders),
      capturedAt: Number(resource.capturedAt ?? Date.now()),
      sentToDesktopAt: resource.sentToDesktopAt ? Number(resource.sentToDesktopAt) : void 0
    };
  }
  function normalizeBridgeHeaderSnapshot(snapshot) {
    return {
      url: String(snapshot.url ?? ""),
      headers: normalizeHeaders(snapshot.headers),
      capturedAt: Number(snapshot.capturedAt ?? Date.now()),
      tabId: Number.isInteger(snapshot.tabId) ? Number(snapshot.tabId) : null,
      supportsRange: Boolean(snapshot.supportsRange)
    };
  }
  function getResponseHeadersValue(headers) {
    const meta = {
      size: 0,
      type: "",
      attachment: "",
      supportsRange: false
    };
    for (const header of headers ?? []) {
      if (!header.name) {
        continue;
      }
      const name = header.name.toLowerCase();
      if (name === "content-length") {
        const size = Number.parseInt(String(header.value ?? ""), 10);
        if (meta.size <= 0 && Number.isFinite(size) && size > 0) {
          meta.size = size;
        }
        continue;
      }
      if (name === "content-type") {
        const type = String(header.value ?? "").split(";")[0]?.trim().toLowerCase() ?? "";
        if (type) {
          meta.type = type;
        }
        continue;
      }
      if (name === "content-disposition") {
        meta.attachment = String(header.value ?? "").trim();
        continue;
      }
      if (name === "accept-ranges") {
        const value = String(header.value ?? "").toLowerCase();
        if (value.includes("bytes")) {
          meta.supportsRange = true;
        } else if (value.includes("none")) {
          meta.supportsRange = false;
        }
        continue;
      }
      if (name === "content-range") {
        const size = String(header.value ?? "").split("/")[1];
        if (size && size !== "*") {
          const totalSize = Number.parseInt(size, 10);
          if (Number.isFinite(totalSize) && totalSize > 0) {
            meta.size = totalSize;
          }
        }
        meta.supportsRange = true;
      }
    }
    return meta;
  }
  function filenameFromContentDisposition(value) {
    if (!value) {
      return "";
    }
    const utf8Match = /filename\*\s*=\s*UTF-8''([^;]+)/i.exec(value);
    if (utf8Match?.[1]) {
      try {
        return trimFilename(decodeURIComponent(utf8Match[1].trim().replace(/^"|"$/g, "")));
      } catch {
        return trimFilename(utf8Match[1].trim().replace(/^"|"$/g, ""));
      }
    }
    const quotedMatch = /filename\s*=\s*"([^"]+)"/i.exec(value);
    if (quotedMatch?.[1]) {
      return trimFilename(quotedMatch[1]);
    }
    const plainMatch = /filename\s*=\s*([^;]+)/i.exec(value);
    if (plainMatch?.[1]) {
      return trimFilename(plainMatch[1].trim().replace(/^"|"$/g, ""));
    }
    return "";
  }
  function urlsLikelySamePage(left, right) {
    const normalizedLeft = normalizeUrl(left);
    const normalizedRight = normalizeUrl(right);
    if (!normalizedLeft || !normalizedRight) {
      return false;
    }
    return normalizedLeft === normalizedRight || normalizedLeft.startsWith(normalizedRight) || normalizedRight.startsWith(normalizedLeft);
  }
  async function resolveTabIdFromPageUrl(pageUrl) {
    const normalizedPageUrl = normalizeUrl(pageUrl);
    if (!normalizedPageUrl) {
      return null;
    }
    const tabs = await queryTabs({});
    const exactMatch = tabs.find((tab) => tab.id && tab.url && urlsLikelySamePage(tab.url, normalizedPageUrl));
    if (exactMatch?.id) {
      return exactMatch.id;
    }
    try {
      const initiatorUrl = new URL(normalizedPageUrl);
      const originMatch = tabs.find((tab) => {
        if (!tab.id || !tab.url) {
          return false;
        }
        try {
          return new URL(tab.url).origin === initiatorUrl.origin;
        } catch {
          return false;
        }
      });
      if (originMatch?.id) {
        return originMatch.id;
      }
    } catch {
    }
    return null;
  }
  function shouldCaptureCatCatchResponse(details, responseMeta) {
    if (!isCapturableUrl(details.url)) {
      return false;
    }
    const extension = fileExtension(filenameFromContentDisposition(responseMeta.attachment) || filenameFromUrl(details.url));
    if (details.type === "media") {
      return true;
    }
    if (extension === "m3u8" || extension === "m3u" || extension === "mpd") {
      return true;
    }
    if (DIRECT_MEDIA_EXTENSIONS.has(extension) || DOWNLOAD_EXTENSIONS.has(extension)) {
      return true;
    }
    if (responseMeta.type.startsWith("video/") || responseMeta.type.startsWith("audio/")) {
      return true;
    }
    if (responseMeta.type.includes("mpegurl") || responseMeta.type === "application/dash+xml") {
      return true;
    }
    return Boolean(filenameFromContentDisposition(responseMeta.attachment));
  }
  function resolveNetworkResourceFilename(rawUrl, responseMeta) {
    const fromDisposition = filenameFromContentDisposition(responseMeta.attachment);
    if (fromDisposition) {
      return fromDisposition;
    }
    const fromUrl = trimFilename(filenameFromUrl(rawUrl) || "");
    if (fromUrl) {
      return fromUrl;
    }
    if (responseMeta.type.includes("mpegurl")) {
      return "resource.m3u8";
    }
    if (responseMeta.type === "application/dash+xml") {
      return "resource.mpd";
    }
    return "resource";
  }
  async function persistBridgeState() {
    bridgePersistTimer = null;
    pruneHeaderSnapshots();
    await bridgeStorageSet({
      [BRIDGE_RESOURCE_CACHE_KEY]: serializeResourceCache(),
      [BRIDGE_HEADER_SNAPSHOTS_KEY]: [...headerSnapshotsByUrl.values()],
      [BRIDGE_LAST_ACTIVE_TAB_KEY]: lastActiveTabId ?? 0
    });
  }
  function scheduleBridgeStatePersist() {
    if (bridgePersistTimer !== null) {
      return;
    }
    bridgePersistTimer = self.setTimeout(() => {
      void persistBridgeState();
    }, BRIDGE_PERSIST_DEBOUNCE_MS);
  }
  function serializeResourceCache() {
    const result = {};
    for (const [tabId, bucket] of resourceCache.entries()) {
      result[String(tabId)] = sortResources(bucket.values()).slice(0, RESOURCE_LIMIT);
    }
    return result;
  }
  function pruneHeaderSnapshots() {
    const now = Date.now();
    const snapshots = [...headerSnapshotsByUrl.values()].map((snapshot) => normalizeBridgeHeaderSnapshot(snapshot)).filter((snapshot) => snapshot.url && now - snapshot.capturedAt <= HEADER_EXPIRATION_MS).sort((left, right) => right.capturedAt - left.capturedAt).slice(0, HEADER_SNAPSHOT_LIMIT);
    headerSnapshotsByUrl.clear();
    for (const snapshot of snapshots) {
      headerSnapshotsByUrl.set(snapshot.url, snapshot);
    }
  }
  function clearResourcesForTab(tabId) {
    const bucket = resourceCache.get(tabId);
    if (!bucket) {
      return;
    }
    for (const resourceId of bucket.keys()) {
      resourcesById.delete(resourceId);
    }
    resourceCache.delete(tabId);
    scheduleBridgeStatePersist();
  }
  function clearHeaderSnapshotsForTab(tabId) {
    let changed = false;
    for (const [url, snapshot] of headerSnapshotsByUrl.entries()) {
      if (snapshot.tabId === tabId) {
        headerSnapshotsByUrl.delete(url);
        changed = true;
      }
    }
    if (changed) {
      scheduleBridgeStatePersist();
    }
  }
  async function setLastActiveTab(tabId) {
    if (lastActiveTabId === tabId) {
      return;
    }
    lastActiveTabId = tabId;
    scheduleBridgeStatePersist();
  }
  async function refreshActiveTabFromBrowser() {
    const tabs = await queryTabs({ active: true, currentWindow: true });
    const tabId = tabs[0]?.id ?? null;
    await setLastActiveTab(tabId);
    return tabId;
  }
  async function resolveActiveTabId(preferredTabId = null) {
    if (preferredTabId != null) {
      const preferredTab = await getTab(preferredTabId);
      if (preferredTab?.id) {
        await setLastActiveTab(preferredTab.id);
        return preferredTab.id;
      }
    }
    if (lastActiveTabId != null) {
      const current = await getTab(lastActiveTabId);
      if (current?.id) {
        return current.id;
      }
    }
    return refreshActiveTabFromBrowser();
  }
  function filenameWithExtension(baseName, extension) {
    const trimmedBaseName = trimFilename(baseName || "") || "resource";
    const normalizedExt = String(extension || "").trim().replace(/^\./, "").toLowerCase();
    if (!normalizedExt) {
      return trimmedBaseName;
    }
    if (fileExtension(trimmedBaseName) === normalizedExt) {
      return trimmedBaseName;
    }
    return `${trimmedBaseName}.${normalizedExt}`;
  }
  function resolveBridgeFilename(payload) {
    const explicit = trimFilename(payload.filename || "");
    if (explicit) {
      return explicit;
    }
    const fromUrl = trimFilename(filenameFromUrl(payload.url) || "");
    const ext = String(payload.ext || "").trim();
    if (fromUrl) {
      return ext ? filenameWithExtension(fromUrl, ext) : fromUrl;
    }
    return ext ? filenameWithExtension("resource", ext) : "resource";
  }
  async function resolveBridgeResourceTabId(sender, href) {
    const normalizedHref = String(href ?? "").trim();
    if (normalizedHref) {
      const matchedTabId = await resolveTabIdFromPageUrl(normalizedHref);
      if (matchedTabId != null) {
        return matchedTabId;
      }
    }
    if (sender.tab?.id) {
      return sender.tab.id;
    }
    return resolveActiveTabId();
  }
  async function resolveNetworkResourceTabId(details) {
    if (details.tabId > 0) {
      return details.tabId;
    }
    const snapshotTabId = headerSnapshotsByUrl.get(details.url)?.tabId;
    if (snapshotTabId != null) {
      return snapshotTabId;
    }
    const matchedTabId = await resolveTabIdFromPageUrl(details.initiator ?? "");
    if (matchedTabId != null) {
      return matchedTabId;
    }
    return resolveActiveTabId();
  }
  function buildResourceId(tabId, url) {
    return `${tabId}:${normalizeResourceUrl(url)}`;
  }
  function bucketForTab(tabId) {
    const existing = resourceCache.get(tabId);
    if (existing) {
      return existing;
    }
    const bucket = /* @__PURE__ */ new Map();
    resourceCache.set(tabId, bucket);
    return bucket;
  }
  function trimBucket(tabId) {
    const bucket = resourceCache.get(tabId);
    if (!bucket || bucket.size <= RESOURCE_LIMIT) {
      return;
    }
    const keepIds = new Set(sortResources(bucket.values()).slice(0, RESOURCE_LIMIT).map((resource) => resource.id));
    for (const resourceId of bucket.keys()) {
      if (keepIds.has(resourceId)) {
        continue;
      }
      bucket.delete(resourceId);
      resourcesById.delete(resourceId);
    }
  }
  function cacheResource(resource) {
    const normalized = normalizeCapturedResource(resource);
    const bucket = bucketForTab(normalized.tabId);
    const existing = bucket.get(normalized.id);
    const merged = existing ? {
      ...existing,
      ...normalized,
      pageTitle: normalized.pageTitle || existing.pageTitle,
      pageUrl: normalized.pageUrl || existing.pageUrl,
      filename: normalized.filename || existing.filename,
      mime: normalized.mime || existing.mime,
      size: normalized.size > 0 ? normalized.size : existing.size,
      supportsRange: normalized.supportsRange || existing.supportsRange,
      referer: normalized.referer || existing.referer,
      requestHeaders: Object.keys(normalized.requestHeaders).length > 0 ? normalized.requestHeaders : existing.requestHeaders,
      capturedAt: Math.max(existing.capturedAt, normalized.capturedAt),
      sentToDesktopAt: existing.sentToDesktopAt ?? normalized.sentToDesktopAt
    } : normalized;
    bucket.set(merged.id, merged);
    resourcesById.set(merged.id, merged);
    trimBucket(normalized.tabId);
    scheduleBridgeStatePersist();
  }
  function findResourceById(resourceId) {
    return resourcesById.get(resourceId) ?? null;
  }
  function findResourceByUrl(rawUrl) {
    const normalizedUrl = normalizeResourceUrl(rawUrl);
    let matched = null;
    for (const resource of resourcesById.values()) {
      if (normalizeResourceUrl(resource.url) !== normalizedUrl) {
        continue;
      }
      if (matched == null || resource.capturedAt > matched.capturedAt) {
        matched = resource;
      }
    }
    return matched;
  }
  function markResourceSent(resourceId) {
    const resource = resourcesById.get(resourceId);
    if (!resource) {
      return;
    }
    resource.sentToDesktopAt = Date.now();
    scheduleBridgeStatePersist();
  }
  function rememberHeaderSnapshot(url, headers, tabId, supportsRange) {
    const normalized = normalizeHeaders(headers);
    if (Object.keys(normalized).length === 0 && !supportsRange) {
      return;
    }
    headerSnapshotsByUrl.set(url, {
      url,
      headers: normalized,
      capturedAt: Date.now(),
      tabId,
      supportsRange
    });
    pruneHeaderSnapshots();
    scheduleBridgeStatePersist();
  }
  function resolveHeaderSnapshot(url) {
    pruneHeaderSnapshots();
    return headerSnapshotsByUrl.get(url) ?? null;
  }
  function resolveHeadersForDownload(url) {
    return { ...resolveHeaderSnapshot(url)?.headers ?? {} };
  }
  function otherResourcesForTab(activeTabId) {
    const result = [];
    for (const [tabId, bucket] of resourceCache.entries()) {
      if (activeTabId != null && tabId === activeTabId) {
        continue;
      }
      result.push(...bucket.values());
    }
    return sortResources(result);
  }
  function deriveMergeOutputTitle(resources) {
    const pageTitle = String(resources[0]?.pageTitle || "").trim();
    if (pageTitle) {
      return pageTitle;
    }
    const firstFileName = trimFilename(resources[0]?.filename || filenameFromUrl(resources[0]?.url || ""));
    if (firstFileName) {
      const extension = fileExtension(firstFileName);
      return extension ? firstFileName.slice(0, -(extension.length + 1)) : firstFileName;
    }
    return "merged-media";
  }
  async function downloadResourceViaBrowser(resource) {
    const filename = resolveBridgeFilename({
      url: resource.url,
      filename: resource.filename
    });
    return new Promise((resolve, reject) => {
      chrome.downloads.download(
        {
          url: resource.url,
          filename
        },
        (downloadId) => {
          const lastError = chrome.runtime.lastError;
          if (lastError) {
            reject(new Error(lastError.message));
            return;
          }
          if (typeof downloadId !== "number") {
            reject(new Error("\u6D4F\u89C8\u5668\u672A\u8FD4\u56DE\u4E0B\u8F7D\u4EFB\u52A1"));
            return;
          }
          resolve();
        }
      );
    });
  }
  async function loadPersistentState() {
    const bridgeState = await bridgeStorageGet({
      [BRIDGE_RESOURCE_CACHE_KEY]: {},
      [BRIDGE_HEADER_SNAPSHOTS_KEY]: [],
      [BRIDGE_LAST_ACTIVE_TAB_KEY]: 0
    });
    resourceCache.clear();
    resourcesById.clear();
    for (const [tabIdText, resources] of Object.entries(bridgeState[BRIDGE_RESOURCE_CACHE_KEY] ?? {})) {
      const tabId = Number(tabIdText);
      if (!Number.isInteger(tabId) || tabId <= 0 || !Array.isArray(resources)) {
        continue;
      }
      const bucket = /* @__PURE__ */ new Map();
      for (const resource of sortResources(resources.map(normalizeCapturedResource)).slice(0, RESOURCE_LIMIT)) {
        bucket.set(resource.id, resource);
        resourcesById.set(resource.id, resource);
      }
      resourceCache.set(tabId, bucket);
    }
    headerSnapshotsByUrl.clear();
    for (const snapshot of bridgeState[BRIDGE_HEADER_SNAPSHOTS_KEY] ?? []) {
      const normalized = normalizeBridgeHeaderSnapshot(snapshot);
      if (!normalized.url) {
        continue;
      }
      headerSnapshotsByUrl.set(normalized.url, normalized);
    }
    pruneHeaderSnapshots();
    lastActiveTabId = Number(bridgeState[BRIDGE_LAST_ACTIVE_TAB_KEY] ?? 0) || null;
    bridgeStateReady = true;
  }
  async function capturePageResource(sender, payload) {
    const tabId = await resolveBridgeResourceTabId(sender, payload.href);
    if (!tabId || !isBridgeResourceUrl(payload.url)) {
      return;
    }
    const tab = await getTab(tabId);
    const headers = normalizeHeaders(payload.requestHeaders);
    const filename = resolveBridgeFilename(payload);
    const mime = String(payload.mime ?? "").toLowerCase();
    cacheResource({
      id: buildResourceId(tabId, payload.url),
      tabId,
      url: payload.url,
      pageTitle: tab?.title ?? "",
      pageUrl: payload.href ?? tab?.url ?? "",
      filename,
      mime,
      size: 0,
      supportsRange: false,
      referer: headers.referer ?? payload.href ?? tab?.url ?? "",
      requestHeaders: headers,
      capturedAt: Date.now()
    });
  }
  async function captureNetworkResource(details) {
    const responseMeta = getResponseHeadersValue(details.responseHeaders);
    if (!shouldCaptureCatCatchResponse(details, responseMeta)) {
      headersByRequestId.delete(details.requestId);
      rangeRequestIds.delete(details.requestId);
      return;
    }
    const tabId = await resolveNetworkResourceTabId(details);
    const headerSnapshot = resolveHeaderSnapshot(details.url);
    const requestHadRange = rangeRequestIds.has(details.requestId) || Boolean(headerSnapshot?.supportsRange);
    const requestHeaders = normalizeHeaders(headersByRequestId.get(details.requestId) ?? headerSnapshot?.headers ?? {});
    headersByRequestId.delete(details.requestId);
    rangeRequestIds.delete(details.requestId);
    if (!tabId) {
      return;
    }
    const tab = await getTab(tabId);
    const filename = resolveNetworkResourceFilename(details.url, responseMeta);
    const referer = requestHeaders.referer || details.initiator || tab?.url || "";
    const normalizedRequestHeaders = referer ? { ...requestHeaders, referer } : requestHeaders;
    cacheResource({
      id: buildResourceId(tabId, details.url),
      tabId,
      url: details.url,
      pageTitle: tab?.title ?? "",
      pageUrl: details.initiator ?? tab?.url ?? "",
      filename,
      mime: responseMeta.type,
      size: responseMeta.size,
      supportsRange: responseMeta.supportsRange || details.statusCode === 206 || requestHadRange,
      referer,
      requestHeaders: normalizedRequestHeaders,
      capturedAt: Date.now()
    });
  }
  function shouldHandoffBrowserDownload(downloadItem, interceptDownloads2) {
    const finalUrl = downloadItem.finalUrl || downloadItem.url;
    return Boolean(interceptDownloads2 && options.isDesktopReady() && isCapturableUrl(finalUrl));
  }
  async function handoffBrowserDownload(downloadItem) {
    const finalUrl = downloadItem.finalUrl || downloadItem.url;
    const matchedResource = findResourceByUrl(finalUrl);
    const resolvedFilename = trimFilename(downloadItem.filename) || trimFilename(matchedResource?.filename ?? "") || trimFilename(filenameFromUrl(finalUrl)) || "resource";
    const headers = resolveHeadersForDownload(finalUrl);
    if (downloadItem.referrer && !headers.referer) {
      headers.referer = downloadItem.referrer;
    }
    try {
      const result = await options.sendDesktopRequest({
        type: "create_task",
        source: "download",
        title: resolvedFilename,
        payload: {
          url: finalUrl,
          headers,
          filename: resolvedFilename,
          size: typeof downloadItem.totalBytes === "number" && downloadItem.totalBytes > 0 ? downloadItem.totalBytes : matchedResource?.size ?? 0,
          supportsRange: matchedResource?.supportsRange ?? downloadItem.canResume === true
        }
      });
      if (result.ok) {
        await openActionPopup();
      }
    } catch {
    }
  }
  async function sendHttpResourceToDesktop(resource) {
    try {
      const result = await options.sendDesktopRequest({
        type: "create_task",
        source: "resource",
        title: resource.filename,
        payload: {
          url: resource.url,
          headers: resource.requestHeaders,
          filename: resource.filename,
          size: resource.size,
          supportsRange: resource.supportsRange
        }
      });
      if (result.ok) {
        markResourceSent(resource.id);
        return {
          ...result,
          message: result.message || "\u8D44\u6E90\u5DF2\u53D1\u9001\u5230 Ghost Downloader"
        };
      }
      return result;
    } catch (error) {
      return {
        ok: false,
        message: error instanceof Error ? error.message : "\u53D1\u9001\u8D44\u6E90\u5931\u8D25"
      };
    }
  }
  async function sendResource(resourceId) {
    const resource = findResourceById(resourceId);
    if (!resource) {
      return { ok: false, message: "\u8D44\u6E90\u4E0D\u5B58\u5728" };
    }
    try {
      if (resource.url.startsWith("blob:")) {
        await downloadResourceViaBrowser(resource);
        markResourceSent(resource.id);
        return {
          ok: true,
          message: "\u8D44\u6E90\u5DF2\u4EA4\u7ED9\u6D4F\u89C8\u5668\u4E0B\u8F7D"
        };
      }
      return await sendHttpResourceToDesktop(resource);
    } catch (error) {
      return {
        ok: false,
        message: error instanceof Error ? error.message : "\u53D1\u9001\u8D44\u6E90\u5931\u8D25"
      };
    }
  }
  async function mergeResources(resourceIds) {
    const ids = [...new Set(resourceIds.map((value) => String(value || "")).filter(Boolean))];
    const resources = ids.map((resourceId) => findResourceById(resourceId)).filter((resource) => resource != null);
    if (resources.length !== 2) {
      return {
        ok: false,
        message: "\u5728\u7EBF\u5408\u5E76\u6682\u65F6\u53EA\u652F\u6301\u9009\u4E2D 2 \u4E2A\u8D44\u6E90"
      };
    }
    if (!canUseOnlineMergeSelection(resources)) {
      return {
        ok: false,
        message: "\u5F53\u524D\u9009\u4E2D\u7684\u8D44\u6E90\u4E0D\u7B26\u5408\u5728\u7EBF\u5408\u5E76\u6761\u4EF6"
      };
    }
    const orderedResources = sortResourcesForOnlineMerge(resources);
    try {
      const result = await options.sendDesktopRequest({
        type: "create_task",
        source: "resource_merge",
        title: deriveMergeOutputTitle(orderedResources),
        payload: {
          resources: orderedResources.map((resource) => ({
            url: resource.url,
            filename: resource.filename,
            mime: resource.mime,
            size: resource.size,
            headers: resource.requestHeaders,
            pageTitle: resource.pageTitle,
            supportsRange: resource.supportsRange
          }))
        }
      });
      if (result.ok) {
        orderedResources.forEach((resource) => markResourceSent(resource.id));
        return {
          ...result,
          message: result.message || "\u5728\u7EBF\u5408\u5E76\u4EFB\u52A1\u5DF2\u53D1\u9001\u5230 Ghost Downloader"
        };
      }
      return result;
    } catch (error) {
      return {
        ok: false,
        message: error instanceof Error ? error.message : "\u5728\u7EBF\u5408\u5E76\u5931\u8D25"
      };
    }
  }
  function buildPopupStateData(resolvedTabId, activeTab) {
    const canCaptureCurrentTab = isCapturableTab(activeTab);
    let resourceState = "ready";
    let resourceStateMessage = "\u7B49\u5F85 cat-catch \u6355\u83B7\u8D44\u6E90";
    if (!bridgeStateReady) {
      resourceState = "restoring";
      resourceStateMessage = "\u6B63\u5728\u6062\u590D cat-catch \u5DF2\u6355\u83B7\u7684\u8D44\u6E90";
    } else if (!canCaptureCurrentTab) {
      resourceState = "unavailable";
      resourceStateMessage = "\u5F53\u524D\u6807\u7B7E\u9875\u4E0D\u652F\u6301 cat-catch \u8D44\u6E90\u6865\u63A5";
    }
    return {
      resourceState,
      resourceStateMessage,
      currentResources: resolvedTabId == null ? [] : sortResources(resourceCache.get(resolvedTabId)?.values() ?? []),
      otherResources: otherResourcesForTab(resolvedTabId),
      activePageDomain: domainFromUrl(activeTab?.url ?? "")
    };
  }
  function handleTabRemoved(tabId) {
    clearResourcesForTab(tabId);
    clearHeaderSnapshotsForTab(tabId);
    if (lastActiveTabId === tabId) {
      void setLastActiveTab(null);
    }
  }
  function handleNavigationCommitted(details) {
    if (details.tabId <= 0 || details.frameId !== 0) {
      return;
    }
    clearResourcesForTab(details.tabId);
    clearHeaderSnapshotsForTab(details.tabId);
  }
  function handleRequestHeaders(details) {
    const headers = parseHeaderList(details.requestHeaders);
    headersByRequestId.set(details.requestId, headers);
    const supportsRange = hasRangeHeader(details.requestHeaders);
    if (supportsRange) {
      rangeRequestIds.add(details.requestId);
    } else {
      rangeRequestIds.delete(details.requestId);
    }
    rememberHeaderSnapshot(details.url, headers, details.tabId > 0 ? details.tabId : lastActiveTabId, supportsRange);
  }
  function clearRequestHeaders(requestId) {
    headersByRequestId.delete(requestId);
    rangeRequestIds.delete(requestId);
  }
  return {
    buildPopupStateData,
    captureNetworkResource,
    capturePageResource,
    clearRequestHeaders,
    handoffBrowserDownload,
    shouldHandoffBrowserDownload,
    handleNavigationCommitted,
    handleRequestHeaders,
    handleTabRemoved,
    loadPersistentState,
    refreshActiveTabFromBrowser,
    resolveActiveTabId,
    mergeResources,
    sendResource,
    setLastActiveTab
  };
}

// src/background.ts
var desktopBridge = createDesktopBridge();
var resourceBridge = createResourceBridge({
  isDesktopReady: () => desktopBridge.isReady(),
  sendDesktopRequest: (payload) => desktopBridge.sendRequest(payload)
});
var featureBridge = createFeatureBridge();
var mediaBridge = createMediaBridge();
var interceptDownloads = true;
var domainBlacklist = [];
var typeBlacklist = [];
var sizeBlacklistMB = "";
function taskCounters(tasks) {
  return {
    total: tasks.length,
    active: tasks.filter((task) => task.status !== "completed").length,
    completed: tasks.filter((task) => task.status === "completed").length
  };
}
function parseRuleLines(value) {
  return String(value ?? "").split(/\r?\n/).map((line) => line.trim().toLowerCase()).filter(Boolean);
}
function isDomainBlacklisted(rawUrl) {
  try {
    const hostname = new URL(rawUrl).hostname.toLowerCase();
    return domainBlacklist.some((rule) => hostname === rule || hostname.endsWith(`.${rule}`));
  } catch {
    return false;
  }
}
function isTypeBlacklisted(downloadItem) {
  const rawUrl = String(downloadItem.finalUrl || downloadItem.url || "").toLowerCase();
  const filename = String(downloadItem.filename || "").toLowerCase();
  return typeBlacklist.some((rule) => {
    if (rule.startsWith(".")) {
      return rawUrl.includes(rule) || filename.endsWith(rule);
    }
    return rawUrl.includes(rule) || filename.includes(rule);
  });
}
function isSizeBlacklisted(downloadItem) {
  const raw = String(sizeBlacklistMB ?? "").trim();
  if (!raw) {
    return false;
  }
  const thresholdMB = Number(raw);
  if (!Number.isFinite(thresholdMB) || thresholdMB <= 0) {
    return false;
  }
  const sizeBytes = typeof downloadItem.totalBytes === "number" && downloadItem.totalBytes > 0 ? downloadItem.totalBytes : typeof downloadItem.fileSize === "number" && downloadItem.fileSize > 0 ? downloadItem.fileSize : -1;
  if (sizeBytes < 0) {
    return false;
  }
  return sizeBytes < thresholdMB * 1024 * 1024;
}
async function buildPopupState(options = {}) {
  const resolvedTabId = await resourceBridge.resolveActiveTabId(options.preferredTabId ?? null);
  const activeTab = resolvedTabId != null ? await getTab(resolvedTabId) : null;
  const desktopState = desktopBridge.buildSnapshot();
  const resourceState = resourceBridge.buildPopupStateData(resolvedTabId, activeTab);
  const mediaPanelState = options.currentView === "advanced" || options.refreshMediaInventory ? await mediaBridge.buildPanelState(resolvedTabId, {
    refreshInventory: Boolean(options.refreshMediaInventory),
    refreshTarget: true
  }) : mediaBridge.getLastPanelState();
  return {
    connectionState: desktopState.connectionState,
    connectionMessage: desktopState.connectionMessage,
    desktopVersion: desktopState.desktopVersion,
    token: desktopState.token,
    serverUrl: desktopState.serverUrl,
    interceptDownloads,
    tasks: desktopState.tasks,
    taskCounters: taskCounters(desktopState.tasks),
    tabId: resolvedTabId,
    featureStates: featureBridge.createFeatureStateMap(resolvedTabId),
    mediaTabs: mediaPanelState.mediaTabs,
    mediaItems: mediaPanelState.mediaItems,
    selectedMediaTabId: mediaPanelState.selectedMediaTabId,
    selectedMediaIndex: mediaPanelState.selectedMediaIndex,
    mediaPlaybackState: mediaPanelState.playbackState,
    domainBlacklist: domainBlacklist.join("\n"),
    typeBlacklist: typeBlacklist.join("\n"),
    sizeBlacklistMB,
    ...resourceState
  };
}
async function initialize() {
  const localState = await localStorageGet({
    [INTERCEPT_DOWNLOADS_KEY]: true,
    [DOMAIN_BLACKLIST_KEY]: "",
    [TYPE_BLACKLIST_KEY]: "",
    [SIZE_BLACKLIST_KEY]: ""
  });
  interceptDownloads = Boolean(localState[INTERCEPT_DOWNLOADS_KEY] ?? true);
  domainBlacklist = parseRuleLines(String(localState[DOMAIN_BLACKLIST_KEY] ?? ""));
  typeBlacklist = parseRuleLines(String(localState[TYPE_BLACKLIST_KEY] ?? ""));
  sizeBlacklistMB = String(localState[SIZE_BLACKLIST_KEY] ?? "").trim();
  await desktopBridge.loadPersistentState();
  await resourceBridge.loadPersistentState();
  await featureBridge.loadPersistentState();
  await mediaBridge.loadPersistentState();
  await resourceBridge.resolveActiveTabId();
  if (desktopBridge.buildSnapshot().token) {
    void desktopBridge.connect();
  }
  desktopBridge.ensureReconnectAlarm();
}
chrome.alarms.onAlarm.addListener((alarm) => {
  desktopBridge.handleReconnectAlarm(alarm);
});
chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName !== "local") {
    return;
  }
  desktopBridge.syncLocalStorageChanges(changes);
  if (changes[INTERCEPT_DOWNLOADS_KEY]) {
    interceptDownloads = Boolean(changes[INTERCEPT_DOWNLOADS_KEY].newValue ?? true);
  }
  if (changes[DOMAIN_BLACKLIST_KEY]) {
    domainBlacklist = parseRuleLines(String(changes[DOMAIN_BLACKLIST_KEY].newValue ?? ""));
  }
  if (changes[TYPE_BLACKLIST_KEY]) {
    typeBlacklist = parseRuleLines(String(changes[TYPE_BLACKLIST_KEY].newValue ?? ""));
  }
  if (changes[SIZE_BLACKLIST_KEY]) {
    sizeBlacklistMB = String(changes[SIZE_BLACKLIST_KEY].newValue ?? "").trim();
  }
});
chrome.tabs.onActivated.addListener((activeInfo) => {
  void resourceBridge.setLastActiveTab(activeInfo.tabId);
});
chrome.windows.onFocusChanged.addListener((windowId) => {
  if (windowId === chrome.windows.WINDOW_ID_NONE) {
    return;
  }
  void resourceBridge.refreshActiveTabFromBrowser();
});
chrome.tabs.onRemoved.addListener((tabId) => {
  resourceBridge.handleTabRemoved(tabId);
  mediaBridge.handleTabRemoved(tabId);
  featureBridge.handleTabRemoved(tabId);
});
chrome.webNavigation.onCommitted.addListener((details) => {
  resourceBridge.handleNavigationCommitted(details);
  mediaBridge.handleNavigationCommitted(details);
  featureBridge.handleNavigationCommitted(details);
});
chrome.webRequest.onSendHeaders.addListener(
  (details) => {
    resourceBridge.handleRequestHeaders(details);
  },
  { urls: ["<all_urls>"] },
  getOnSendHeadersExtraInfoSpec()
);
chrome.webRequest.onResponseStarted.addListener(
  (details) => {
    void resourceBridge.captureNetworkResource(details);
  },
  { urls: ["<all_urls>"] },
  ["responseHeaders"]
);
chrome.webRequest.onErrorOccurred.addListener(
  (details) => {
    resourceBridge.clearRequestHeaders(details.requestId);
  },
  { urls: ["<all_urls>"] }
);
chrome.webRequest.onCompleted.addListener(
  (details) => {
    resourceBridge.clearRequestHeaders(details.requestId);
  },
  { urls: ["<all_urls>"] }
);
async function interceptBrowserDownload(downloadItem, options = {}) {
  const rawUrl = String(downloadItem.finalUrl || downloadItem.url || "");
  if (isDomainBlacklisted(rawUrl)) {
    return;
  }
  if (isTypeBlacklisted(downloadItem)) {
    return;
  }
  if (isSizeBlacklisted(downloadItem)) {
    return;
  }
  if (!resourceBridge.shouldHandoffBrowserDownload(downloadItem, interceptDownloads)) {
    return;
  }
  try {
    await cancelDownload(downloadItem.id);
    if (options.eraseFromHistory) {
      await eraseDownloadFromHistory(downloadItem.id);
    }
  } catch {
  }
  await resourceBridge.handoffBrowserDownload(downloadItem);
}
if (supportsDownloadDeterminingFilename()) {
  chrome.downloads.onDeterminingFilename.addListener((downloadItem, suggest) => {
    suggest();
    void interceptBrowserDownload(downloadItem);
  });
} else if (chrome.downloads.onCreated?.addListener) {
  chrome.downloads.onCreated.addListener((downloadItem) => {
    void interceptBrowserDownload(downloadItem, { eraseFromHistory: true });
  });
}
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || typeof message.type !== "string") {
    return;
  }
  if (message.type === "bridge_page_media") {
    void resourceBridge.capturePageResource(sender, message.payload);
    sendResponse({ ok: true });
    return true;
  }
  if (message.type === "bridge_page_command") {
    void featureBridge.handleBridgeScriptCommand(message.payload, sender);
    sendResponse({ ok: true });
    return true;
  }
  if (message.type === "popup_get_state") {
    void (async () => {
      sendResponse(
        await buildPopupState({
          preferredTabId: typeof message.tabId === "number" ? message.tabId : null,
          currentView: message.view
        })
      );
    })();
    return true;
  }
  if (message.type === "popup_set_token") {
    void (async () => {
      await desktopBridge.setToken(String(message.token ?? "").trim());
      sendResponse(await buildPopupState({ currentView: message.view }));
    })();
    return true;
  }
  if (message.type === "popup_set_server_url") {
    void (async () => {
      await desktopBridge.setServerUrl(String(message.serverUrl ?? ""));
      sendResponse(await buildPopupState({ currentView: message.view }));
    })();
    return true;
  }
  if (message.type === "popup_refresh_connection") {
    void (async () => {
      await desktopBridge.connect(true);
      sendResponse(await buildPopupState({ currentView: message.view }));
    })();
    return true;
  }
  if (message.type === "popup_set_intercept_downloads") {
    void (async () => {
      interceptDownloads = Boolean(message.enabled);
      await chrome.storage.local.set({ [INTERCEPT_DOWNLOADS_KEY]: interceptDownloads });
      sendResponse(await buildPopupState({ currentView: message.view }));
    })();
    return true;
  }
  if (message.type === "popup_task_action") {
    void (async () => {
      try {
        const result = await desktopBridge.sendRequest({
          type: "task_action",
          taskId: message.taskId,
          action: message.action
        });
        sendResponse(result);
      } catch (error) {
        sendResponse({
          ok: false,
          message: error instanceof Error ? error.message : "\u4EFB\u52A1\u64CD\u4F5C\u5931\u8D25"
        });
      }
    })();
    return true;
  }
  if (message.type === "popup_send_resource") {
    void (async () => {
      sendResponse(await resourceBridge.sendResource(String(message.resourceId ?? "")));
    })();
    return true;
  }
  if (message.type === "popup_merge_resources") {
    void (async () => {
      const resourceIds = Array.isArray(message.resourceIds) ? message.resourceIds.map((value) => String(value ?? "")).filter(Boolean) : [];
      sendResponse(await resourceBridge.mergeResources(resourceIds));
    })();
    return true;
  }
  if (message.type === "popup_toggle_feature") {
    void (async () => {
      const tabId = typeof message.tabId === "number" ? message.tabId : null;
      if (tabId == null) {
        sendResponse({ ok: false, message: "\u5F53\u524D\u6CA1\u6709\u53EF\u64CD\u4F5C\u7684\u6807\u7B7E\u9875" });
        return;
      }
      try {
        const infoMessage = await featureBridge.toggleFeature(message.feature, tabId);
        sendResponse({ ok: true, message: infoMessage });
      } catch (error) {
        sendResponse({
          ok: false,
          message: error instanceof Error ? error.message : "\u529F\u80FD\u5207\u6362\u5931\u8D25"
        });
      }
    })();
    return true;
  }
  if (message.type === "popup_set_media_target") {
    void (async () => {
      await mediaBridge.setMediaTarget(Number(message.tabId ?? 0), Number(message.index ?? -1));
      sendResponse(
        await buildPopupState({
          currentView: "advanced",
          refreshMediaInventory: true
        })
      );
    })();
    return true;
  }
  if (message.type === "popup_media_action") {
    void (async () => {
      sendResponse(await mediaBridge.performAction(String(message.action ?? ""), message.value));
    })();
    return true;
  }
  if (message.type === "popup_set_domain_blacklist") {
    void (async () => {
      const value = String(message.value ?? "");
      await chrome.storage.local.set({ [DOMAIN_BLACKLIST_KEY]: value });
      sendResponse({ ok: true });
    })();
    return true;
  }
  if (message.type === "popup_set_type_blacklist") {
    void (async () => {
      const value = String(message.value ?? "");
      await chrome.storage.local.set({ [TYPE_BLACKLIST_KEY]: value });
      sendResponse({ ok: true });
    })();
    return true;
  }
  if (message.type === "popup_set_size_blacklist") {
    void (async () => {
      const value = String(message.value ?? "").trim();
      await chrome.storage.local.set({ [SIZE_BLACKLIST_KEY]: value });
      sendResponse({ ok: true });
    })();
    return true;
  }
});
void initialize();
