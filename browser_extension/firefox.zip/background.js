// src/shared/browser.ts
var REQUEST_HEADERS = "requestHeaders";
var EXTRA_HEADERS = "extraHeaders";
var cachedBrowserTarget = null;
function getExtensionBrowserTarget() {
  if (cachedBrowserTarget) {
    return cachedBrowserTarget;
  }
  try {
    const runtimeUrl = chrome.runtime.getURL("/");
    if (runtimeUrl.startsWith("moz-extension://")) {
      cachedBrowserTarget = "firefox";
      return cachedBrowserTarget;
    }
  } catch {
  }
  cachedBrowserTarget = "chromium";
  return cachedBrowserTarget;
}
function isFirefoxExtension() {
  return getExtensionBrowserTarget() === "firefox";
}
function isAndroidFirefoxLike() {
  try {
    return isFirefoxExtension() && /Android/i.test(globalThis.navigator?.userAgent ?? "");
  } catch {
    return false;
  }
}
function getInstallDirectory() {
  return isFirefoxExtension() ? "browser_extension/firefox" : "browser_extension/chromium";
}
function getOnSendHeadersExtraInfoSpec() {
  return isFirefoxExtension() ? [REQUEST_HEADERS] : [REQUEST_HEADERS, EXTRA_HEADERS];
}
function supportsDownloadDeterminingFilename() {
  return Boolean(chrome.downloads?.onDeterminingFilename?.addListener);
}

// src/shared/cat-catch.ts
var CAT_CATCH_HLS_TYPES = /* @__PURE__ */ new Set([
  "application/vnd.apple.mpegurl",
  "application/x-mpegurl",
  "application/mpegurl",
  "application/octet-stream-m3u8"
]);
var CAT_CATCH_MPD_TYPES = /* @__PURE__ */ new Set(["application/dash+xml"]);
var CAT_CATCH_VIDEO_EXTENSIONS = /* @__PURE__ */ new Set([
  "3gp",
  "asf",
  "avi",
  "divx",
  "f4v",
  "flv",
  "hlv",
  "m4s",
  "mkv",
  "mov",
  "mp4",
  "mpeg",
  "mpeg4",
  "movie",
  "ogv",
  "ts",
  "vid",
  "webm",
  "wmv"
]);
var CAT_CATCH_AUDIO_EXTENSIONS = /* @__PURE__ */ new Set([
  "aac",
  "acc",
  "flac",
  "m4s",
  "m4a",
  "mp3",
  "ogg",
  "opus",
  "wav",
  "weba",
  "wma"
]);
var CAT_CATCH_MEDIA_EXTENSIONS = /* @__PURE__ */ new Set([
  ...CAT_CATCH_VIDEO_EXTENSIONS,
  ...CAT_CATCH_AUDIO_EXTENSIONS,
  "m3u",
  "m3u8",
  "mpd"
]);
function isCatCatchM3u8(extension, mime = "") {
  const type = String(mime || "").toLowerCase();
  return extension === "m3u8" || extension === "m3u" || CAT_CATCH_HLS_TYPES.has(type) || type.endsWith("/vnd.apple.mpegurl") || type.endsWith("/x-mpegurl") || type.endsWith("/mpegurl") || type.endsWith("/octet-stream-m3u8");
}
function isCatCatchMpd(extension, mime = "") {
  return extension === "mpd" || CAT_CATCH_MPD_TYPES.has(String(mime || "").toLowerCase());
}
function isCatCatchStream(extension, mime = "") {
  return isCatCatchM3u8(extension, mime) || isCatCatchMpd(extension, mime);
}
function isCatCatchMedia(extension, mime = "") {
  const type = String(mime || "").toLowerCase();
  return CAT_CATCH_MEDIA_EXTENSIONS.has(extension) || type.startsWith("video/") || type.startsWith("audio/") || isCatCatchStream(extension, type);
}
var CAT_CATCH_SCRIPT_FEATURES = {
  recorder: { script: "recorder.js", i18n: true, allFrames: true, world: "MAIN", reloadRequired: false },
  webrtc: { script: "webrtc.js", i18n: true, allFrames: true, world: "MAIN", reloadRequired: true },
  recorder2: { script: "recorder2.js", i18n: true, allFrames: false, world: "ISOLATED", reloadRequired: false },
  search: { script: "search.js", i18n: false, allFrames: true, world: "MAIN", reloadRequired: true },
  catch: { script: "catch.js", i18n: true, allFrames: true, world: "MAIN", reloadRequired: true }
};
var MOBILE_USER_AGENT = "Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1";

// src/shared/constants.ts
var DEFAULT_SERVER_URL = "ws://127.0.0.1:14370";
var EXTENSION_VERSION = chrome.runtime.getManifest().version;
var ADVANCED_FEATURES = [
  {
    key: "recorder",
    title: "\u89C6\u9891\u5F55\u5236",
    description: "\u5F55\u5236\u7F51\u9875\u4E2D\u7684\u89C6\u9891\u5185\u5BB9"
  },
  {
    key: "webrtc",
    title: "\u5F55\u5236 WebRTC",
    description: "\u5F55\u5236 WebRTC \u5B9E\u65F6\u901A\u4FE1\u5185\u5BB9",
    reloadRequired: CAT_CATCH_SCRIPT_FEATURES.webrtc.reloadRequired
  },
  {
    key: "recorder2",
    title: "\u5C4F\u5E55\u6355\u6349",
    description: "\u6355\u6349\u5C4F\u5E55\u3001\u7A97\u53E3\u6216\u6807\u7B7E\u9875"
  },
  {
    key: "mobileUserAgent",
    title: "\u6A21\u62DF\u624B\u673A",
    description: "\u6A21\u62DF\u79FB\u52A8\u8BBE\u5907\u8BBF\u95EE\u9875\u9762",
    reloadRequired: true
  },
  {
    key: "search",
    title: "\u6DF1\u5EA6\u641C\u7D22",
    description: "\u6DF1\u5165\u5206\u6790\u9875\u9762\u8BF7\u6C42\u8D44\u6E90",
    reloadRequired: CAT_CATCH_SCRIPT_FEATURES.search.reloadRequired
  },
  {
    key: "catch",
    title: "\u7F13\u5B58\u6355\u6349",
    description: "\u6355\u6349\u6D4F\u89C8\u5668\u7F13\u5B58\u7684\u8D44\u6E90",
    reloadRequired: CAT_CATCH_SCRIPT_FEATURES.catch.reloadRequired
  }
];
var HELP_CONTENT = {
  pairing: {
    title: "\u5982\u4F55\u914D\u5BF9\u684C\u9762\u7AEF",
    body: [
      "1. \u5728 Ghost-Downloader-3 \u684C\u9762\u7AEF\u8BBE\u7F6E\u9875\u5F00\u542F\u201C\u542F\u7528\u6D4F\u89C8\u5668\u6269\u5C55\u201D\u3002",
      "2. \u5728\u6269\u5C55\u8BBE\u7F6E\u9875\u70B9\u51FB\u201C\u81EA\u52A8\u914D\u5BF9\u201D\u3002",
      "3. \u56DE\u5230\u684C\u9762\u7AEF\u786E\u8BA4\u914D\u5BF9\u8BF7\u6C42\u3002",
      "4. \u8FDE\u63A5\u72B6\u6001\u53D8\u6210\u201C\u5DF2\u8FDE\u63A5\u201D\u540E\uFF0C\u6D4F\u89C8\u5668\u5C31\u80FD\u76F4\u63A5\u7BA1\u7406\u684C\u9762\u4EFB\u52A1\u4E86\u3002"
    ]
  },
  install: {
    title: "\u5B89\u88C5\u8BF4\u660E",
    body: isFirefoxExtension() ? [
      "1. \u6253\u5F00 about:debugging#/runtime/this-firefox\u3002",
      "2. \u70B9\u51FB\u201C\u4E34\u65F6\u8F7D\u5165\u9644\u52A0\u7EC4\u4EF6\u201D\u3002",
      `3. \u9009\u62E9\u9879\u76EE\u91CC\u7684 ${getInstallDirectory()} \u76EE\u5F55\u5185\u4EFB\u610F\u6587\u4EF6\u3002`,
      "4. \u4FDD\u6301\u684C\u9762\u7AEF\u6D4F\u89C8\u5668\u670D\u52A1\u5F00\u542F\u5373\u53EF\u6B63\u5E38\u8FDE\u63A5\u3002"
    ] : [
      "1. \u6253\u5F00\u6D4F\u89C8\u5668\u6269\u5C55\u7BA1\u7406\u9875\u5E76\u5F00\u542F\u5F00\u53D1\u8005\u6A21\u5F0F\u3002",
      "2. \u9009\u62E9\u201C\u52A0\u8F7D\u5DF2\u89E3\u538B\u7684\u6269\u5C55\u7A0B\u5E8F\u201D\u3002",
      `3. \u9009\u62E9\u9879\u76EE\u91CC\u7684 ${getInstallDirectory()} \u76EE\u5F55\u3002`,
      "4. \u4FDD\u6301\u684C\u9762\u7AEF\u6D4F\u89C8\u5668\u670D\u52A1\u5F00\u542F\u5373\u53EF\u6B63\u5E38\u8FDE\u63A5\u3002"
    ]
  },
  troubleshooting: {
    title: "\u6545\u969C\u6392\u67E5",
    body: [
      "1. \u5148\u786E\u8BA4\u684C\u9762\u7AEF\u6D4F\u89C8\u5668\u6269\u5C55\u670D\u52A1\u5DF2\u7ECF\u5F00\u542F\u3002",
      "2. \u4F18\u5148\u70B9\u51FB\u201C\u81EA\u52A8\u914D\u5BF9\u201D\uFF0C\u5931\u8D25\u65F6\u518D\u68C0\u67E5\u914D\u5BF9\u4EE4\u724C\u662F\u5426\u548C\u684C\u9762\u7AEF\u4E00\u81F4\u3002",
      "3. \u5982\u679C\u72B6\u6001\u4E00\u76F4\u65AD\u5F00\uFF0C\u5C1D\u8BD5\u70B9\u51FB\u8BBE\u7F6E\u9875\u91CC\u7684\u91CD\u65B0\u8FDE\u63A5\u3002",
      "4. \u6D4F\u89C8\u5668\u4E0B\u8F7D\u6CA1\u6709\u88AB\u63A5\u7BA1\u65F6\uFF0C\u53EF\u5148\u786E\u8BA4\u9876\u90E8\u201C\u62E6\u622A\u4E0B\u8F7D\u201D\u5F00\u5173\u662F\u5426\u5F00\u542F\u3002"
    ]
  }
};

// src/background/constants.ts
var PROTOCOL_VERSION = 1;
var RECONNECT_ALARM = "gd3-reconnect";
var RESOURCE_LIMIT = 120;
var HEADER_SNAPSHOT_LIMIT = 80;
var HEADER_EXPIRATION_MS = 2 * 60 * 1e3;
var BRIDGE_PERSIST_DEBOUNCE_MS = 240;
var MAIN_FRAME_ID = 0;
var PAIR_TOKEN_KEY = "pairToken";
var SERVER_URL_KEY = "desktopServerUrl";
var INTERCEPT_DOWNLOADS_KEY = "interceptDownloads";
var MEDIA_DOWNLOAD_OVERLAY_KEY = "mediaDownloadOverlayEnabled";
var DOMAIN_BLACKLIST_KEY = "domainBlacklist";
var TYPE_BLACKLIST_KEY = "typeBlacklist";
var SIZE_BLACKLIST_KEY = "sizeBlacklistMB";
var FEATURE_TAB_STATE_KEY = "featureTabState";
var BRIDGE_RESOURCE_CACHE_KEY = "bridgeResourceCacheByTab";
var BRIDGE_HEADER_SNAPSHOTS_KEY = "bridgeHeaderSnapshots";
var BRIDGE_LAST_ACTIVE_TAB_KEY = "bridgeLastActiveTabId";
var NOTIFY_ON_TASK_CREATED_KEY = "notifyOnTaskCreated";
var FEATURE_KEYS = ADVANCED_FEATURES.map((item) => item.key);

// src/background/chrome-helpers.ts
function bridgeStorageArea() {
  return chrome.storage.session ?? chrome.storage.local;
}
async function localStorageGet(defaults) {
  const items = await chrome.storage.local.get(defaults);
  return items;
}
async function localStorageSet(values) {
  await chrome.storage.local.set(values);
}
async function bridgeStorageGet(defaults) {
  const items = await bridgeStorageArea().get(defaults);
  return items;
}
async function bridgeStorageSet(values) {
  await bridgeStorageArea().set(values);
}
async function queryTabs(queryInfo) {
  return chrome.tabs.query(queryInfo);
}
async function getTab(tabId) {
  try {
    return await chrome.tabs.get(tabId);
  } catch {
    return null;
  }
}
async function sendMessageToTab(tabId, message, options) {
  const tab = await getTab(tabId);
  if (!tab?.id) {
    return {
      status: "no_receiver",
      message: "\u76EE\u6807\u6807\u7B7E\u9875\u4E0D\u5B58\u5728"
    };
  }
  return new Promise((resolve) => {
    chrome.tabs.sendMessage(tabId, message, options ?? {}, (response) => {
      const lastError = chrome.runtime.lastError;
      if (lastError) {
        const text = String(lastError.message || "");
        const status = /receiving end does not exist/i.test(text) ? "no_receiver" : "runtime_error";
        resolve({
          status,
          message: text
        });
        return;
      }
      if (typeof response === "undefined") {
        resolve({
          status: "no_response"
        });
        return;
      }
      resolve({
        status: "ok",
        response
      });
    });
  });
}
async function reloadTab(tabId) {
  return new Promise((resolve) => {
    chrome.tabs.reload(tabId, { bypassCache: true }, () => resolve());
  });
}
async function cancelDownload(downloadId) {
  return new Promise((resolve, reject) => {
    chrome.downloads.cancel(downloadId, () => {
      const lastError = chrome.runtime.lastError;
      if (lastError) {
        reject(new Error(lastError.message));
        return;
      }
      resolve();
    });
  });
}
async function eraseDownloadFromHistory(downloadId) {
  return new Promise((resolve, reject) => {
    chrome.downloads.erase({ id: downloadId }, () => {
      const lastError = chrome.runtime.lastError;
      if (lastError) {
        reject(new Error(lastError.message));
        return;
      }
      resolve();
    });
  });
}
async function openActionPopup() {
  if (!chrome.action?.openPopup) {
    return;
  }
  try {
    await chrome.action.openPopup();
  } catch {
  }
}

// src/background/desktop-bridge.ts
var PAIRING_TIMEOUT_MS = 6e4;
var MISSING_PAIRING_MESSAGE = "\u8BF7\u5728\u6269\u5C55\u8BBE\u7F6E\u9875\u81EA\u52A8\u914D\u5BF9\u684C\u9762\u7AEF";
function normalizeServerUrl(value) {
  const raw = String(value || DEFAULT_SERVER_URL).trim() || DEFAULT_SERVER_URL;
  try {
    const withScheme = /^[a-z][a-z\d+\-.]*:\/\//i.test(raw) ? raw : `ws://${raw}`;
    const url = new URL(withScheme);
    if (url.protocol === "http:") {
      url.protocol = "ws:";
    } else if (url.protocol === "https:") {
      url.protocol = "wss:";
    }
    if (url.protocol !== "ws:" && url.protocol !== "wss:") {
      return DEFAULT_SERVER_URL;
    }
    if (url.hostname === "0.0.0.0" || url.hostname === "::") {
      url.hostname = "127.0.0.1";
    }
    if (!url.port) {
      url.port = "14370";
    }
    url.pathname = "/";
    url.search = "";
    url.hash = "";
    return url.toString().replace(/\/$/, "");
  } catch {
    return DEFAULT_SERVER_URL;
  }
}
function createDesktopBridge() {
  let desktopSocket = null;
  let reconnectTimer = null;
  let connectionState = "missing_token";
  let connectionMessage = MISSING_PAIRING_MESSAGE;
  let desktopVersion = "";
  let pairToken = "";
  let serverUrl = normalizeServerUrl(DEFAULT_SERVER_URL);
  let taskSnapshot = [];
  const pendingRequests = /* @__PURE__ */ new Map();
  function nextRequestId() {
    return crypto.randomUUID();
  }
  function setConnectionState(state, message) {
    connectionState = state;
    connectionMessage = message;
  }
  function rejectPendingRequests(message) {
    for (const [requestId, pending] of pendingRequests.entries()) {
      clearTimeout(pending.timeoutId);
      pending.reject(new Error(message));
      pendingRequests.delete(requestId);
    }
  }
  function isReady() {
    return connectionState === "connected" && desktopSocket?.readyState === WebSocket.OPEN;
  }
  function clearReconnectTimer() {
    if (reconnectTimer !== null) {
      clearTimeout(reconnectTimer);
      reconnectTimer = null;
    }
  }
  function scheduleReconnect() {
    if (!pairToken || reconnectTimer !== null) {
      return;
    }
    reconnectTimer = self.setTimeout(() => {
      reconnectTimer = null;
      void connect();
    }, 2500);
  }
  function handleDesktopMessage(rawData) {
    let message;
    try {
      message = JSON.parse(rawData);
    } catch {
      return;
    }
    if (message.type === "hello_ack") {
      desktopVersion = String(message.appVersion ?? "");
      setConnectionState("connected", "\u5DF2\u8FDE\u63A5");
      desktopSocket?.send(JSON.stringify({ type: "subscribe_tasks", requestId: nextRequestId() }));
      return;
    }
    if (message.type === "task_snapshot" && Array.isArray(message.tasks)) {
      taskSnapshot = message.tasks;
      return;
    }
    if (message.type === "create_task_result" || message.type === "task_action_result") {
      const requestId = String(message.requestId ?? "");
      const pending = pendingRequests.get(requestId);
      if (!pending) {
        return;
      }
      clearTimeout(pending.timeoutId);
      pendingRequests.delete(requestId);
      pending.resolve(message);
      return;
    }
    if (message.type === "error" && connectionState === "authenticating") {
      const text = String(message.message ?? "\u914D\u5BF9\u4EE4\u724C\u65E0\u6548");
      desktopVersion = "";
      taskSnapshot = [];
      setConnectionState("unauthorized", text);
      rejectPendingRequests(text);
      desktopSocket?.close();
      desktopSocket = null;
    }
  }
  async function connect(force = false) {
    if (!pairToken) {
      desktopVersion = "";
      taskSnapshot = [];
      setConnectionState("missing_token", MISSING_PAIRING_MESSAGE);
      return;
    }
    if (desktopSocket && desktopSocket.readyState === WebSocket.OPEN && !force) {
      return;
    }
    clearReconnectTimer();
    if (force && desktopSocket) {
      desktopSocket.close();
      desktopSocket = null;
    }
    const targetUrl = normalizeServerUrl(serverUrl);
    serverUrl = targetUrl;
    await localStorageSet({ [SERVER_URL_KEY]: serverUrl });
    setConnectionState("connecting", `\u6B63\u5728\u8FDE\u63A5 Ghost Downloader (${targetUrl})`);
    const socket = new WebSocket(targetUrl);
    desktopSocket = socket;
    socket.addEventListener("open", () => {
      if (desktopSocket !== socket) {
        return;
      }
      setConnectionState("authenticating", "\u6B63\u5728\u6821\u9A8C\u914D\u5BF9\u4EE4\u724C");
      socket.send(
        JSON.stringify({
          type: "hello",
          protocolVersion: PROTOCOL_VERSION,
          token: pairToken,
          extensionVersion: chrome.runtime.getManifest().version,
          clientKind: "browser_extension"
        })
      );
    });
    socket.addEventListener("message", (event) => {
      if (desktopSocket !== socket) {
        return;
      }
      handleDesktopMessage(String(event.data ?? ""));
    });
    socket.addEventListener("close", () => {
      if (desktopSocket !== socket) {
        return;
      }
      desktopSocket = null;
      rejectPendingRequests("\u4E0E Ghost Downloader \u7684\u8FDE\u63A5\u5DF2\u65AD\u5F00");
      if (connectionState !== "unauthorized" && connectionState !== "missing_token") {
        desktopVersion = "";
        setConnectionState("disconnected", "\u672A\u8FDE\u63A5");
        scheduleReconnect();
      }
    });
    socket.addEventListener("error", () => {
      if (desktopSocket !== socket) {
        return;
      }
      if (connectionState !== "unauthorized") {
        desktopVersion = "";
        setConnectionState("disconnected", `\u65E0\u6CD5\u8FDE\u63A5\u5230 Ghost Downloader (${targetUrl})`);
      }
    });
  }
  async function requestPairing() {
    clearReconnectTimer();
    const targetUrl = normalizeServerUrl(serverUrl);
    serverUrl = targetUrl;
    await localStorageSet({ [SERVER_URL_KEY]: serverUrl });
    setConnectionState("connecting", `\u6B63\u5728\u8BF7\u6C42\u684C\u9762\u7AEF\u786E\u8BA4\u914D\u5BF9 (${targetUrl})`);
    try {
      const token = await new Promise((resolve, reject) => {
        const socket = new WebSocket(targetUrl);
        let settled = false;
        let timeoutId = 0;
        const finish = (done) => {
          if (settled) {
            return;
          }
          settled = true;
          self.clearTimeout(timeoutId);
          socket.close();
          done();
        };
        timeoutId = self.setTimeout(() => {
          finish(() => reject(new Error("\u7B49\u5F85\u684C\u9762\u7AEF\u786E\u8BA4\u914D\u5BF9\u8D85\u65F6")));
        }, PAIRING_TIMEOUT_MS);
        socket.addEventListener("open", () => {
          socket.send(
            JSON.stringify({
              type: "pair_request",
              requestId: nextRequestId(),
              protocolVersion: PROTOCOL_VERSION,
              extensionVersion: chrome.runtime.getManifest().version,
              clientKind: "browser_extension"
            })
          );
        });
        socket.addEventListener("message", (event) => {
          let response;
          try {
            response = JSON.parse(String(event.data ?? ""));
          } catch {
            return;
          }
          if (response.type !== "pair_result") {
            return;
          }
          if (!response.ok) {
            finish(() => reject(new Error(response.message || "\u684C\u9762\u7AEF\u5DF2\u62D2\u7EDD\u914D\u5BF9\u8BF7\u6C42")));
            return;
          }
          const token2 = String(response.token ?? "").trim();
          if (!token2) {
            finish(() => reject(new Error("\u684C\u9762\u7AEF\u672A\u8FD4\u56DE\u914D\u5BF9\u4EE4\u724C")));
            return;
          }
          finish(() => resolve(token2));
        });
        socket.addEventListener("close", () => {
          finish(() => reject(new Error("\u914D\u5BF9\u8FDE\u63A5\u5DF2\u65AD\u5F00")));
        });
        socket.addEventListener("error", () => {
          finish(() => reject(new Error(`\u65E0\u6CD5\u8FDE\u63A5\u5230 Ghost Downloader (${targetUrl})`)));
        });
      });
      await setToken(token);
    } catch (error) {
      const message = error instanceof Error ? error.message : "\u81EA\u52A8\u914D\u5BF9\u5931\u8D25";
      setConnectionState(pairToken ? "disconnected" : "missing_token", message);
      throw error;
    }
  }
  async function sendRequest(payload) {
    if (!isReady() || !desktopSocket) {
      throw new Error("Ghost Downloader \u672A\u8FDE\u63A5");
    }
    const requestId = String(payload.requestId ?? nextRequestId());
    const message = { ...payload, requestId };
    return new Promise((resolve, reject) => {
      const timeoutId = self.setTimeout(() => {
        pendingRequests.delete(requestId);
        reject(new Error("\u7B49\u5F85 Ghost Downloader \u54CD\u5E94\u8D85\u65F6"));
      }, 12e3);
      pendingRequests.set(requestId, {
        resolve: (value) => resolve(value),
        reject,
        timeoutId
      });
      desktopSocket?.send(JSON.stringify(message));
    });
  }
  async function loadPersistentState() {
    const localState = await localStorageGet({
      [PAIR_TOKEN_KEY]: "",
      [SERVER_URL_KEY]: DEFAULT_SERVER_URL
    });
    pairToken = String(localState[PAIR_TOKEN_KEY] ?? "").trim();
    serverUrl = normalizeServerUrl(String(localState[SERVER_URL_KEY] ?? DEFAULT_SERVER_URL));
    await localStorageSet({ [SERVER_URL_KEY]: serverUrl });
  }
  async function setToken(token) {
    pairToken = String(token ?? "").trim();
    await localStorageSet({ [PAIR_TOKEN_KEY]: pairToken });
    if (pairToken) {
      await connect(true);
      return;
    }
    desktopVersion = "";
    taskSnapshot = [];
    if (desktopSocket) {
      desktopSocket.close();
      desktopSocket = null;
    }
    setConnectionState("missing_token", MISSING_PAIRING_MESSAGE);
  }
  async function setServerUrl(nextServerUrl) {
    serverUrl = normalizeServerUrl(nextServerUrl);
    await localStorageSet({ [SERVER_URL_KEY]: serverUrl });
    await connect(true);
  }
  function syncLocalStorageChanges(changes) {
    if (changes[PAIR_TOKEN_KEY]) {
      pairToken = String(changes[PAIR_TOKEN_KEY].newValue ?? "").trim();
    }
    if (changes[SERVER_URL_KEY]) {
      serverUrl = normalizeServerUrl(String(changes[SERVER_URL_KEY].newValue ?? DEFAULT_SERVER_URL));
    }
  }
  function buildSnapshot() {
    return {
      connectionState,
      connectionMessage,
      desktopVersion,
      token: pairToken,
      serverUrl,
      tasks: taskSnapshot
    };
  }
  function ensureReconnectAlarm() {
    chrome.alarms.create(RECONNECT_ALARM, { periodInMinutes: 1 });
  }
  function handleReconnectAlarm(alarm) {
    if (alarm.name !== RECONNECT_ALARM || connectionState === "connected") {
      return;
    }
    void connect();
  }
  return {
    buildSnapshot,
    connect,
    ensureReconnectAlarm,
    handleReconnectAlarm,
    isReady,
    loadPersistentState,
    requestPairing,
    sendRequest,
    setServerUrl,
    setToken,
    syncLocalStorageChanges
  };
}

// src/background/feature-bridge.ts
var SCRIPT_FEATURE_KEYS = Object.keys(CAT_CATCH_SCRIPT_FEATURES);
var FLUENT_PANEL_FEATURES = /* @__PURE__ */ new Set(["recorder", "webrtc", "catch"]);
function createFeatureBridge() {
  const featureTabs = Object.fromEntries(
    FEATURE_KEYS.map((key) => [key, /* @__PURE__ */ new Set()])
  );
  function createFeatureStateMap(tabId) {
    return FEATURE_KEYS.reduce((state, key) => {
      state[key] = tabId != null && featureTabs[key].has(tabId);
      return state;
    }, {});
  }
  async function persistFeatureTabs() {
    await localStorageSet({
      [FEATURE_TAB_STATE_KEY]: Object.fromEntries(FEATURE_KEYS.map((key) => [key, Array.from(featureTabs[key])]))
    });
  }
  async function updateSessionRules(tabId, enabled) {
    return new Promise((resolve, reject) => {
      chrome.declarativeNetRequest.updateSessionRules(
        enabled ? {
          removeRuleIds: [tabId],
          addRules: [
            {
              id: tabId,
              action: {
                type: "modifyHeaders",
                requestHeaders: [
                  {
                    header: "User-Agent",
                    operation: "set",
                    value: MOBILE_USER_AGENT
                  }
                ]
              },
              condition: {
                tabIds: [tabId],
                resourceTypes: Object.values(chrome.declarativeNetRequest.ResourceType)
              }
            }
          ]
        } : {
          removeRuleIds: [tabId]
        },
        () => {
          const lastError = chrome.runtime.lastError;
          if (lastError) {
            reject(new Error(lastError.message));
            return;
          }
          resolve();
        }
      );
    });
  }
  async function executeScriptFiles(tabId, key, frameIds) {
    const feature = CAT_CATCH_SCRIPT_FEATURES[key];
    const usesFluentPanel = FLUENT_PANEL_FEATURES.has(key);
    const target = feature.allFrames ? frameIds ? { tabId, frameIds } : { tabId, allFrames: true } : { tabId, frameIds: frameIds ?? [MAIN_FRAME_ID] };
    const world = feature.world;
    const files = [
      ...feature.i18n ? ["catch-script/i18n.js"] : [],
      ...usesFluentPanel ? ["catch-script/fluent-ui.js"] : [],
      `catch-script/${feature.script}`
    ];
    if (usesFluentPanel) {
      await chrome.scripting.executeScript({
        args: [chrome.runtime.getURL("icon48.png")],
        func: (iconUrl) => {
          Reflect.set(window, "CatCatchFluentUIIcon", iconUrl);
        },
        injectImmediately: true,
        target,
        world
      });
    }
    await chrome.scripting.executeScript({
      files,
      injectImmediately: true,
      target,
      world
    });
  }
  async function setFeatureEnabled(key, tabId, enabled) {
    if (key === "mobileUserAgent") {
      if (enabled) {
        featureTabs.mobileUserAgent.add(tabId);
      } else {
        featureTabs.mobileUserAgent.delete(tabId);
      }
      await updateSessionRules(tabId, enabled);
      await persistFeatureTabs();
      await reloadTab(tabId);
      return enabled ? "\u5DF2\u542F\u7528\u6A21\u62DF\u624B\u673A\uFF0C\u5C06\u5728\u5237\u65B0\u540E\u751F\u6548" : "\u5DF2\u5173\u95ED\u6A21\u62DF\u624B\u673A";
    }
    const scriptKey = key;
    if (enabled) {
      featureTabs[scriptKey].add(tabId);
    } else {
      featureTabs[scriptKey].delete(tabId);
    }
    await persistFeatureTabs();
    if (CAT_CATCH_SCRIPT_FEATURES[scriptKey].reloadRequired) {
      await reloadTab(tabId);
      return enabled ? "\u529F\u80FD\u5DF2\u5F00\u542F\uFF0C\u9875\u9762\u5237\u65B0\u540E\u751F\u6548" : "\u529F\u80FD\u5DF2\u5173\u95ED";
    }
    if (!enabled) {
      return "\u529F\u80FD\u540E\u53F0\u72B6\u6001\u5DF2\u5173\u95ED\uFF0C\u9875\u9762\u4E2D\u7684\u9762\u677F\u53EF\u5728\u7F51\u9875\u5185\u81EA\u884C\u5173\u95ED";
    }
    await executeScriptFiles(tabId, scriptKey);
    return "\u529F\u80FD\u5DF2\u5F00\u542F";
  }
  async function loadPersistentState() {
    const localState = await localStorageGet({
      [FEATURE_TAB_STATE_KEY]: {}
    });
    const storedFeatureTabs = localState[FEATURE_TAB_STATE_KEY] ?? {};
    for (const key of FEATURE_KEYS) {
      featureTabs[key] = new Set((storedFeatureTabs[key] ?? []).filter((value) => Number.isInteger(value)));
    }
    for (const tabId of featureTabs.mobileUserAgent) {
      try {
        await updateSessionRules(tabId, true);
      } catch {
        featureTabs.mobileUserAgent.delete(tabId);
      }
    }
    await persistFeatureTabs();
  }
  async function toggleFeature(key, tabId) {
    const enabled = !featureTabs[key].has(tabId);
    return setFeatureEnabled(key, tabId, enabled);
  }
  async function handleBridgeScriptCommand(payload, sender) {
    if (payload.Message !== "script" || typeof payload.script !== "string") {
      return;
    }
    const tabId = sender.tab?.id;
    const scriptKey = payload.script.replace(/\.js$/i, "");
    if (!tabId || !SCRIPT_FEATURE_KEYS.includes(scriptKey) || !featureTabs[scriptKey].has(tabId)) {
      return;
    }
    await setFeatureEnabled(scriptKey, tabId, false);
  }
  function handleTabRemoved(tabId) {
    for (const key of FEATURE_KEYS) {
      featureTabs[key].delete(tabId);
    }
    void updateSessionRules(tabId, false).catch(() => {
    });
    void persistFeatureTabs();
  }
  function handleNavigationCommitted(details) {
    if (details.tabId <= 0 || !/^https?:/i.test(details.url)) {
      return;
    }
    if (featureTabs.mobileUserAgent.has(details.tabId)) {
      void chrome.scripting.executeScript({
        args: [MOBILE_USER_AGENT],
        target: { tabId: details.tabId, frameIds: [details.frameId] },
        func: (userAgent) => {
          Object.defineProperty(navigator, "userAgent", { value: userAgent, writable: false });
        },
        injectImmediately: true,
        world: "MAIN"
      }).catch(() => {
      });
    }
    for (const key of SCRIPT_FEATURE_KEYS) {
      if (!featureTabs[key].has(details.tabId)) {
        continue;
      }
      const feature = CAT_CATCH_SCRIPT_FEATURES[key];
      if (!feature.allFrames && details.frameId !== MAIN_FRAME_ID) {
        continue;
      }
      void executeScriptFiles(
        details.tabId,
        key,
        feature.allFrames ? [details.frameId] : [MAIN_FRAME_ID]
      ).catch(() => {
      });
    }
  }
  return {
    createFeatureStateMap,
    handleBridgeScriptCommand,
    handleNavigationCommitted,
    handleTabRemoved,
    loadPersistentState,
    toggleFeature
  };
}

// src/shared/utils.ts
var IMAGE_EXTENSIONS = /* @__PURE__ */ new Set(["jpg", "jpeg", "png", "gif", "webp", "bmp", "svg", "avif", "heic"]);
var ARCHIVE_EXTENSIONS = /* @__PURE__ */ new Set(["zip", "7z", "rar", "tar", "gz", "bz2", "xz"]);
var PDF_EXTENSIONS = /* @__PURE__ */ new Set(["pdf"]);
var SPREADSHEET_EXTENSIONS = /* @__PURE__ */ new Set(["xls", "xlsx", "csv", "tsv", "ods", "numbers"]);
var DOCUMENT_EXTENSIONS = /* @__PURE__ */ new Set([
  "txt",
  "md",
  "rtf",
  "doc",
  "docx",
  "ppt",
  "pptx",
  "pages",
  "key",
  "epub"
]);
function shorten(value, max = 44) {
  if (!value || value.length <= max) {
    return value;
  }
  return `${value.slice(0, Math.max(0, max - 3))}...`;
}
function domainFromUrl(value) {
  try {
    return new URL(value).hostname;
  } catch {
    return "";
  }
}
function mimeFromUrl(value) {
  try {
    const mime = new URL(value).searchParams.get("mime_type")?.replace(/_/g, "/").toLowerCase() ?? "";
    return isCatCatchMedia("", mime) ? mime : "";
  } catch {
    return "";
  }
}
function filenameFromUrl(value) {
  try {
    const url = new URL(value);
    return decodeURIComponent(url.pathname.split("/").pop() || "");
  } catch {
    return "";
  }
}
function fileExtension(name) {
  const trimmed = String(name || "").trim();
  const dotIndex = trimmed.lastIndexOf(".");
  if (dotIndex < 0) {
    return "";
  }
  return trimmed.slice(dotIndex + 1).toLowerCase();
}
function inferParserHint(rawUrl, mime, extension) {
  const loweredUrl = String(rawUrl || "").toLowerCase();
  const loweredMime = String(mime || "").toLowerCase();
  const loweredExt = String(extension || "").toLowerCase();
  if (isCatCatchM3u8(loweredExt, loweredMime) || loweredUrl.includes(".m3u8")) {
    return "m3u8";
  }
  if (isCatCatchMpd(loweredExt, loweredMime) || loweredUrl.includes(".mpd")) {
    return "mpd";
  }
  if (isCatCatchMedia(loweredExt, loweredMime)) {
    return "media";
  }
  if (["zip", "7z", "rar", "pdf", "exe", "msi", "dmg", "pkg", "apk", "iso"].includes(loweredExt)) {
    return "download";
  }
  return "other";
}
function inferDashTrackKind(name, rawUrl) {
  const filename = String(name || filenameFromUrl(rawUrl) || "");
  const lowered = `${filename} ${rawUrl}`.toLowerCase();
  if (/(^|[-_.\\/])(video)([-_.\\/]|$)/i.test(lowered)) {
    return "video";
  }
  if (/(^|[-_.\\/])(audio)([-_.\\/]|$)/i.test(lowered)) {
    return "audio";
  }
  const match = lowered.match(/-(\d{5,6})(?=\.m4s(?:$|[?#]))/i) ?? lowered.match(/\/(\d{5,6})(?=\.m4s(?:$|[?#]))/i);
  const trackId = Number(match?.[1] ?? 0);
  if (!Number.isFinite(trackId) || trackId <= 0) {
    return "";
  }
  if (trackId >= 1e5) {
    return "video";
  }
  if (trackId >= 3e4 && trackId < 4e4) {
    return "audio";
  }
  return "";
}
function inferResourceMediaKind(resource, extension) {
  const mime = String(resource.mime || "").toLowerCase();
  if (extension === "m4s") {
    const dashKind = inferDashTrackKind(resource.filename, resource.url);
    if (dashKind) {
      return dashKind;
    }
  }
  if (mime.startsWith("video/")) {
    return "video";
  }
  if (mime.startsWith("audio/")) {
    return "audio";
  }
  if (CAT_CATCH_VIDEO_EXTENSIONS.has(extension) && !CAT_CATCH_AUDIO_EXTENSIONS.has(extension)) {
    return "video";
  }
  if (CAT_CATCH_AUDIO_EXTENSIONS.has(extension) && !CAT_CATCH_VIDEO_EXTENSIONS.has(extension)) {
    return "audio";
  }
  return "";
}
function inferDeliveryTarget(url) {
  return String(url || "").startsWith("blob:") ? "browser_download" : "gd3";
}
function inferVisualKind({
  extension,
  mime,
  parserHint
}) {
  const loweredMime = String(mime || "").toLowerCase();
  const loweredExtension = String(extension || "").toLowerCase();
  if (parserHint === "m3u8" || parserHint === "mpd") {
    return "stream";
  }
  if (loweredMime.startsWith("video/") || CAT_CATCH_VIDEO_EXTENSIONS.has(loweredExtension)) {
    return "video";
  }
  if (loweredMime.startsWith("audio/") || CAT_CATCH_AUDIO_EXTENSIONS.has(loweredExtension)) {
    return "audio";
  }
  if (loweredMime.startsWith("image/") || IMAGE_EXTENSIONS.has(loweredExtension)) {
    return "image";
  }
  if (ARCHIVE_EXTENSIONS.has(loweredExtension)) {
    return "archive";
  }
  if (PDF_EXTENSIONS.has(loweredExtension) || loweredMime === "application/pdf") {
    return "pdf";
  }
  if (SPREADSHEET_EXTENSIONS.has(loweredExtension) || loweredMime.includes("spreadsheet") || loweredMime.includes("excel") || loweredMime.includes("csv")) {
    return "spreadsheet";
  }
  if (DOCUMENT_EXTENSIONS.has(loweredExtension) || loweredMime.startsWith("text/")) {
    return "document";
  }
  return "download";
}
function resourceDerivedState(resource) {
  const extension = fileExtension(resource.filename || filenameFromUrl(resource.url));
  return {
    extension,
    parserHint: inferParserHint(resource.url, resource.mime, extension),
    deliveryTarget: inferDeliveryTarget(resource.url),
    mediaKind: inferResourceMediaKind(resource, extension)
  };
}
function resourcePrimaryBadge(resource, derived = resourceDerivedState(resource)) {
  if (derived.parserHint === "m3u8") {
    return "M3U8";
  }
  if (derived.parserHint === "mpd") {
    return "MPD";
  }
  if (derived.extension) {
    return derived.extension.slice(0, 6).toUpperCase();
  }
  if (resource.mime.startsWith("audio/")) {
    return "\u97F3\u9891";
  }
  if (resource.mime.startsWith("video/")) {
    return "\u89C6\u9891";
  }
  return "\u8D44\u6E90";
}
function describeResource(resource) {
  const derived = resourceDerivedState(resource);
  const mime = String(resource.mime || "").toLowerCase();
  let category = "all";
  if (derived.parserHint === "m3u8" || derived.parserHint === "mpd") {
    category = "streaming";
  } else if (derived.mediaKind === "audio") {
    category = "audio";
  } else if (derived.mediaKind === "video") {
    category = "video";
  }
  const primaryBadge = resourcePrimaryBadge(resource, derived);
  const needsDesktop = derived.deliveryTarget === "gd3";
  const statusText = resource.sentToDesktopAt ? needsDesktop ? "\u5DF2\u53D1\u9001\u5230 Ghost Downloader" : "\u5DF2\u4EA4\u7ED9\u6D4F\u89C8\u5668\u4E0B\u8F7D" : needsDesktop ? "\u53D1\u9001\u5230 Ghost Downloader" : "\u6D4F\u89C8\u5668\u4E0B\u8F7D";
  const tags = [primaryBadge];
  tags.push(derived.deliveryTarget === "browser_download" ? "\u6D4F\u89C8\u5668\u4E0B\u8F7D" : "GD3");
  if (!resource.sentToDesktopAt && (derived.parserHint === "m3u8" || derived.parserHint === "mpd")) {
    tags.push("\u6D41\u5A92\u4F53");
  }
  if (!resource.sentToDesktopAt && resource.requestHeaders && Object.keys(resource.requestHeaders).length > 0 && (derived.parserHint === "m3u8" || derived.parserHint === "mpd")) {
    tags.push("\u9700\u8BF7\u6C42\u5934");
  }
  if (!resource.sentToDesktopAt && (derived.parserHint === "download" || derived.parserHint === "media")) {
    tags.push("\u53EF\u76F4\u63A5\u4E0B\u8F7D");
  }
  const visual = {
    kind: inferVisualKind({
      extension: derived.extension,
      mime,
      parserHint: derived.parserHint
    })
  };
  return {
    extension: derived.extension,
    parserHint: derived.parserHint,
    deliveryTarget: derived.deliveryTarget,
    category,
    primaryBadge,
    statusText,
    actionLabel: needsDesktop ? "\u53D1\u9001\u5230 Ghost Downloader" : "\u6D4F\u89C8\u5668\u4E0B\u8F7D",
    needsDesktop,
    tags,
    visual
  };
}
function canUseOnlineMerge(resource) {
  const derived = resourceDerivedState(resource);
  if (derived.deliveryTarget !== "gd3") {
    return false;
  }
  const mime = String(resource.mime || "").toLowerCase();
  return derived.parserHint === "m3u8" || derived.parserHint === "mpd" || isCatCatchMedia(derived.extension, mime) || mime.endsWith("octet-stream");
}
function canUseOnlineMergeSelection(resources) {
  return resources.length === 2 && resources.every(canUseOnlineMerge);
}
function sortResourcesForOnlineMerge(resources) {
  return [...resources].sort((left, right) => {
    const leftCategory = describeResource(left).category;
    const rightCategory = describeResource(right).category;
    if (leftCategory === rightCategory) {
      return 0;
    }
    if (leftCategory === "video") {
      return -1;
    }
    if (rightCategory === "video") {
      return 1;
    }
    return 0;
  });
}

// src/background/media-bridge.ts
function createMediaBridge() {
  let mediaControlTarget = { tabId: 0, index: -1 };
  function createEmptyPlaybackState(message = "\u5F53\u524D\u672A\u68C0\u6D4B\u5230\u53EF\u63A7\u5236\u5A92\u4F53") {
    return {
      available: false,
      stale: false,
      message,
      tabId: null,
      mediaIndex: -1,
      frameId: 0,
      count: 0,
      currentTime: 0,
      duration: 0,
      progress: 0,
      volume: 1,
      paused: true,
      loop: false,
      muted: false,
      speed: 1,
      mediaType: ""
    };
  }
  function createEmptyMediaPanelState(message) {
    return {
      mediaItems: [],
      playbackState: createEmptyPlaybackState(message)
    };
  }
  function createMediaItems(srcList, count) {
    return Array.from({ length: count }, (_unused, index) => {
      const src = srcList[index] ?? `media-${index + 1}`;
      return {
        index,
        label: shorten(filenameFromUrl(src) || src.split("/").pop() || src, 48),
        type: "video"
      };
    });
  }
  function mediaFailureMessage(result) {
    switch (result.status) {
      case "no_receiver":
        return "\u5F53\u524D\u9875\u9762\u7684\u5A92\u4F53\u6865\u63A5\u8FD8\u6CA1\u6709\u51C6\u5907\u597D";
      case "runtime_error":
        return result.message || "\u8BFB\u53D6\u5A92\u4F53\u72B6\u6001\u5931\u8D25";
      case "no_response":
        return "\u9875\u9762\u6CA1\u6709\u8FD4\u56DE\u5A92\u4F53\u72B6\u6001";
      default:
        return "\u5F53\u524D\u9875\u9762\u672A\u68C0\u6D4B\u5230\u53EF\u63A7\u5236\u5A92\u4F53";
    }
  }
  async function requestMediaState(tabId, index) {
    return sendMessageToTab(
      tabId,
      { Message: "getVideoState", index },
      { frameId: MAIN_FRAME_ID }
    );
  }
  async function buildPanelState(activeTabId) {
    const tabId = activeTabId;
    let mediaIndex = mediaControlTarget.tabId === tabId ? mediaControlTarget.index : 0;
    if (!tabId) {
      return createEmptyMediaPanelState("\u5F53\u524D\u6CA1\u6709\u53EF\u64CD\u4F5C\u7684\u6807\u7B7E\u9875");
    }
    const result = await requestMediaState(tabId, mediaIndex >= 0 ? mediaIndex : 0);
    const state = result.response;
    if (result.status !== "ok" || !state?.count) {
      return createEmptyMediaPanelState(mediaFailureMessage(result));
    }
    const count = Number(state.count ?? 0);
    mediaIndex = mediaIndex >= 0 && mediaIndex < count ? mediaIndex : 0;
    const srcList = Array.isArray(state.src) ? state.src : [];
    const playbackState = {
      available: true,
      stale: false,
      message: "",
      tabId,
      mediaIndex,
      frameId: 0,
      count,
      currentTime: Number(state.currentTime ?? 0),
      duration: Number(state.duration ?? 0),
      progress: Number(state.time ?? 0),
      volume: Number(state.volume ?? 1),
      paused: Boolean(state.paused ?? true),
      loop: Boolean(state.loop ?? false),
      muted: Boolean(state.muted ?? false),
      speed: Number(state.speed ?? 1),
      mediaType: "video"
    };
    if (mediaControlTarget.tabId !== tabId || mediaControlTarget.index !== mediaIndex) {
      mediaControlTarget = { tabId, index: mediaIndex };
    }
    return {
      mediaItems: createMediaItems(srcList, count),
      playbackState
    };
  }
  function setMediaIndex(tabId, index) {
    mediaControlTarget = { tabId, index };
  }
  function handleTabRemoved(tabId) {
    if (mediaControlTarget.tabId === tabId) {
      mediaControlTarget = { tabId: 0, index: -1 };
    }
  }
  return {
    buildPanelState,
    handleTabRemoved,
    setMediaIndex
  };
}

// src/background/media-download-adapters.ts
var TWITTER_MEDIA_ID = /\/(?:amplify_video(?:_thumb)?|ext_tw_video|tweet_video)\/(\d+)\//i;
function hostEndsWith(url, suffix) {
  try {
    return new URL(url).hostname.endsWith(suffix);
  } catch {
    return false;
  }
}
function sameResource(left, right) {
  try {
    const leftUrl = new URL(left);
    const rightUrl = new URL(right);
    leftUrl.hash = "";
    rightUrl.hash = "";
    return leftUrl.toString() === rightUrl.toString();
  } catch {
    return left === right;
  }
}
function payloadResourceSet(payload) {
  return new Set([payload.url, ...payload.resourceUrls ?? []].filter(Boolean));
}
function matchesPayloadResource(resource, payloadUrls) {
  for (const url of payloadUrls) {
    if (sameResource(resource.url, url)) {
      return true;
    }
  }
  return false;
}
function mediaIdFromUrl(url) {
  return TWITTER_MEDIA_ID.exec(url)?.[1] ?? "";
}
function isStream(resource) {
  const hint = describeResource(resource).parserHint;
  return hint === "m3u8" || hint === "mpd";
}
function douyinKind(resource) {
  const mime = mimeFromUrl(resource.url) || resource.mime.toLowerCase();
  if (mime.startsWith("audio/")) {
    return "audio";
  }
  if (mime.startsWith("video/")) {
    return "video";
  }
  const category = describeResource(resource).category;
  return category === "audio" || category === "video" ? category : "";
}
function pickDouyinTrack(resources, kind, payloadUrls, videoId) {
  const rank = (resource) => (matchesPayloadResource(resource, payloadUrls) ? 2 : 0) + (videoId && resource.url.includes(`__vid=${videoId}`) ? 1 : 0);
  return resources.filter((resource) => douyinKind(resource) === kind).sort((left, right) => rank(right) - rank(left) || right.size - left.size || right.capturedAt - left.capturedAt)[0];
}
var adapters = [
  {
    matches: (pageUrl) => pageUrl.hostname === "x.com" || pageUrl.hostname.endsWith(".x.com"),
    pick: (resources, payload) => {
      const mediaId = mediaIdFromUrl(payload.poster ?? "") || mediaIdFromUrl(payload.url);
      const streams = resources.filter((resource) => isStream(resource) && hostEndsWith(resource.url, "video.twimg.com") && (!mediaId || resource.url.includes(`/${mediaId}/`)));
      return {
        exclusive: true,
        resources: streams.slice(0, 1),
        message: "X \u5F53\u524D\u5A92\u4F53\u53EA\u6355\u83B7\u5230\u5206\u7247\u65F6\u4E0D\u80FD\u4E00\u952E\u53D1\u9001\uFF0C\u8BF7\u5148\u5728\u8D44\u6E90\u55C5\u63A2\u9875\u9009\u62E9\u5B8C\u6574\u6E05\u5355"
      };
    }
  },
  {
    matches: (pageUrl) => pageUrl.hostname === "www.douyin.com" || pageUrl.hostname.endsWith(".douyin.com"),
    pick: (resources, payload, pageUrl) => {
      const videoId = pageUrl.searchParams.get("modal_id") ?? "";
      const payloadUrls = payloadResourceSet(payload);
      const douyinResources = resources.filter((resource) => hostEndsWith(resource.url, "douyinvod.com"));
      const video = pickDouyinTrack(douyinResources, "video", payloadUrls, videoId);
      const audio = pickDouyinTrack(douyinResources, "audio", payloadUrls, videoId);
      return {
        exclusive: true,
        resources: video && audio ? [video, audio] : [],
        message: "Douyin \u5F53\u524D\u5A92\u4F53\u9700\u8981\u540C\u65F6\u6355\u83B7\u89C6\u9891\u548C\u97F3\u9891\u540E\u624D\u80FD\u4E00\u952E\u5408\u5E76\uFF0C\u8BF7\u64AD\u653E\u51E0\u79D2\u540E\u91CD\u8BD5"
      };
    }
  }
];
function pickSiteMediaResources(resources, payload) {
  try {
    const pageUrl = new URL(payload.href || "");
    const adapter = adapters.find((item) => item.matches(pageUrl));
    return adapter ? adapter.pick(resources, payload, pageUrl) : null;
  } catch {
    return null;
  }
}

// src/background/resource-bridge.ts
var HEADER_WHITELIST = /* @__PURE__ */ new Set([
  "accept",
  "accept-language",
  "authorization",
  "cookie",
  "origin",
  "referer",
  "sec-ch-ua",
  "sec-ch-ua-arch",
  "sec-ch-ua-bitness",
  "sec-ch-ua-full-version",
  "sec-ch-ua-full-version-list",
  "sec-ch-ua-mobile",
  "sec-ch-ua-model",
  "sec-ch-ua-platform",
  "sec-ch-ua-platform-version",
  "sec-fetch-dest",
  "sec-fetch-mode",
  "sec-fetch-site",
  "user-agent",
  "priority"
]);
var MIME_EXTENSIONS = {
  "application/dash+xml": "mpd",
  "application/mpegurl": "m3u8",
  "application/vnd.apple.mpegurl": "m3u8",
  "application/x-mpegurl": "m3u8",
  "audio/aac": "aac",
  "audio/flac": "flac",
  "audio/mp4": "m4a",
  "audio/mpeg": "mp3",
  "audio/ogg": "ogg",
  "audio/wav": "wav",
  "audio/webm": "webm",
  "video/mp2t": "ts",
  "video/mp4": "mp4",
  "video/quicktime": "mov",
  "video/webm": "webm",
  "video/x-flv": "flv",
  "video/x-m4v": "m4v",
  "video/x-ms-wmv": "wmv"
};
function createResourceBridge(options) {
  let bridgePersistTimer = null;
  let bridgeStateReady = false;
  let lastActiveTabId = null;
  const resourceCache = /* @__PURE__ */ new Map();
  const resourcesById = /* @__PURE__ */ new Map();
  const headerSnapshotsByUrl = /* @__PURE__ */ new Map();
  function normalizeHeaders(headers) {
    const result = {};
    for (const [key, value] of Object.entries(headers ?? {})) {
      const name = String(key || "").trim().toLowerCase();
      if (!HEADER_WHITELIST.has(name)) {
        continue;
      }
      const text = String(value ?? "").trim();
      if (!text) {
        continue;
      }
      result[name] = text;
    }
    return result;
  }
  function trimFilename(value) {
    const text = String(value || "").trim();
    if (!text) {
      return "";
    }
    const slashIndex = Math.max(text.lastIndexOf("/"), text.lastIndexOf("\\"));
    return slashIndex >= 0 ? text.slice(slashIndex + 1) : text;
  }
  function isCapturableUrl(rawUrl) {
    return /^https?:/i.test(rawUrl);
  }
  function sortResources(resources) {
    return [...resources].sort((left, right) => right.capturedAt - left.capturedAt);
  }
  function normalizeUrl(value, allowBlob = false) {
    const text = String(value || "").trim();
    if (!text) {
      return "";
    }
    if (allowBlob && text.startsWith("blob:")) {
      return text;
    }
    try {
      const url = new URL(text);
      url.hash = "";
      return url.toString();
    } catch {
      return text.split("#", 1)[0] ?? text;
    }
  }
  function normalizeCapturedResource(resource) {
    return {
      id: String(resource.id ?? ""),
      tabId: Number(resource.tabId),
      url: String(resource.url ?? ""),
      pageTitle: String(resource.pageTitle ?? ""),
      pageUrl: String(resource.pageUrl ?? ""),
      filename: String(resource.filename ?? ""),
      mime: String(resource.mime ?? "").toLowerCase(),
      size: Number(resource.size ?? 0),
      supportsRange: Boolean(resource.supportsRange),
      referer: String(resource.referer ?? ""),
      requestHeaders: normalizeHeaders(resource.requestHeaders),
      capturedAt: Number(resource.capturedAt ?? Date.now()),
      sentToDesktopAt: resource.sentToDesktopAt ? Number(resource.sentToDesktopAt) : void 0
    };
  }
  function normalizeBridgeHeaderSnapshot(snapshot) {
    return {
      url: String(snapshot.url ?? ""),
      headers: normalizeHeaders(snapshot.headers),
      capturedAt: Number(snapshot.capturedAt ?? Date.now()),
      tabId: Number.isInteger(snapshot.tabId) ? Number(snapshot.tabId) : null,
      supportsRange: Boolean(snapshot.supportsRange)
    };
  }
  function responseMeta(headers) {
    const meta = { size: 0, mime: "", filename: "", supportsRange: false };
    let contentLengthSize = 0;
    let contentRangeSize = 0;
    for (const header of headers ?? []) {
      const name = String(header.name ?? "").toLowerCase();
      const value = String(header.value ?? "").trim();
      if (name === "content-length") {
        const size = Number.parseInt(value, 10);
        contentLengthSize = Number.isFinite(size) && size > 0 ? size : contentLengthSize;
      } else if (name === "content-type") {
        meta.mime = value.split(";")[0]?.trim().toLowerCase() ?? "";
      } else if (name === "content-disposition") {
        const match = /filename\*\s*=\s*UTF-8''([^;]+)|filename\s*=\s*"?([^";]+)"?/i.exec(value);
        const filename = match?.[1] ?? match?.[2] ?? "";
        try {
          meta.filename = trimFilename(decodeURIComponent(filename));
        } catch {
          meta.filename = trimFilename(filename);
        }
      } else if (name === "accept-ranges") {
        meta.supportsRange = value.toLowerCase().includes("bytes");
      } else if (name === "content-range") {
        const size = Number.parseInt(value.split("/")[1] ?? "", 10);
        contentRangeSize = Number.isFinite(size) && size > 0 ? size : contentRangeSize;
        meta.supportsRange = true;
      }
    }
    meta.size = contentRangeSize || contentLengthSize;
    return meta;
  }
  function shouldBlockParsedDownload(url, meta) {
    return Boolean(options.shouldBlockDownload?.({
      url,
      filename: meta.filename || trimFilename(filenameFromUrl(url)),
      mime: meta.mime || mimeFromUrl(url),
      size: meta.size > 0 ? meta.size : void 0
    }));
  }
  function shouldCaptureNetworkResource(details, meta) {
    if (!isCapturableUrl(details.url)) {
      return false;
    }
    const extension = fileExtension(meta.filename || filenameFromUrl(details.url));
    return details.type === "media" || isCatCatchMedia(extension, meta.mime);
  }
  function shouldCaptureRequestResource(details) {
    if (!isCapturableUrl(details.url)) {
      return false;
    }
    return details.type === "media" || isCatCatchMedia(fileExtension(filenameFromUrl(details.url)), mimeFromUrl(details.url));
  }
  function urlsLikelySamePage(left, right) {
    const normalizedLeft = normalizeUrl(left);
    const normalizedRight = normalizeUrl(right);
    if (!normalizedLeft || !normalizedRight) {
      return false;
    }
    return normalizedLeft === normalizedRight || normalizedLeft.startsWith(normalizedRight) || normalizedRight.startsWith(normalizedLeft);
  }
  async function resolveTabIdFromPageUrl(pageUrl) {
    const normalizedPageUrl = normalizeUrl(pageUrl);
    if (!normalizedPageUrl) {
      return null;
    }
    const tabs = await queryTabs({});
    const exactMatch = tabs.find((tab) => tab.id && tab.url && urlsLikelySamePage(tab.url, normalizedPageUrl));
    if (exactMatch?.id) {
      return exactMatch.id;
    }
    try {
      const initiatorUrl = new URL(normalizedPageUrl);
      const originMatch = tabs.find((tab) => {
        if (!tab.id || !tab.url) {
          return false;
        }
        try {
          return new URL(tab.url).origin === initiatorUrl.origin;
        } catch {
          return false;
        }
      });
      if (originMatch?.id) {
        return originMatch.id;
      }
    } catch {
    }
    return null;
  }
  async function persistBridgeState() {
    bridgePersistTimer = null;
    pruneHeaderSnapshots();
    await bridgeStorageSet({
      [BRIDGE_RESOURCE_CACHE_KEY]: serializeResourceCache(),
      [BRIDGE_HEADER_SNAPSHOTS_KEY]: [...headerSnapshotsByUrl.values()],
      [BRIDGE_LAST_ACTIVE_TAB_KEY]: lastActiveTabId ?? 0
    });
  }
  function scheduleBridgeStatePersist() {
    if (bridgePersistTimer !== null) {
      return;
    }
    bridgePersistTimer = self.setTimeout(() => {
      void persistBridgeState();
    }, BRIDGE_PERSIST_DEBOUNCE_MS);
  }
  function serializeResourceCache() {
    const result = {};
    for (const [tabId, bucket] of resourceCache.entries()) {
      result[String(tabId)] = sortResources(bucket.values()).slice(0, RESOURCE_LIMIT);
    }
    return result;
  }
  function pruneHeaderSnapshots() {
    const now = Date.now();
    const snapshots = [...headerSnapshotsByUrl.values()].filter((snapshot) => snapshot.url && now - snapshot.capturedAt <= HEADER_EXPIRATION_MS).sort((left, right) => right.capturedAt - left.capturedAt).slice(0, HEADER_SNAPSHOT_LIMIT);
    headerSnapshotsByUrl.clear();
    for (const snapshot of snapshots) {
      headerSnapshotsByUrl.set(snapshot.url, snapshot);
    }
  }
  function clearResourcesForTab(tabId) {
    const bucket = resourceCache.get(tabId);
    if (!bucket) {
      return;
    }
    for (const resourceId of bucket.keys()) {
      resourcesById.delete(resourceId);
    }
    resourceCache.delete(tabId);
    scheduleBridgeStatePersist();
  }
  function clearHeaderSnapshotsForTab(tabId) {
    let changed = false;
    for (const [url, snapshot] of headerSnapshotsByUrl.entries()) {
      if (snapshot.tabId === tabId) {
        headerSnapshotsByUrl.delete(url);
        changed = true;
      }
    }
    if (changed) {
      scheduleBridgeStatePersist();
    }
  }
  async function setLastActiveTab(tabId) {
    if (lastActiveTabId === tabId) {
      return;
    }
    lastActiveTabId = tabId;
    scheduleBridgeStatePersist();
  }
  async function refreshActiveTabFromBrowser() {
    const tabs = await queryTabs({ active: true, currentWindow: true });
    const tabId = tabs[0]?.id ?? null;
    await setLastActiveTab(tabId);
    return tabId;
  }
  async function resolveActiveTabId(preferredTabId = null) {
    if (preferredTabId != null) {
      const preferredTab = await getTab(preferredTabId);
      if (preferredTab?.id) {
        await setLastActiveTab(preferredTab.id);
        return preferredTab.id;
      }
    }
    const activeTabId = await refreshActiveTabFromBrowser();
    if (activeTabId != null) {
      return activeTabId;
    }
    if (lastActiveTabId != null) {
      const current = await getTab(lastActiveTabId);
      if (current?.id) {
        return current.id;
      }
    }
    return null;
  }
  function filenameWithExtension(baseName, extension) {
    const trimmedBaseName = cleanFilename(baseName) || "resource";
    const normalizedExt = extension.trim().replace(/^\./, "").toLowerCase();
    if (!normalizedExt) {
      return trimmedBaseName;
    }
    if (fileExtension(trimmedBaseName) === normalizedExt) {
      return trimmedBaseName;
    }
    return `${trimmedBaseName}.${normalizedExt}`;
  }
  function cleanFilename(value) {
    return (value ?? "").trim().replace(/[<>:"/\\|?*\x00-\x1f]+/g, " ").replace(/\s+/g, " ").replace(/[. ]+$/g, "").trim().slice(0, 160);
  }
  function extensionFromMime(mime) {
    const type = mime?.split(";")[0]?.trim().toLowerCase() ?? "";
    return MIME_EXTENSIONS[type] ?? "";
  }
  function resolveBridgeFilename(payload) {
    const ext = payload.ext?.trim() || extensionFromMime(payload.mime);
    const explicit = cleanFilename(payload.filename);
    if (explicit) {
      return ext && !fileExtension(explicit) ? filenameWithExtension(explicit, ext) : explicit;
    }
    const fromUrl = cleanFilename(filenameFromUrl(payload.url));
    if (fromUrl) {
      return ext ? filenameWithExtension(fromUrl, ext) : fromUrl;
    }
    return ext ? filenameWithExtension("resource", ext) : "resource";
  }
  function filenameForDesktop(resource) {
    const urlFilename = filenameFromUrl(resource.url);
    const current = cleanFilename(resource.filename || urlFilename);
    const extension = fileExtension(current) || fileExtension(urlFilename) || extensionFromMime(resource.mime);
    const title = cleanFilename(resource.pageTitle);
    const baseName = title || current || "resource";
    return filenameWithExtension(baseName, extension);
  }
  async function resolveBridgeResourceTabId(sender, href) {
    if (sender.tab?.id) {
      await setLastActiveTab(sender.tab.id);
      return sender.tab.id;
    }
    const normalizedHref = href?.trim() ?? "";
    if (normalizedHref) {
      const matchedTabId = await resolveTabIdFromPageUrl(normalizedHref);
      if (matchedTabId != null) {
        return matchedTabId;
      }
    }
    return resolveActiveTabId();
  }
  async function resolveNetworkResourceTabId(details) {
    if (details.tabId > 0) {
      return details.tabId;
    }
    const snapshotTabId = resolveHeaderSnapshot(details.url)?.tabId;
    if (snapshotTabId != null) {
      return snapshotTabId;
    }
    const matchedTabId = await resolveTabIdFromPageUrl(details.initiator ?? "");
    return matchedTabId ?? resolveActiveTabId();
  }
  function bucketForTab(tabId) {
    const existing = resourceCache.get(tabId);
    if (existing) {
      return existing;
    }
    const bucket = /* @__PURE__ */ new Map();
    resourceCache.set(tabId, bucket);
    return bucket;
  }
  function trimBucket(tabId) {
    const bucket = resourceCache.get(tabId);
    if (!bucket || bucket.size <= RESOURCE_LIMIT) {
      return;
    }
    const keepIds = new Set(sortResources(bucket.values()).slice(0, RESOURCE_LIMIT).map((resource) => resource.id));
    for (const resourceId of bucket.keys()) {
      if (keepIds.has(resourceId)) {
        continue;
      }
      bucket.delete(resourceId);
      resourcesById.delete(resourceId);
    }
  }
  function cacheResource(resource) {
    const bucket = bucketForTab(resource.tabId);
    const existing = bucket.get(resource.id);
    const merged = existing ? {
      ...existing,
      ...resource,
      pageTitle: resource.pageTitle || existing.pageTitle,
      pageUrl: resource.pageUrl || existing.pageUrl,
      filename: resource.filename || existing.filename,
      mime: resource.mime || existing.mime,
      size: resource.size > 0 ? resource.size : existing.size,
      supportsRange: resource.supportsRange || existing.supportsRange,
      referer: resource.referer || existing.referer,
      requestHeaders: {
        ...resource.requestHeaders,
        ...existing.requestHeaders
      },
      capturedAt: Math.max(existing.capturedAt, resource.capturedAt),
      sentToDesktopAt: existing.sentToDesktopAt ?? resource.sentToDesktopAt
    } : resource;
    bucket.set(merged.id, merged);
    resourcesById.set(merged.id, merged);
    const mergedUrl = normalizeUrl(merged.url, true);
    if (mergedUrl && (merged.size > 0 || merged.mime || merged.supportsRange)) {
      for (const resource2 of resourcesById.values()) {
        if (resource2.id === merged.id || !resource2.id.endsWith(`:${mergedUrl}`)) {
          continue;
        }
        resource2.size = merged.size > 0 ? merged.size : resource2.size;
        resource2.mime = merged.mime || resource2.mime;
        resource2.filename = resource2.filename && resource2.filename !== "resource" ? resource2.filename : merged.filename;
        resource2.supportsRange = merged.supportsRange || resource2.supportsRange;
      }
    }
    trimBucket(resource.tabId);
    scheduleBridgeStatePersist();
  }
  function findResourceByUrl(rawUrl, tabId) {
    const resourceIdSuffix = `:${normalizeUrl(rawUrl, true)}`;
    let matched = null;
    const resources = tabId == null ? resourcesById.values() : resourceCache.get(tabId)?.values() ?? [];
    for (const resource of resources) {
      if (!resource.id.endsWith(resourceIdSuffix)) {
        continue;
      }
      if (matched == null || resource.capturedAt > matched.capturedAt) {
        matched = resource;
      }
    }
    return matched;
  }
  function markResourceSent(resourceId) {
    const resource = resourcesById.get(resourceId);
    if (!resource) {
      return;
    }
    resource.sentToDesktopAt = Date.now();
    scheduleBridgeStatePersist();
  }
  function rememberHeaderSnapshot(url, headers, tabId, supportsRange) {
    const existing = headerSnapshotsByUrl.get(url);
    const mergedHeaders = {
      ...existing?.headers ?? {},
      ...headers
    };
    const mergedSupportsRange = supportsRange || Boolean(existing?.supportsRange);
    if (Object.keys(mergedHeaders).length === 0 && !mergedSupportsRange) {
      return;
    }
    headerSnapshotsByUrl.set(url, {
      url,
      headers: mergedHeaders,
      capturedAt: Date.now(),
      tabId: tabId ?? existing?.tabId ?? null,
      supportsRange: mergedSupportsRange
    });
    pruneHeaderSnapshots();
    scheduleBridgeStatePersist();
  }
  function resolveHeaderSnapshot(url) {
    pruneHeaderSnapshots();
    return headerSnapshotsByUrl.get(url) ?? null;
  }
  function otherResourcesForTab(activeTabId) {
    const result = [];
    for (const [tabId, bucket] of resourceCache.entries()) {
      if (activeTabId != null && tabId === activeTabId) {
        continue;
      }
      result.push(...bucket.values());
    }
    return sortResources(result);
  }
  function canSendOneClickResource(resource) {
    const hint = describeResource(resource).parserHint;
    return hint === "m3u8" || hint === "mpd" || resource.size > 0 || resource.supportsRange;
  }
  function recentAudioVideoPair(resources) {
    const recentResources = resources.filter((resource) => Date.now() - resource.capturedAt <= 12e4);
    const video = recentResources.find((resource) => describeResource(resource).category === "video");
    const audio = recentResources.find((resource) => describeResource(resource).category === "audio");
    if (!video || !audio || Math.abs(video.capturedAt - audio.capturedAt) > 3e4) {
      return [];
    }
    return canUseOnlineMergeSelection([video, audio]) ? [video, audio] : [];
  }
  function deriveMergeOutputTitle(resources) {
    const pageTitle = (resources[0]?.pageTitle ?? "").trim();
    if (pageTitle) {
      return pageTitle;
    }
    const firstFileName = trimFilename(resources[0]?.filename || filenameFromUrl(resources[0]?.url || ""));
    if (firstFileName) {
      const extension = fileExtension(firstFileName);
      return extension ? firstFileName.slice(0, -(extension.length + 1)) : firstFileName;
    }
    return "merged-media";
  }
  async function downloadResourceViaBrowser(resource) {
    const filename = filenameForDesktop(resource);
    return new Promise((resolve, reject) => {
      chrome.downloads.download(
        {
          url: resource.url,
          filename
        },
        (downloadId) => {
          const lastError = chrome.runtime.lastError;
          if (lastError) {
            reject(new Error(lastError.message));
            return;
          }
          if (typeof downloadId !== "number") {
            reject(new Error("\u6D4F\u89C8\u5668\u672A\u8FD4\u56DE\u4E0B\u8F7D\u4EFB\u52A1"));
            return;
          }
          resolve();
        }
      );
    });
  }
  async function loadPersistentState() {
    const bridgeState = await bridgeStorageGet({
      [BRIDGE_RESOURCE_CACHE_KEY]: {},
      [BRIDGE_HEADER_SNAPSHOTS_KEY]: [],
      [BRIDGE_LAST_ACTIVE_TAB_KEY]: 0
    });
    resourceCache.clear();
    resourcesById.clear();
    for (const [tabIdText, resources] of Object.entries(bridgeState[BRIDGE_RESOURCE_CACHE_KEY] ?? {})) {
      const tabId = Number(tabIdText);
      if (!Number.isInteger(tabId) || tabId <= 0 || !Array.isArray(resources)) {
        continue;
      }
      const bucket = /* @__PURE__ */ new Map();
      for (const resource of sortResources(resources.map(normalizeCapturedResource)).slice(0, RESOURCE_LIMIT)) {
        bucket.set(resource.id, resource);
        resourcesById.set(resource.id, resource);
      }
      resourceCache.set(tabId, bucket);
    }
    headerSnapshotsByUrl.clear();
    for (const snapshot of bridgeState[BRIDGE_HEADER_SNAPSHOTS_KEY] ?? []) {
      const normalized = normalizeBridgeHeaderSnapshot(snapshot);
      if (!normalized.url) {
        continue;
      }
      headerSnapshotsByUrl.set(normalized.url, normalized);
    }
    pruneHeaderSnapshots();
    lastActiveTabId = Number(bridgeState[BRIDGE_LAST_ACTIVE_TAB_KEY] ?? 0) || null;
    bridgeStateReady = true;
  }
  async function capturePageResource(sender, payload) {
    const tabId = await resolveBridgeResourceTabId(sender, payload.href);
    if (!tabId || !/^(https?:|blob:)/i.test(payload.url)) {
      return;
    }
    const tab = await getTab(tabId);
    const headerSnapshot = resolveHeaderSnapshot(payload.url);
    const headers = {
      ...headerSnapshot?.headers ?? {},
      ...normalizeHeaders(payload.requestHeaders)
    };
    const filename = resolveBridgeFilename(payload);
    const mime = payload.mime?.toLowerCase() || mimeFromUrl(payload.url);
    cacheResource({
      id: `${tabId}:${normalizeUrl(payload.url, true)}`,
      tabId,
      url: payload.url,
      pageTitle: tab?.title ?? "",
      pageUrl: payload.href ?? tab?.url ?? "",
      filename,
      mime,
      size: 0,
      supportsRange: Boolean(headerSnapshot?.supportsRange),
      referer: headers.referer ?? payload.href ?? tab?.url ?? "",
      requestHeaders: headers,
      capturedAt: Date.now()
    });
  }
  async function captureNetworkResource(details) {
    const meta = responseMeta(details.responseHeaders);
    meta.mime = mimeFromUrl(details.url) || meta.mime;
    const responseSupportsRange = meta.supportsRange || details.statusCode === 206;
    if (responseSupportsRange && isCapturableUrl(details.url)) {
      rememberHeaderSnapshot(details.url, {}, details.tabId > 0 ? details.tabId : lastActiveTabId, true);
    }
    if (!shouldCaptureNetworkResource(details, meta)) {
      return;
    }
    const tabId = await resolveNetworkResourceTabId(details);
    if (!tabId) {
      return;
    }
    const tab = await getTab(tabId);
    const headerSnapshot = resolveHeaderSnapshot(details.url);
    const headers = { ...headerSnapshot?.headers ?? {} };
    const referer = headers.referer || (details.initiator && details.initiator !== "null" ? details.initiator : tab?.url) || "";
    if (referer) {
      headers.referer = referer;
    }
    cacheResource({
      id: `${tabId}:${normalizeUrl(details.url, true)}`,
      tabId,
      url: details.url,
      pageTitle: tab?.title ?? "",
      pageUrl: details.initiator && details.initiator !== "null" ? details.initiator : tab?.url ?? "",
      filename: meta.filename || trimFilename(filenameFromUrl(details.url)) || "resource",
      mime: meta.mime,
      size: meta.size,
      supportsRange: responseSupportsRange || Boolean(headerSnapshot?.supportsRange),
      referer,
      requestHeaders: headers,
      capturedAt: Date.now()
    });
  }
  async function captureRequestResource(details) {
    if (!shouldCaptureRequestResource(details)) {
      return;
    }
    const tabId = details.tabId > 0 ? details.tabId : lastActiveTabId ?? await resolveActiveTabId();
    if (!tabId) {
      return;
    }
    const tab = await getTab(tabId);
    const headerSnapshot = resolveHeaderSnapshot(details.url);
    const headers = { ...headerSnapshot?.headers ?? {} };
    const referer = headers.referer || (details.initiator && details.initiator !== "null" ? details.initiator : tab?.url) || "";
    if (referer) {
      headers.referer = referer;
    }
    cacheResource({
      id: `${tabId}:${normalizeUrl(details.url, true)}`,
      tabId,
      url: details.url,
      pageTitle: tab?.title ?? "",
      pageUrl: details.initiator && details.initiator !== "null" ? details.initiator : tab?.url ?? "",
      filename: trimFilename(filenameFromUrl(details.url)) || "resource",
      mime: mimeFromUrl(details.url),
      size: 0,
      supportsRange: Boolean(headerSnapshot?.supportsRange),
      referer,
      requestHeaders: headers,
      capturedAt: Date.now()
    });
  }
  function responseHeaderValue(headers, headerName) {
    const normalizedName = headerName.toLowerCase();
    return String(
      (headers ?? []).find((header) => String(header.name ?? "").toLowerCase() === normalizedName)?.value ?? ""
    ).trim();
  }
  function isLikelyFirefoxDownloadResponse(details, meta) {
    if (!isCapturableUrl(details.url)) {
      return false;
    }
    const statusCode = Number(details.statusCode ?? 0);
    if (statusCode < 200 || statusCode >= 400) {
      return false;
    }
    const contentDisposition = responseHeaderValue(details.responseHeaders, "content-disposition").toLowerCase();
    const isAttachment = contentDisposition.includes("attachment");
    const extension = fileExtension(meta.filename || filenameFromUrl(details.url));
    const mime = (mimeFromUrl(details.url) || meta.mime || "").toLowerCase();
    if (isAttachment || meta.filename) {
      return true;
    }
    if (!extension && !mime) {
      return false;
    }
    if (mime.startsWith("text/html") || mime.startsWith("text/css") || mime.startsWith("text/javascript") || mime.includes("javascript") || mime === "application/json" || mime === "application/xml" || mime === "text/xml") {
      return false;
    }
    return isCatCatchMedia(extension, mime) || Boolean(extension && meta.size > 0) || mime === "application/octet-stream" || mime === "application/x-msdownload" || mime === "application/x-zip-compressed" || mime === "application/zip";
  }
  async function tryInterceptFirefoxDownload(details) {
    const meta = responseMeta(details.responseHeaders);
    meta.mime = mimeFromUrl(details.url) || meta.mime;
    if (shouldBlockParsedDownload(details.url, meta)) {
      return void 0;
    }
    if (!isLikelyFirefoxDownloadResponse(details, meta)) {
      return void 0;
    }
    const finalUrl = details.url;
    const headerSnapshot = resolveHeaderSnapshot(finalUrl);
    const headers = { ...headerSnapshot?.headers ?? {} };
    const referer = headers.referer || (details.originUrl && details.originUrl !== "null" ? details.originUrl : "") || (details.initiator && details.initiator !== "null" ? details.initiator : "");
    if (referer) {
      headers.referer = referer;
    }
    const resolvedFilename = meta.filename || trimFilename(filenameFromUrl(finalUrl)) || "resource";
    void options.sendDesktopRequest({
      type: "create_task",
      source: "download",
      title: resolvedFilename,
      payload: {
        url: finalUrl,
        headers,
        filename: resolvedFilename,
        size: meta.size,
        supportsRange: Boolean(meta.supportsRange || headerSnapshot?.supportsRange)
      }
    }).then((result) => {
      if (result.ok) {
        void openActionPopup();
      }
    }).catch(() => {
    });
    return { cancel: true };
  }
  async function handoffBrowserDownload(downloadItem) {
    const finalUrl = downloadItem.finalUrl || downloadItem.url;
    const matchedResource = findResourceByUrl(finalUrl) ?? (downloadItem.url !== finalUrl ? findResourceByUrl(downloadItem.url) : null);
    const resolvedFilename = trimFilename(downloadItem.filename) || trimFilename(matchedResource?.filename ?? "") || trimFilename(filenameFromUrl(finalUrl)) || "resource";
    if (options.shouldBlockDownload?.({
      url: finalUrl,
      filename: resolvedFilename,
      mime: matchedResource?.mime ?? "",
      size: typeof downloadItem.totalBytes === "number" && downloadItem.totalBytes > 0 ? downloadItem.totalBytes : matchedResource?.size
    })) {
      return;
    }
    const headerSnapshot = resolveHeaderSnapshot(finalUrl) ?? (downloadItem.url !== finalUrl ? resolveHeaderSnapshot(downloadItem.url) : null);
    const headers = { ...headerSnapshot?.headers ?? {} };
    if (downloadItem.referrer && !headers.referer) {
      headers.referer = downloadItem.referrer;
    }
    try {
      const result = await options.sendDesktopRequest({
        type: "create_task",
        source: "download",
        title: resolvedFilename,
        payload: {
          url: finalUrl,
          headers,
          filename: resolvedFilename,
          size: typeof downloadItem.totalBytes === "number" && downloadItem.totalBytes > 0 ? downloadItem.totalBytes : matchedResource?.size ?? 0,
          supportsRange: Boolean(
            matchedResource?.supportsRange || headerSnapshot?.supportsRange || downloadItem.canResume === true
          )
        }
      });
      if (result.ok) {
        await openActionPopup();
      }
    } catch {
    }
  }
  async function sendHttpResourceToDesktop(resource) {
    const filename = filenameForDesktop(resource);
    try {
      const result = await options.sendDesktopRequest({
        type: "create_task",
        source: "resource",
        title: filename,
        payload: {
          url: resource.url,
          headers: resource.requestHeaders,
          filename,
          size: resource.size,
          supportsRange: resource.supportsRange
        }
      });
      if (result.ok) {
        markResourceSent(resource.id);
        return {
          ...result,
          message: result.message || "\u8D44\u6E90\u5DF2\u53D1\u9001\u5230 Ghost Downloader"
        };
      }
      return result;
    } catch (error) {
      return {
        ok: false,
        message: error instanceof Error ? error.message : "\u53D1\u9001\u8D44\u6E90\u5931\u8D25"
      };
    }
  }
  async function sendResource(resourceId) {
    const resource = resourcesById.get(resourceId) ?? null;
    if (!resource) {
      return { ok: false, message: "\u8D44\u6E90\u4E0D\u5B58\u5728" };
    }
    try {
      if (resource.url.startsWith("blob:")) {
        await downloadResourceViaBrowser(resource);
        markResourceSent(resource.id);
        return {
          ok: true,
          message: "\u8D44\u6E90\u5DF2\u4EA4\u7ED9\u6D4F\u89C8\u5668\u4E0B\u8F7D"
        };
      }
      return await sendHttpResourceToDesktop(resource);
    } catch (error) {
      return {
        ok: false,
        message: error instanceof Error ? error.message : "\u53D1\u9001\u8D44\u6E90\u5931\u8D25"
      };
    }
  }
  async function downloadPageMedia(sender, payload) {
    const tabId = await resolveBridgeResourceTabId(sender, payload.href);
    if (!tabId) {
      return { ok: false, message: "\u5F53\u524D\u6CA1\u6709\u53EF\u64CD\u4F5C\u7684\u6807\u7B7E\u9875" };
    }
    const downloadableResources = sortResources(resourceCache.get(tabId)?.values() ?? []).filter((resource) => /^https?:/i.test(resource.url) && canSendOneClickResource(resource));
    const candidates = downloadableResources.filter(canUseOnlineMerge);
    const siteSelection = pickSiteMediaResources(downloadableResources, payload);
    if (siteSelection?.resources.length === 1) {
      return sendResource(siteSelection.resources[0].id);
    }
    if (siteSelection?.resources.length === 2) {
      return mergeResources(siteSelection.resources.map((resource) => resource.id));
    }
    if (siteSelection?.exclusive) {
      await openActionPopup();
      return {
        ok: false,
        message: siteSelection.message || "\u8BF7\u5728\u8D44\u6E90\u55C5\u63A2\u9875\u9009\u62E9\u5F53\u524D\u5A92\u4F53\u8D44\u6E90"
      };
    }
    const exactResource = payload.url ? findResourceByUrl(payload.url, tabId) : null;
    if (exactResource && canSendOneClickResource(exactResource)) {
      return sendResource(exactResource.id);
    }
    const streamResource = candidates.find((resource) => {
      const hint = describeResource(resource).parserHint;
      return hint === "m3u8" || hint === "mpd";
    });
    if (streamResource) {
      return sendResource(streamResource.id);
    }
    const pair = recentAudioVideoPair(candidates);
    if (pair.length === 2) {
      return mergeResources(pair.map((resource) => resource.id));
    }
    if (candidates.length === 1) {
      return sendResource(candidates[0].id);
    }
    await openActionPopup();
    return {
      ok: false,
      message: candidates.length > 1 ? "\u627E\u5230\u591A\u4E2A\u5A92\u4F53\u8D44\u6E90\uFF0C\u8BF7\u5728\u8D44\u6E90\u55C5\u63A2\u9875\u9009\u62E9" : "\u5C1A\u672A\u6355\u83B7\u5230\u53EF\u4E0B\u8F7D\u5A92\u4F53\u8D44\u6E90"
    };
  }
  async function mergeResources(resourceIds) {
    const ids = [...new Set(resourceIds.filter(Boolean))];
    const resources = ids.map((resourceId) => resourcesById.get(resourceId) ?? null).filter((resource) => resource != null);
    if (resources.length !== 2) {
      return {
        ok: false,
        message: "\u5728\u7EBF\u5408\u5E76\u6682\u65F6\u53EA\u652F\u6301\u9009\u4E2D 2 \u4E2A\u8D44\u6E90"
      };
    }
    if (!canUseOnlineMergeSelection(resources)) {
      return {
        ok: false,
        message: "\u5F53\u524D\u9009\u4E2D\u7684\u8D44\u6E90\u4E0D\u7B26\u5408\u5728\u7EBF\u5408\u5E76\u6761\u4EF6"
      };
    }
    const orderedResources = sortResourcesForOnlineMerge(resources);
    try {
      const result = await options.sendDesktopRequest({
        type: "create_task",
        source: "resource_merge",
        title: deriveMergeOutputTitle(orderedResources),
        payload: {
          resources: orderedResources.map((resource) => ({
            url: resource.url,
            filename: filenameForDesktop(resource),
            mime: resource.mime,
            size: resource.size,
            headers: resource.requestHeaders,
            pageTitle: resource.pageTitle,
            supportsRange: resource.supportsRange
          }))
        }
      });
      if (result.ok) {
        orderedResources.forEach((resource) => markResourceSent(resource.id));
        return {
          ...result,
          message: result.message || "\u5728\u7EBF\u5408\u5E76\u4EFB\u52A1\u5DF2\u53D1\u9001\u5230 Ghost Downloader"
        };
      }
      return result;
    } catch (error) {
      return {
        ok: false,
        message: error instanceof Error ? error.message : "\u5728\u7EBF\u5408\u5E76\u5931\u8D25"
      };
    }
  }
  function buildPopupStateData(resolvedTabId, activeTab) {
    const canCaptureCurrentTab = Boolean(activeTab?.url && isCapturableUrl(activeTab.url));
    let resourceState = "ready";
    let resourceStateMessage = "\u7B49\u5F85 cat-catch \u6355\u83B7\u8D44\u6E90";
    if (!bridgeStateReady) {
      resourceState = "restoring";
      resourceStateMessage = "\u6B63\u5728\u6062\u590D cat-catch \u5DF2\u6355\u83B7\u7684\u8D44\u6E90";
    } else if (!canCaptureCurrentTab) {
      resourceState = "unavailable";
      resourceStateMessage = "\u5F53\u524D\u6807\u7B7E\u9875\u4E0D\u652F\u6301 cat-catch \u8D44\u6E90\u6865\u63A5";
    }
    return {
      resourceState,
      resourceStateMessage,
      currentResources: resolvedTabId == null ? [] : sortResources(resourceCache.get(resolvedTabId)?.values() ?? []),
      otherResources: otherResourcesForTab(resolvedTabId),
      activePageDomain: domainFromUrl(activeTab?.url ?? "")
    };
  }
  function handleTabRemoved(tabId) {
    clearResourcesForTab(tabId);
    clearHeaderSnapshotsForTab(tabId);
    if (lastActiveTabId === tabId) {
      void setLastActiveTab(null);
    }
  }
  function handleNavigationCommitted(details) {
    if (details.tabId <= 0 || details.frameId !== 0) {
      return;
    }
    clearResourcesForTab(details.tabId);
    clearHeaderSnapshotsForTab(details.tabId);
  }
  function handleRequestHeaders(details) {
    const headers = normalizeHeaders(Object.fromEntries((details.requestHeaders ?? []).map((header) => [header.name ?? "", header.value ?? ""])));
    const supportsRange = (details.requestHeaders ?? []).some((header) => header.name?.toLowerCase() === "range" && String(header.value ?? "").toLowerCase().startsWith("bytes="));
    rememberHeaderSnapshot(details.url, headers, details.tabId > 0 ? details.tabId : lastActiveTabId, supportsRange);
  }
  return {
    buildPopupStateData,
    captureNetworkResource,
    capturePageResource,
    captureRequestResource,
    downloadPageMedia,
    handoffBrowserDownload,
    handleNavigationCommitted,
    handleRequestHeaders,
    handleTabRemoved,
    loadPersistentState,
    refreshActiveTabFromBrowser,
    resolveActiveTabId,
    mergeResources,
    sendResource,
    setLastActiveTab,
    tryInterceptFirefoxDownload
  };
}

// src/background.ts
var desktopBridge = createDesktopBridge();
var resourceBridge = createResourceBridge({
  sendDesktopRequest: (payload) => desktopBridge.sendRequest(payload),
  shouldBlockDownload: shouldBlockByBlacklist
});
var featureBridge = createFeatureBridge();
var mediaBridge = createMediaBridge();
var resourceBridgeCompat = resourceBridge;
var interceptDownloads = true;
var mediaDownloadOverlayEnabled = true;
var domainBlacklist = [];
var typeBlacklist = [];
var sizeBlacklistMB = "";
var notifyOnTaskCreated = true;
var cachedTaskState = null;
var taskCacheRefreshTimer = null;
function parseRuleLines(value) {
  return String(value ?? "").split(/\r?\n/).map((line) => line.trim().toLowerCase()).filter(Boolean);
}
function isDomainBlacklisted(rawUrl) {
  try {
    const hostname = new URL(rawUrl).hostname.toLowerCase();
    return domainBlacklist.some((rule) => hostname === rule || hostname.endsWith(`.${rule}`));
  } catch {
    return false;
  }
}
function isTypeBlacklistedByMeta(filename, mime, rawUrl) {
  const normalizedUrl = String(rawUrl ?? "").toLowerCase();
  const normalizedFilename = String(filename ?? "").toLowerCase();
  const normalizedMime = String(mime ?? "").toLowerCase();
  return typeBlacklist.some((rule) => {
    if (rule.startsWith(".")) {
      return normalizedUrl.includes(rule) || normalizedFilename.endsWith(rule);
    }
    return normalizedUrl.includes(rule) || normalizedFilename.includes(rule) || normalizedMime.includes(rule);
  });
}
function isSizeBlacklistedByValue(sizeBytes) {
  const raw = String(sizeBlacklistMB ?? "").trim();
  if (!raw) {
    return false;
  }
  const thresholdMB = Number(raw);
  if (!Number.isFinite(thresholdMB) || thresholdMB <= 0) {
    return false;
  }
  if (!Number.isFinite(sizeBytes) || sizeBytes <= 0) {
    return false;
  }
  return sizeBytes < thresholdMB * 1024 * 1024;
}
function shouldBlockByBlacklist(input) {
  if (isDomainBlacklisted(input.url)) {
    return true;
  }
  if (isTypeBlacklistedByMeta(input.filename ?? "", input.mime ?? "", input.url)) {
    return true;
  }
  if (typeof input.size === "number" && isSizeBlacklistedByValue(input.size)) {
    return true;
  }
  return false;
}
function domainFromRawUrl(rawUrl) {
  try {
    return new URL(rawUrl).hostname;
  } catch {
    return "";
  }
}
function normalizeMediaPanelState(mediaPanelState, resolvedTabId, activeTab) {
  const rawItems = Array.isArray(mediaPanelState.mediaItems) ? mediaPanelState.mediaItems : [];
  const mediaItems = rawItems.map((item) => ({
    index: Number(item.index ?? 0),
    label: String(item.label ?? `media-${Number(item.index ?? 0) + 1}`),
    type: item.type ?? "video"
  }));
  const rawPlayback = mediaPanelState.playbackState ?? {};
  const mediaIndex = Number(rawPlayback.mediaIndex ?? (mediaItems.length > 0 ? 0 : -1));
  const tabId = typeof rawPlayback.tabId === "number" ? rawPlayback.tabId : resolvedTabId;
  const playbackState = {
    available: Boolean(rawPlayback.available),
    stale: Boolean(rawPlayback.stale ?? false),
    message: String(rawPlayback.message ?? ""),
    tabId,
    mediaIndex,
    frameId: Number(rawPlayback.frameId ?? 0),
    count: Number(rawPlayback.count ?? mediaItems.length),
    currentTime: Number(rawPlayback.currentTime ?? 0),
    duration: Number(rawPlayback.duration ?? 0),
    progress: Number(rawPlayback.progress ?? 0),
    volume: Number(rawPlayback.volume ?? 1),
    paused: Boolean(rawPlayback.paused ?? true),
    loop: Boolean(rawPlayback.loop ?? false),
    muted: Boolean(rawPlayback.muted ?? false),
    speed: Number(rawPlayback.speed ?? 1),
    mediaType: String(rawPlayback.mediaType ?? "video")
  };
  const mediaTabs = resolvedTabId == null ? [] : [
    {
      tabId: resolvedTabId,
      title: activeTab?.title || "\u5F53\u524D\u6807\u7B7E\u9875",
      domain: domainFromRawUrl(activeTab?.url ?? "")
    }
  ];
  return {
    mediaTabs,
    mediaItems,
    selectedMediaTabId: tabId,
    selectedMediaIndex: mediaIndex,
    playbackState
  };
}
async function injectMediaDownloadOverlay(tabId) {
  if (!mediaDownloadOverlayEnabled) {
    return;
  }
  const tab = await getTab(tabId);
  if (!tab?.url || !/^https?:/i.test(tab.url)) {
    return;
  }
  try {
    await chrome.scripting.executeScript({
      files: ["catch-script/media-download-overlay.js"],
      injectImmediately: false,
      target: { tabId, allFrames: true }
    });
  } catch {
  }
}
async function syncMediaDownloadOverlay(enabled) {
  mediaDownloadOverlayEnabled = enabled;
  await chrome.storage.local.set({ [MEDIA_DOWNLOAD_OVERLAY_KEY]: enabled });
  const tabs = await queryTabs({});
  for (const tab of tabs) {
    if (!tab.id || !tab.url || !/^https?:/i.test(tab.url)) {
      continue;
    }
    chrome.tabs.sendMessage(
      tab.id,
      {
        type: "media_download_overlay_set_enabled",
        enabled
      },
      () => {
        const lastError = chrome.runtime.lastError;
        if (enabled && lastError && tab.id) {
          void injectMediaDownloadOverlay(tab.id);
        }
      }
    );
  }
}
function taskCounters(tasks) {
  return {
    total: tasks.length,
    active: tasks.filter((task) => task.status !== "completed").length,
    completed: tasks.filter((task) => task.status === "completed").length
  };
}
async function showTaskCreatedNotification(message) {
  if (!notifyOnTaskCreated) {
    return;
  }
  if (!chrome.notifications?.create) {
    return;
  }
  try {
    await chrome.notifications.create({
      type: "basic",
      iconUrl: chrome.runtime.getURL("icon128.png"),
      title: "Ghost Downloader",
      message: message?.trim() || "\u65B0\u4EFB\u52A1\u5DF2\u6210\u529F\u52A0\u5165 Ghost Downloader"
    });
  } catch {
  }
}
async function buildPopupState(options = {}) {
  const resolvedTabId = await resourceBridge.resolveActiveTabId(options.preferredTabId ?? null);
  const activeTab = resolvedTabId != null ? await getTab(resolvedTabId) : null;
  const desktopState = desktopBridge.buildSnapshot();
  const resourceState = resourceBridge.buildPopupStateData(resolvedTabId, activeTab);
  const mediaPanelState = normalizeMediaPanelState(
    await mediaBridge.buildPanelState(
      options.currentView === "advanced" || options.refreshMediaInventory ? resolvedTabId : null
    ),
    resolvedTabId,
    activeTab
  );
  return {
    connectionState: desktopState.connectionState,
    connectionMessage: desktopState.connectionMessage,
    desktopVersion: desktopState.desktopVersion,
    token: desktopState.token,
    serverUrl: desktopState.serverUrl,
    interceptDownloads,
    mediaDownloadOverlayEnabled,
    tasks: desktopState.tasks,
    taskCounters: taskCounters(desktopState.tasks),
    tabId: resolvedTabId,
    featureStates: featureBridge.createFeatureStateMap(resolvedTabId),
    mediaTabs: mediaPanelState.mediaTabs,
    mediaItems: mediaPanelState.mediaItems,
    selectedMediaTabId: mediaPanelState.selectedMediaTabId,
    selectedMediaIndex: mediaPanelState.selectedMediaIndex,
    mediaPlaybackState: mediaPanelState.playbackState,
    domainBlacklist: domainBlacklist.join("\n"),
    typeBlacklist: typeBlacklist.join("\n"),
    sizeBlacklistMB,
    notifyOnTaskCreated,
    ...resourceState
  };
}
function buildTaskState() {
  const desktopState = desktopBridge.buildSnapshot();
  return {
    connectionState: desktopState.connectionState,
    connectionMessage: desktopState.connectionMessage,
    desktopVersion: desktopState.desktopVersion,
    tasks: desktopState.tasks,
    taskCounters: taskCounters(desktopState.tasks)
  };
}
function updateTaskCache() {
  try {
    cachedTaskState = buildTaskState();
  } catch (error) {
    console.warn("Failed to update task cache:", error);
  }
}
async function broadcastTaskUpdate() {
  if (!cachedTaskState) {
    return;
  }
  try {
    await chrome.runtime.sendMessage({
      type: "task_update",
      payload: cachedTaskState
    });
  } catch {
  }
}
function refreshAndBroadcastTaskState() {
  updateTaskCache();
  void broadcastTaskUpdate();
}
function startTaskCacheRefreshLoop() {
  if (taskCacheRefreshTimer) {
    clearInterval(taskCacheRefreshTimer);
  }
  taskCacheRefreshTimer = setInterval(() => {
    refreshAndBroadcastTaskState();
  }, 900);
}
async function initialize() {
  const localState = await localStorageGet({
    [INTERCEPT_DOWNLOADS_KEY]: true,
    [MEDIA_DOWNLOAD_OVERLAY_KEY]: true,
    [NOTIFY_ON_TASK_CREATED_KEY]: true,
    [DOMAIN_BLACKLIST_KEY]: "",
    [TYPE_BLACKLIST_KEY]: "",
    [SIZE_BLACKLIST_KEY]: ""
  });
  interceptDownloads = Boolean(localState[INTERCEPT_DOWNLOADS_KEY] ?? true);
  mediaDownloadOverlayEnabled = Boolean(localState[MEDIA_DOWNLOAD_OVERLAY_KEY] ?? true);
  notifyOnTaskCreated = Boolean(localState[NOTIFY_ON_TASK_CREATED_KEY] ?? true);
  domainBlacklist = parseRuleLines(String(localState[DOMAIN_BLACKLIST_KEY] ?? ""));
  typeBlacklist = parseRuleLines(String(localState[TYPE_BLACKLIST_KEY] ?? ""));
  sizeBlacklistMB = String(localState[SIZE_BLACKLIST_KEY] ?? "").trim();
  await desktopBridge.loadPersistentState();
  await resourceBridge.loadPersistentState();
  await featureBridge.loadPersistentState();
  const mediaBridgeAny = mediaBridge;
  if (typeof mediaBridgeAny.loadPersistentState === "function") {
    await mediaBridgeAny.loadPersistentState();
  }
  const activeTabId = await resourceBridge.resolveActiveTabId();
  if (activeTabId != null) {
    void injectMediaDownloadOverlay(activeTabId);
  }
  if (desktopBridge.buildSnapshot().token) {
    void desktopBridge.connect();
  }
  desktopBridge.ensureReconnectAlarm();
  refreshAndBroadcastTaskState();
  startTaskCacheRefreshLoop();
}
chrome.alarms.onAlarm.addListener((alarm) => {
  desktopBridge.handleReconnectAlarm(alarm);
  refreshAndBroadcastTaskState();
});
chrome.runtime.onConnect.addListener((port) => {
  if (port.name === "HeartBeat") {
    port.postMessage("HeartBeat");
  }
});
chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName !== "local") {
    return;
  }
  desktopBridge.syncLocalStorageChanges(changes);
  if (changes[INTERCEPT_DOWNLOADS_KEY]) {
    interceptDownloads = Boolean(changes[INTERCEPT_DOWNLOADS_KEY].newValue ?? true);
  }
  if (changes[MEDIA_DOWNLOAD_OVERLAY_KEY]) {
    mediaDownloadOverlayEnabled = Boolean(changes[MEDIA_DOWNLOAD_OVERLAY_KEY].newValue ?? true);
  }
  if (changes[DOMAIN_BLACKLIST_KEY]) {
    domainBlacklist = parseRuleLines(String(changes[DOMAIN_BLACKLIST_KEY].newValue ?? ""));
  }
  if (changes[TYPE_BLACKLIST_KEY]) {
    typeBlacklist = parseRuleLines(String(changes[TYPE_BLACKLIST_KEY].newValue ?? ""));
  }
  if (changes[SIZE_BLACKLIST_KEY]) {
    sizeBlacklistMB = String(changes[SIZE_BLACKLIST_KEY].newValue ?? "").trim();
  }
  if (changes[NOTIFY_ON_TASK_CREATED_KEY]) {
    notifyOnTaskCreated = Boolean(changes[NOTIFY_ON_TASK_CREATED_KEY].newValue ?? true);
  }
  refreshAndBroadcastTaskState();
});
chrome.tabs.onActivated.addListener((activeInfo) => {
  void resourceBridge.setLastActiveTab(activeInfo.tabId);
  void injectMediaDownloadOverlay(activeInfo.tabId);
});
if (!isAndroidFirefoxLike()) {
  chrome.windows.onFocusChanged.addListener((windowId) => {
    if (windowId === chrome.windows.WINDOW_ID_NONE) {
      return;
    }
    void resourceBridge.refreshActiveTabFromBrowser().then((tabId) => {
      if (tabId != null) {
        void injectMediaDownloadOverlay(tabId);
      }
    });
  });
}
chrome.tabs.onRemoved.addListener((tabId) => {
  resourceBridge.handleTabRemoved(tabId);
  mediaBridge.handleTabRemoved(tabId);
  featureBridge.handleTabRemoved(tabId);
});
chrome.webNavigation.onCommitted.addListener((details) => {
  resourceBridgeCompat.handleNavigationCommitted?.(details);
  featureBridge.handleNavigationCommitted(details);
});
chrome.webRequest.onSendHeaders.addListener(
  (details) => {
    resourceBridgeCompat.handleRequestHeaders?.(details);
    void resourceBridgeCompat.captureRequestResource?.(details);
  },
  { urls: ["<all_urls>"] },
  getOnSendHeadersExtraInfoSpec()
);
chrome.webRequest.onResponseStarted.addListener(
  (details) => {
    void resourceBridge.captureNetworkResource(details);
  },
  { urls: ["<all_urls>"] },
  ["responseHeaders"]
);
if (isFirefoxExtension() && typeof resourceBridgeCompat.tryInterceptFirefoxDownload === "function") {
  chrome.webRequest.onHeadersReceived.addListener(
    (details) => {
      if (!interceptDownloads || !desktopBridge.isReady() || !/^https?:/i.test(details.url)) {
        return void 0;
      }
      return resourceBridgeCompat.tryInterceptFirefoxDownload?.(details) ?? void 0;
    },
    { urls: ["<all_urls>"], types: ["main_frame", "sub_frame"] },
    ["blocking", "responseHeaders"]
  );
}
async function interceptBrowserDownload(downloadItem, options = {}) {
  const finalUrl = String(downloadItem.finalUrl || downloadItem.url || "");
  if (!interceptDownloads || !desktopBridge.isReady() || !/^https?:/i.test(finalUrl)) {
    return;
  }
  if (shouldBlockByBlacklist({
    url: finalUrl,
    filename: String(downloadItem.filename || ""),
    mime: "",
    size: typeof downloadItem.totalBytes === "number" && downloadItem.totalBytes > 0 ? downloadItem.totalBytes : void 0
  })) {
    return;
  }
  try {
    await cancelDownload(downloadItem.id);
    if (options.eraseFromHistory) {
      await eraseDownloadFromHistory(downloadItem.id);
    }
  } catch {
  }
  await resourceBridge.handoffBrowserDownload(downloadItem);
  await showTaskCreatedNotification();
  refreshAndBroadcastTaskState();
}
if (supportsDownloadDeterminingFilename()) {
  chrome.downloads.onDeterminingFilename.addListener((downloadItem, suggest) => {
    suggest();
    void interceptBrowserDownload(downloadItem);
  });
} else if (chrome.downloads?.onCreated?.addListener) {
  chrome.downloads.onCreated.addListener((downloadItem) => {
    void interceptBrowserDownload(downloadItem, { eraseFromHistory: true });
  });
}
function reply(sendResponse, response) {
  void response.then(sendResponse);
  return true;
}
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || typeof message !== "object") {
    return;
  }
  if (message.Message === "addMedia" && typeof message.url === "string") {
    void resourceBridge.capturePageResource(sender, {
      url: message.url,
      href: message.href,
      mime: message.mime,
      ext: message.extraExt,
      requestHeaders: message.requestHeaders
    });
    sendResponse("ok");
    return true;
  }
  if (typeof message.type !== "string") {
    return;
  }
  if (message.type === "bridge_page_media") {
    void resourceBridge.capturePageResource(sender, message.payload);
    sendResponse({ ok: true });
    return true;
  }
  if (message.type === "bridge_page_command") {
    void featureBridge.handleBridgeScriptCommand(message.payload, sender);
    sendResponse({ ok: true });
    return true;
  }
  if (message.type === "popup_get_state") {
    return reply(
      sendResponse,
      (async () => {
        const state = await buildPopupState({
          preferredTabId: typeof message.tabId === "number" ? message.tabId : null,
          currentView: message.view
        });
        cachedTaskState = {
          connectionState: state.connectionState,
          connectionMessage: state.connectionMessage,
          desktopVersion: state.desktopVersion,
          tasks: state.tasks,
          taskCounters: state.taskCounters
        };
        return state;
      })()
    );
  }
  if (message.type === "popup_get_tasks_state") {
    if (!cachedTaskState) {
      updateTaskCache();
    }
    sendResponse(cachedTaskState ?? buildTaskState());
    return true;
  }
  if (message.type === "popup_set_token") {
    return reply(
      sendResponse,
      (async () => {
        await desktopBridge.setToken(String(message.token ?? "").trim());
        refreshAndBroadcastTaskState();
        return buildPopupState({ currentView: message.view });
      })()
    );
  }
  if (message.type === "popup_set_server_url") {
    return reply(
      sendResponse,
      (async () => {
        await desktopBridge.setServerUrl(String(message.serverUrl ?? ""));
        refreshAndBroadcastTaskState();
        return buildPopupState({ currentView: message.view });
      })()
    );
  }
  if (message.type === "popup_request_pairing") {
    return reply(
      sendResponse,
      (async () => {
        try {
          await desktopBridge.requestPairing();
          refreshAndBroadcastTaskState();
          return { ok: true, message: "\u914D\u5BF9\u6210\u529F" };
        } catch (error) {
          refreshAndBroadcastTaskState();
          return {
            ok: false,
            message: error instanceof Error ? error.message : "\u81EA\u52A8\u914D\u5BF9\u5931\u8D25"
          };
        }
      })()
    );
  }
  if (message.type === "popup_refresh_connection") {
    return reply(
      sendResponse,
      (async () => {
        await desktopBridge.connect(true);
        refreshAndBroadcastTaskState();
        return buildPopupState({ currentView: message.view });
      })()
    );
  }
  if (message.type === "popup_set_media_download_overlay") {
    return reply(
      sendResponse,
      (async () => {
        await syncMediaDownloadOverlay(Boolean(message.enabled));
        return buildPopupState({ currentView: message.view });
      })()
    );
  }
  if (message.type === "popup_set_intercept_downloads") {
    return reply(
      sendResponse,
      (async () => {
        interceptDownloads = Boolean(message.enabled);
        await chrome.storage.local.set({ [INTERCEPT_DOWNLOADS_KEY]: interceptDownloads });
        return buildPopupState({ currentView: message.view });
      })()
    );
  }
  if (message.type === "popup_task_action") {
    return reply(
      sendResponse,
      (async () => {
        try {
          const result = await desktopBridge.sendRequest({
            type: "task_action",
            taskId: message.taskId,
            action: message.action
          });
          refreshAndBroadcastTaskState();
          return result;
        } catch (error) {
          return {
            ok: false,
            message: error instanceof Error ? error.message : "\u4EFB\u52A1\u64CD\u4F5C\u5931\u8D25"
          };
        }
      })()
    );
  }
  if (message.type === "popup_send_resource") {
    return reply(
      sendResponse,
      (async () => {
        const result = await resourceBridge.sendResource(String(message.resourceId ?? ""));
        if (result.ok) {
          await showTaskCreatedNotification(result.message);
        }
        refreshAndBroadcastTaskState();
        return result;
      })()
    );
  }
  if (message.type === "popup_merge_resources") {
    return reply(
      sendResponse,
      (async () => {
        const resourceIds = Array.isArray(message.resourceIds) ? message.resourceIds.map((value) => String(value ?? "")).filter(Boolean) : [];
        const result = await resourceBridge.mergeResources(resourceIds);
        if (result.ok) {
          await showTaskCreatedNotification(result.message);
        }
        refreshAndBroadcastTaskState();
        return result;
      })()
    );
  }
  if (message.type === "page_download_media") {
    return reply(
      sendResponse,
      (async () => {
        const result = await resourceBridge.downloadPageMedia(sender, {
          url: String(message.url ?? ""),
          href: String(message.href ?? ""),
          filename: String(message.filename ?? ""),
          poster: String(message.poster ?? ""),
          resourceUrls: Array.isArray(message.resourceUrls) ? message.resourceUrls.map((url) => String(url ?? "")).filter(Boolean) : []
        });
        if (result.ok) {
          await showTaskCreatedNotification(result.message);
          await openActionPopup();
          refreshAndBroadcastTaskState();
        }
        return result;
      })()
    );
  }
  if (message.type === "page_media_overlay_state") {
    sendResponse({ enabled: mediaDownloadOverlayEnabled });
    return;
  }
  if (message.type === "popup_toggle_feature") {
    return reply(
      sendResponse,
      (async () => {
        const tabId = typeof message.tabId === "number" ? message.tabId : null;
        if (tabId == null) {
          return { ok: false, message: "\u5F53\u524D\u6CA1\u6709\u53EF\u64CD\u4F5C\u7684\u6807\u7B7E\u9875" };
        }
        try {
          const infoMessage = await featureBridge.toggleFeature(message.feature, tabId);
          return { ok: true, message: infoMessage };
        } catch (error) {
          return {
            ok: false,
            message: error instanceof Error ? error.message : "\u529F\u80FD\u5207\u6362\u5931\u8D25"
          };
        }
      })()
    );
  }
  if (message.type === "popup_set_media_target" || message.type === "popup_set_media_index") {
    return reply(
      sendResponse,
      (async () => {
        const tabId = Number(message.tabId ?? 0);
        const index = Number(message.index ?? -1);
        const mediaBridgeAny = mediaBridge;
        if (typeof mediaBridgeAny.setMediaTarget === "function") {
          await mediaBridgeAny.setMediaTarget(tabId, index);
        } else {
          mediaBridge.setMediaIndex(tabId, index);
        }
        return buildPopupState({
          currentView: "advanced",
          refreshMediaInventory: true
        });
      })()
    );
  }
  if (message.type === "popup_media_action") {
    return reply(
      sendResponse,
      (async () => {
        const mediaBridgeAny = mediaBridge;
        if (typeof mediaBridgeAny.performAction === "function") {
          return mediaBridgeAny.performAction(String(message.action ?? ""), message.value);
        }
        return {
          ok: false,
          message: "\u5F53\u524D media-bridge \u7248\u672C\u4E0D\u652F\u6301\u5A92\u4F53\u63A7\u5236\u64CD\u4F5C"
        };
      })()
    );
  }
  if (message.type === "popup_set_domain_blacklist") {
    return reply(
      sendResponse,
      (async () => {
        const value = String(message.value ?? "");
        await chrome.storage.local.set({ [DOMAIN_BLACKLIST_KEY]: value });
        return { ok: true };
      })()
    );
  }
  if (message.type === "popup_set_type_blacklist") {
    return reply(
      sendResponse,
      (async () => {
        const value = String(message.value ?? "");
        await chrome.storage.local.set({ [TYPE_BLACKLIST_KEY]: value });
        return { ok: true };
      })()
    );
  }
  if (message.type === "popup_set_size_blacklist") {
    return reply(
      sendResponse,
      (async () => {
        const value = String(message.value ?? "").trim();
        await chrome.storage.local.set({ [SIZE_BLACKLIST_KEY]: value });
        return { ok: true };
      })()
    );
  }
  if (message.type === "popup_set_notify_on_task_created") {
    return reply(
      sendResponse,
      (async () => {
        notifyOnTaskCreated = Boolean(message.enabled);
        await chrome.storage.local.set({
          [NOTIFY_ON_TASK_CREATED_KEY]: notifyOnTaskCreated
        });
        return buildPopupState({ currentView: message.view });
      })()
    );
  }
});
void initialize();
