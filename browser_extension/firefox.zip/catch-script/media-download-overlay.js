(function installGhostDownloaderMediaButton() {
    if (window.GhostDownloaderMediaButton?.installed) { return; }
    if (!globalThis.chrome?.runtime?.sendMessage) { return; }

    const host = document.createElement("div");
    const root = host.attachShadow({ mode: "open" });
    let resetTimer = 0;
    let updateQueued = false;
    let enabled = false;

    host.id = "ghostDownloaderMediaDownload";
    Object.assign(host.style, {
        display: "none",
        left: "0",
        position: "fixed",
        top: "0",
        zIndex: "1000000000",
    });

    root.innerHTML = `
        <style>
            :host {
                font: 13px/18px "Segoe UI", "Microsoft YaHei", Arial, sans-serif;
            }
            button {
                align-items: center;
                background: rgba(255, 255, 255, 0.96);
                border: 1px solid #d1d1d1;
                border-radius: 4px;
                box-shadow: 0 8px 20px rgba(0, 0, 0, 0.18), 0 1px 4px rgba(0, 0, 0, 0.12);
                color: #242424;
                cursor: pointer;
                display: inline-flex;
                font: inherit;
                font-weight: 600;
                gap: 6px;
                min-height: 32px;
                padding: 6px 10px;
                white-space: nowrap;
            }
            button:hover {
                background: #f5f5f5;
            }
            button:active {
                background: #e0e0e0;
            }
            button:disabled {
                cursor: default;
                opacity: 0.78;
            }
            .icon {
                width: 16px;
                height: 16px;
                flex: none;
            }
            .status {
                color: #0f6cbd;
            }
            .error {
                color: #b10e1c;
            }
        </style>
        <button type="button" title="发送当前媒体到 Ghost Downloader">
            <svg class="icon" viewBox="0 0 20 20" aria-hidden="true">
                <path fill="currentColor" d="M10 2.5a.75.75 0 0 1 .75.75v7.69l2.72-2.72a.75.75 0 1 1 1.06 1.06l-4 4a.75.75 0 0 1-1.06 0l-4-4a.75.75 0 0 1 1.06-1.06l2.72 2.72V3.25A.75.75 0 0 1 10 2.5Zm-5.25 11a.75.75 0 0 1 .75.75v1.25h9v-1.25a.75.75 0 0 1 1.5 0v2a.75.75 0 0 1-.75.75H4.75A.75.75 0 0 1 4 16.25v-2a.75.75 0 0 1 .75-.75Z"/>
            </svg>
            <span class="label">下载此媒体</span>
            <span class="status"></span>
        </button>
    `;

    const button = root.querySelector("button");
    const label = root.querySelector(".label");
    const status = root.querySelector(".status");

    function mediaRect(media) {
        const rect = media.getBoundingClientRect();
        if (rect.width < 120 || rect.height < 80 || rect.bottom <= 0 || rect.right <= 0 || rect.top >= innerHeight || rect.left >= innerWidth) {
            return null;
        }
        return rect;
    }

    function mediaScore(media, rect) {
        const playing = !media.paused && !media.ended ? 1_000_000_000 : 0;
        return playing + media.readyState * 1_000_000 + rect.width * rect.height;
    }

    function findActiveMedia() {
        let selected = null;
        for (const media of document.querySelectorAll("video")) {
            const rect = mediaRect(media);
            if (!rect) { continue; }
            const score = mediaScore(media, rect);
            if (!selected || score > selected.score) {
                selected = { media, rect, score };
            }
        }
        return selected;
    }

    function recentMediaResourceUrls() {
        return performance.getEntriesByType("resource")
            .filter((entry) => /video|audio|mpegurl|mp4|m4s|mpd|m3u8|douyinvod|twimg/i.test(`${entry.name} ${entry.initiatorType}`))
            .sort((left, right) => right.startTime - left.startTime)
            .slice(0, 20)
            .map((entry) => entry.name);
    }

    function updatePosition() {
        updateQueued = false;
        if (!enabled) {
            host.style.display = "none";
            return;
        }
        const selected = findActiveMedia();
        if (!selected) {
            host.style.display = "none";
            return;
        }

        host.style.display = "block";
        const gap = 8;
        const buttonWidth = host.offsetWidth || 112;
        const buttonHeight = host.offsetHeight || 32;
        let left = selected.rect.right + gap;
        let top = selected.rect.top;

        if (left + buttonWidth > innerWidth - gap) {
            left = Math.min(innerWidth - buttonWidth - gap, Math.max(gap, selected.rect.right - buttonWidth));
            top = selected.rect.top - buttonHeight - gap;
        }
        if (top < gap && selected.rect.left - buttonWidth - gap >= gap) {
            left = selected.rect.left - buttonWidth - gap;
            top = selected.rect.top;
        }
        if (top < gap) {
            top = selected.rect.bottom + gap;
        }

        host.style.left = `${Math.max(gap, Math.min(left, innerWidth - buttonWidth - gap))}px`;
        host.style.top = `${Math.max(gap, Math.min(top, innerHeight - buttonHeight - gap))}px`;
    }

    function enableOverlay() {
        enabled = true;
        if (document.documentElement && !host.isConnected) {
            document.documentElement.appendChild(host);
        }
        scheduleUpdate();
    }

    function disableOverlay() {
        enabled = false;
        host.style.display = "none";
        host.remove();
    }

    function scheduleUpdate() {
        if (updateQueued) { return; }
        updateQueued = true;
        requestAnimationFrame(updatePosition);
    }

    function setStatus(text, failed = false) {
        status.textContent = text;
        status.className = failed ? "status error" : "status";
        clearTimeout(resetTimer);
        if (text && !failed) {
            resetTimer = setTimeout(() => { status.textContent = ""; }, 1600);
        }
    }

    async function downloadMedia() {
        const media = findActiveMedia()?.media;
        if (!media) {
            setStatus("未检测到媒体", true);
            return;
        }

        button.disabled = true;
        label.textContent = "正在发送";
        setStatus("");
        try {
            const result = await chrome.runtime.sendMessage({
                type: "page_download_media",
                url: media.currentSrc || media.src || "",
                href: location.href,
                filename: document.title,
                poster: media.poster || "",
                resourceUrls: recentMediaResourceUrls(),
            });
            setStatus(result?.ok ? "已发送" : result?.message || "发送失败", !result?.ok);
        } catch (error) {
            setStatus(error instanceof Error ? error.message : "发送失败", true);
        } finally {
            label.textContent = "下载此媒体";
            button.disabled = false;
            scheduleUpdate();
        }
    }

    button.addEventListener("click", (event) => {
        event.preventDefault();
        event.stopPropagation();
        void downloadMedia();
    });

    addEventListener("resize", scheduleUpdate, { passive: true });
    addEventListener("scroll", scheduleUpdate, { passive: true });
    document.addEventListener("play", scheduleUpdate, true);
    document.addEventListener("pause", scheduleUpdate, true);
    document.addEventListener("loadedmetadata", scheduleUpdate, true);
    setInterval(scheduleUpdate, 1000);

    chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
        if (message?.type !== "media_download_overlay_set_enabled") { return; }
        Boolean(message.enabled) ? enableOverlay() : disableOverlay();
        sendResponse({ ok: true });
    });

    chrome.runtime.sendMessage({ type: "page_media_overlay_state" }, (result) => {
        const lastError = chrome.runtime.lastError;
        if (!lastError && result?.enabled === false) {
            disableOverlay();
            return;
        }
        enableOverlay();
    });

    window.GhostDownloaderMediaButton = {
        installed: true,
    };
})();
